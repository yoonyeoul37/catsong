package kr.ssing.catsong

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews
import io.flutter.plugin.common.MethodChannel
import io.flutter.embedding.engine.FlutterEngineCache
import com.ryanheise.audioservice.AudioServicePlugin
import java.util.Calendar

/// 홈 위젯 B안 (4×2)
/// 위: 시간대 라디오 사진 위에 지금 듣는 것 + 이전·재생·다음
/// 아래: 음악 · 라디오 · 자연 · 수면 바로가기 (누르면 앱이 그 화면으로 열림)
class PlayerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) updateAppWidget(context, appWidgetManager, id)
    }

    // 바탕화면에서 위젯 크기를 바꾸면 사진도 새 크기에 맞게
    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager,
                                           appWidgetId: Int, newOptions: android.os.Bundle) {
        updateAppWidget(context, appWidgetManager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val a = intent.action ?: return
        if (MainActivity.mediaChannel == null) attachHeadless(context)
        when {
            a == ACTION_PLAY_PAUSE -> {
                if (tooSoon(context)) return
                pressed(context, null)
                toApp("widgetPlayPause", null) { wakeAndPlay(context, null) }
            }
            a == ACTION_NEXT -> sendMediaKey(context, android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            a == ACTION_PREV -> sendMediaKey(context, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            a == ACTION_REPEAT || a == ACTION_SHUFFLE -> {
                if (MainActivity.mediaChannel != null) {
                    flipMode(context, a == ACTION_REPEAT) // 누르자마자 모양 먼저
                    toApp(if (a == ACTION_REPEAT) "widgetRepeat" else "widgetShuffle", null) {}
                }
            }
            a == ACTION_SLEEP -> {
                // ⋮ 창에서 맞춘 수면 타이머 → 앱(다트)에게 (앱이 막 깨어나는 중이면 조금 기다렸다가)
                val m = intent.getIntExtra("minutes", 0)
                if (MainActivity.mediaChannel != null) {
                    toApp("widgetSleep", m) {}
                } else {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        try { MainActivity.mediaChannel?.invokeMethod("widgetSleep", m) } catch (_: Exception) {}
                    }, 1500)
                }
            }
            a.startsWith(ACTION_KIND) -> {
                // 아래 버튼: 음악 · 라디오 · 자연 바로 재생 (앱 안 열고)
                if (tooSoon(context)) return
                val kind = a.removePrefix(ACTION_KIND)
                pressed(context, kind)
                toApp("widgetPlayKind", kind) { wakeAndPlay(context, kind) }
            }
        }
    }

    /// 앱(다트)에게 바로 전달 — 앱이 꺼져 있거나 1.2초 안에 대답이 없으면 fallback
    private fun toApp(method: String, arg: Any?, fallback: () -> Unit) {
        val ch = MainActivity.mediaChannel
        if (ch == null) {
            fallback()
            return
        }
        val pending = goAsync()
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        var done = false
        val finish = { useFallback: Boolean ->
            if (!done) {
                done = true
                if (useFallback) fallback()
                pending.finish()
            }
        }
        h.postDelayed({
            finish(true)
        }, 1200)
        try {
            ch.invokeMethod(method, arg, object : MethodChannel.Result {
                override fun success(result: Any?) {
                    finish(false)
                }
                override fun error(code: String, msg: String?, details: Any?) = finish(false)
                override fun notImplemented() {
                    finish(true)
                }
            })
        } catch (_: Exception) {
            finish(true)
        }
    }

    /// 앱이 정말 꺼져 있으면: 화면 없이 재생 엔진만 깨우기 (다트가 이 표시를 보고 틂)
    private fun wakeAndPlay(context: Context, kind: String?) {
        val e = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).edit()
            .putLong("flutter.widget_play_at", System.currentTimeMillis())
        if (kind == null) e.remove("flutter.widget_play_kind") else e.putString("flutter.widget_play_kind", kind)
        e.apply()
        sendMediaKey(context, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "kr.ssing.catsong.PLAY_PAUSE"
        const val ACTION_NEXT = "kr.ssing.catsong.NEXT"
        const val ACTION_PREV = "kr.ssing.catsong.PREV"
        const val ACTION_KIND = "kr.ssing.catsong.PLAY_KIND_" // 뒤에 music · radio · nature
        const val ACTION_REPEAT = "kr.ssing.catsong.REPEAT"
        const val ACTION_SHUFFLE = "kr.ssing.catsong.SHUFFLE"
        const val ACTION_SLEEP = "kr.ssing.catsong.SLEEP" // ⋮ 창 → 수면 타이머 (minutes, 0이면 끄기)
        private const val PREFS = "paran_widget"
        private const val TAP_GAP = 1000L    // 이 시간 안에 또 누르면 무시 (1초)
        private const val LOAD_MAX = 10000L  // '불러오는 중…' 은 길어도 10초까지만
        private const val TALL_BOTTOM = 148  // 세로 2×3 위젯 아래 크림 칸 높이(dp)

        /// 1초 안에 또 누른 거면 true (무시)
        private fun tooSoon(context: Context): Boolean {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val gap = now - p.getLong("tap", 0L)
            if (gap in 0 until TAP_GAP) {
                return true
            }
            p.edit().putLong("tap", now).apply()
            return false
        }

        /// 반복·섞기: 누르자마자 위젯 모양 먼저 (앱도 같은 값으로 저장함)
        private fun flipMode(context: Context, repeat: Boolean) {
            try {
                val fp = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                if (repeat) {
                    // 0 반복 안 함 → 1 한 곡 반복 → 2 전체 반복
                    fp.edit().putLong("flutter.w_loop", (fp.getLong("flutter.w_loop", 0L) + 1) % 3).apply()
                } else {
                    fp.edit().putBoolean("flutter.w_shuffle", !fp.getBoolean("flutter.w_shuffle", false)).apply()
                }
            } catch (_: Exception) {}
            refreshAll(context)
        }

        /// 누르자마자 위젯 모양부터 바꾸기
        /// - 듣는 중에 재생 버튼 = 멈춤 → 버튼만 바로 ▶
        /// - 그 밖엔 '불러오는 중…' + ⏸ (진짜 곡·방송 이름이 오면 바뀜)
        private fun pressed(context: Context, kind: String?) {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val playing = p.getBoolean("p", false)
            if (kind == null && playing) {
                p.edit().putBoolean("p", false).apply()
            } else {
                // load_any: 다른 걸 듣다가 바꾼 경우 → 어떤 소식이 와도 끝냄
                p.edit().putLong("load", System.currentTimeMillis()).putBoolean("load_any", playing).apply()
                val app = context.applicationContext
                android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed({ refreshAll(app) }, LOAD_MAX + 300)
            }
            refreshAll(context)
        }

        /// 앱 화면 없이 재생 엔진만 깨어났을 때: 위젯 ↔ 앱 통로를 위젯이 직접 연결
        /// (그래야 다음 누름부터 바로 전달되고, 곡·방송 이름도 위젯에 뜸)
        /// 나중에 앱 화면이 열리면 앱이 자기 통로로 다시 바꿔 끼움
        fun attachHeadless(context: Context, tries: Int = 0) {
            if (MainActivity.mediaChannel != null) return
            val app = context.applicationContext
            val engine = FlutterEngineCache.getInstance().get(AudioServicePlugin.getFlutterEngineId())
            if (engine == null) {
                if (tries < 40) android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed({ attachHeadless(app, tries + 1) }, 250)
                return
            }
            val ch = MethodChannel(engine.dartExecutor.binaryMessenger, "kr.ssing.catsong/media")
            ch.setMethodCallHandler { call, result ->
                if (call.method == "requestAudioFocus") {
                    result.success(true) // 화면 없을 땐 그냥 통과 (오류 안 나게)
                } else if (call.method == "refreshWidget") {
                    refreshAll(app) // 최근에 들은 목록이 바뀜
                    result.success(null)
                } else if (call.method == "updateWidget") {
                    val mgr = AppWidgetManager.getInstance(app)
                    for (id in allIds(app)) updateAppWidget(app, mgr, id,
                        call.argument<String>("title") ?: app.getString(R.string.app_name),
                        call.argument<String>("artist") ?: "",
                        call.argument<Boolean>("isPlaying") ?: false,
                        call.argument<String>("schedule") ?: "")
                    result.success(null)
                } else {
                    result.notImplemented()
                }
            }
            MainActivity.mediaChannel = ch
        }

        /// 다음·이전 → 앱의 재생 버튼 받는 곳(audio_service)으로 바로
        fun sendMediaKey(context: Context, keyCode: Int) {
            context.sendBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                component = android.content.ComponentName(
                    context.packageName, "com.ryanheise.audioservice.MediaButtonReceiver")
                putExtra(Intent.EXTRA_KEY_EVENT,
                    android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
            })
        }

        /// 바탕화면에 붙은 파란소리 위젯 전부 (4×2 + 4×3 + 세로 2×3)
        fun allIds(context: Context): IntArray {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(android.content.ComponentName(context, PlayerWidget::class.java)) +
                mgr.getAppWidgetIds(android.content.ComponentName(context, PlayerWidget2::class.java)) +
                mgr.getAppWidgetIds(android.content.ComponentName(context, PlayerWidget3::class.java))
        }

        /// 앱에서 고른 언어(설정 → 언어)의 글자 꺼내기 — '폰 언어'면 그대로
        fun localized(context: Context): Context {
            return try {
                val code = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                    .getString("flutter.appLanguage", "system") ?: "system"
                val tag = when (code) {
                    "system", "" -> return context
                    "zh_Hant" -> "zh-TW"
                    "zh_Hans" -> "zh-CN"
                    "pt" -> "pt-BR"
                    else -> code
                }
                val cfg = android.content.res.Configuration(context.resources.configuration)
                cfg.setLocale(java.util.Locale.forLanguageTag(tag))
                context.createConfigurationContext(cfg)
            } catch (_: Exception) {
                context
            }
        }

        /// 바탕화면에 붙은 위젯 전부 다시 그리기 (앱이 켜지고 꺼질 때)
        fun refreshAll(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                for (id in allIds(context)) updateAppWidget(context, mgr, id)
            } catch (_: Exception) {}
        }

        /// 곡 정보가 오면 기억해 두고, 없으면(시간대 바뀔 때 등) 기억한 걸로 다시 그림
        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            title: String? = null,
            artist: String? = null,
            isPlaying: Boolean? = null,
            schedule: String = ""
        ) {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (title != null) {
                p.edit().putString("t", title).putString("a", artist ?: "")
                    .putBoolean("p", isPlaying ?: false).putString("s", schedule).apply()
                // 소리가 나기 시작하면 끝 (다른 걸 듣다 바꾼 경우엔 어떤 소식이든 오면 끝)
                if (isPlaying == true || p.getBoolean("load_any", false)) p.edit().remove("load").apply()
            }
            // 가사 줄만 바뀐 건 폰 화면이 꺼져 있으면 기억만 하고 안 그림 (화면 켜면 다음 줄부터)
            if (schedule.startsWith("♪")) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (!pm.isInteractive) return
            }
            val loadAt = p.getLong("load", 0L)
            val loading = loadAt > 0 && System.currentTimeMillis() - loadAt in 0 until LOAD_MAX
            val t = p.getString("t", null)
            val a = p.getString("a", null) ?: ""
            val s = p.getString("s", null) ?: ""
            val playing = p.getBoolean("p", false)
            val empty = t == null || t == "플레이쏭" || t == "캣송"

            // 4×3 위젯이면 큰 모양 (위는 똑같고, 아래에 최근에 들은 것)
            val cls = appWidgetManager.getAppWidgetInfo(appWidgetId)?.provider?.className
            val big = cls == PlayerWidget2::class.java.name
            // 세로 2×3이면 위 사진 + 아래 크림 칸 (제목 · 버튼 · 바로가기 아이콘만)
            val tall = cls == PlayerWidget3::class.java.name
            val views = RemoteViews(context.packageName,
                if (tall) R.layout.widget_player3 else if (big) R.layout.widget_player2 else R.layout.widget_player)
            // 글자는 앱에서 고른 언어로 (위젯은 바탕화면 앱이 그려서, 그냥 두면 폰 언어로 나옴)
            val lc = localized(context)
            if (tall) {
                // 세로 위젯은 바로가기 글자 없이 아이콘만 → 읽어 주기용 이름만
                views.setContentDescription(R.id.widget_go_music, lc.getString(R.string.tab_music))
                views.setContentDescription(R.id.widget_go_radio, lc.getString(R.string.tab_radio))
                views.setContentDescription(R.id.widget_go_nature, lc.getString(R.string.tab_nature))
                views.setContentDescription(R.id.widget_go_sleep, lc.getString(R.string.tab_sleep))
            } else {
                views.setTextViewText(R.id.widget_go_music_label, lc.getString(R.string.tab_music))
                views.setTextViewText(R.id.widget_go_radio_label, lc.getString(R.string.tab_radio))
                views.setTextViewText(R.id.widget_go_nature_label, lc.getString(R.string.tab_nature))
                views.setTextViewText(R.id.widget_go_sleep_label, lc.getString(R.string.tab_sleep))
            }
            if (big) views.setTextViewText(R.id.widget_recent_empty, lc.getString(R.string.widget_recent_empty))
            views.setTextViewText(R.id.widget_title,
                if (loading) lc.getString(R.string.widget_loading) else if (empty) lc.getString(R.string.app_name) else t)
            views.setTextViewText(R.id.widget_artist,
                if (loading) lc.getString(R.string.widget_wait) else if (empty) lc.getString(R.string.widget_idle_sub) else a)
            views.setTextViewText(R.id.widget_schedule, s)
            views.setViewVisibility(R.id.widget_schedule, if (loading || s.isEmpty()) View.GONE else View.VISIBLE)
            views.setImageViewResource(R.id.widget_play_pause,
                if (playing || loading) R.drawable.paran_ic_pause else R.drawable.paran_ic_play)
            // ⋮ 메뉴: 듣는 게 있으면 언제나 (랜덤·반복 줄은 창에서 음악일 때만) — 세 위젯 모두 같음
            val fp = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            views.setViewVisibility(R.id.widget_more, if (!empty) View.VISIBLE else View.GONE)
            // 수면 타이머 남은 시간 (음악·자연 'm' · 라디오 'r' 중 늦게 끝나는 것) — 1초마다 저절로 줄어듦
            val sleepEnd = maxOf(
                try { fp.getLong("flutter.w_sleep_m", 0L) } catch (_: Exception) { 0L },
                try { fp.getLong("flutter.w_sleep_r", 0L) } catch (_: Exception) { 0L })
            val sleepLeft = sleepEnd - System.currentTimeMillis()
            if (sleepLeft > 0 && android.os.Build.VERSION.SDK_INT >= 24) {
                views.setViewVisibility(R.id.widget_timer, View.VISIBLE)
                views.setChronometer(R.id.widget_timer_text,
                    android.os.SystemClock.elapsedRealtime() + sleepLeft, null, true)
                views.setChronometerCountDown(R.id.widget_timer_text, true)
            } else {
                views.setViewVisibility(R.id.widget_timer, View.GONE)
                views.setChronometer(R.id.widget_timer_text, android.os.SystemClock.elapsedRealtime(), null, false)
            }
            // 4×3: 아래 '최근에 들었어요' 줄 (사진 칸 높이도 그만큼 빼기)
            // 4×2: 바로가기 64 / 4×3: 바로가기 54(46 + 위 8) + 최근 줄
            // 세로 2×3: 아래 크림 칸 148 (widget_player3.xml 과 같은 값)
            val bottomDp = if (tall) TALL_BOTTOM else if (big) 54 + recentRows(context, views, if (empty) null else t) else 64
            val photoBmp = photo(context, appWidgetManager, appWidgetId, bottomDp, big, tall)
            photoBmp?.let { views.setImageViewBitmap(R.id.widget_photo, it) }
            // 이 위젯 사진 칸 모양 (가로 ÷ 세로) → ⋮ 창 자르기 틀을 같은 모양으로
            val photoAspect = photoBmp?.let { it.width.toFloat() / it.height } ?: 2f

            // 사진 부분 누르면 앱 열기
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            views.setOnClickPendingIntent(R.id.widget_top, PendingIntent.getActivity(
                context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            // 이전 · 재생 · 다음 (이 위젯에게만 보내기 → 두 번 눌리는 일 없게)
            fun media(action: String, code: Int) = PendingIntent.getBroadcast(
                context, code, Intent(context, PlayerWidget::class.java).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_prev, media(ACTION_PREV, 1))
            // 재생: 앱이 켜져 있으면 앱에게 바로 / 꺼져 있으면 앱을 열면서 마지막에 듣던 것
            views.setOnClickPendingIntent(R.id.widget_play_pause, media(ACTION_PLAY_PAUSE, 2))
            views.setOnClickPendingIntent(R.id.widget_next, media(ACTION_NEXT, 3))
            // ⋮ → 바탕화면 위 작은 창 (앱 화면은 안 열림)
            val menu = Intent(context, WidgetMenuActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("aspect", photoAspect)
            }
            // 위젯마다 따로 (사진 칸 모양이 달라서 — 같은 번호면 마지막 위젯 값으로 덮임)
            views.setOnClickPendingIntent(R.id.widget_more, PendingIntent.getActivity(
                context, 1000 + appWidgetId, menu, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            // 바로가기 4개
            val go = listOf(
                R.id.widget_go_music to "music",
                R.id.widget_go_radio to "radio",
                R.id.widget_go_nature to "nature",
                R.id.widget_go_sleep to "sleep"
            )
            go.forEachIndexed { i, (viewId, target) ->
                val pi = if (target == "sleep") {
                    // 수면: 아직 소리가 없어서 화면 열기
                    val goIntent = Intent(context, MainActivity::class.java).apply {
                        action = "kr.ssing.catsong.WIDGET_GO_$target"
                        putExtra("widgetGo", target)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    PendingIntent.getActivity(context, 20 + i, goIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                } else {
                    // 음악(첫 곡부터) · 라디오 · 자연: 앱 안 열고 위젯에서 바로 재생
                    PendingIntent.getBroadcast(context, 20 + i,
                        Intent(context, PlayerWidget::class.java).setAction(ACTION_KIND + target),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                }
                views.setOnClickPendingIntent(viewId, pi)
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        /// 4×3 위젯: '최근에 들었어요' 3개 (지금 위에 나오는 건 빼고) — 누르면 바로 재생
        /// 돌려주는 값: 아래 칸 높이(dp) → 사진 칸 크기 맞추기용 (위 4 + 아래 10 + 줄마다 40)
        private fun recentRows(context: Context, views: RemoteViews, now: String?): Int {
            val rows = arrayOf(
                intArrayOf(R.id.widget_recent1, R.id.widget_recent1_icon, R.id.widget_recent1_title, R.id.widget_recent1_sub),
                intArrayOf(R.id.widget_recent2, R.id.widget_recent2_icon, R.id.widget_recent2_title, R.id.widget_recent2_sub),
                intArrayOf(R.id.widget_recent3, R.id.widget_recent3_icon, R.id.widget_recent3_title, R.id.widget_recent3_sub)
            )
            // 앱이 저장해 둔 '최근에 들었어요' 목록 (음악·라디오·자연만)
            val list = mutableListOf<org.json.JSONObject>()
            try {
                // 앱이 지금 듣는 종류에 맞춰 골라 둔 3개 (아직 없으면 '최근에 들었어요' 앞에서)
                val fp = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                val picked = fp.getString("flutter.w_list", null)
                val raw = picked ?: fp.getString("flutter.recent_content_v1", null)
                if (raw != null) {
                    val arr = org.json.JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val type = o.optString("type")
                        if (type != "music" && type != "radio" && type != "nature") continue
                        if (picked == null && now != null && o.optString("title") == now) continue
                        list.add(o)
                        if (list.size == rows.size) break
                    }
                }
            } catch (_: Exception) {}
            rows.forEachIndexed { i, r ->
                val o = list.getOrNull(i)
                if (o == null) {
                    views.setViewVisibility(r[0], View.GONE)
                    return@forEachIndexed
                }
                val type = o.optString("type")
                views.setViewVisibility(r[0], View.VISIBLE)
                views.setImageViewResource(r[1], when (type) {
                    "radio" -> R.drawable.paran_ic_radio
                    "nature" -> R.drawable.paran_ic_leaf
                    else -> R.drawable.paran_ic_music
                })
                views.setTextViewText(r[2], o.optString("title"))
                views.setTextViewText(r[3], o.optString("subtitle"))
                // 아래 버튼(음악·라디오·자연)과 같은 길로 → 앱이 꺼져 있어도 바로 재생
                views.setOnClickPendingIntent(r[0], PendingIntent.getBroadcast(context, 40 + i,
                    Intent(context, PlayerWidget::class.java)
                        .setAction(ACTION_KIND + "recent:" + type + "|" + o.optString("key")),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            views.setViewVisibility(R.id.widget_recent_empty, if (list.isEmpty()) View.VISIBLE else View.GONE)
            return 14 + 40 * maxOf(list.size, 1)
        }

        /// 지금 시간대 라디오 사진 (아침 5–11 · 낮 11–17 · 저녁 17–22 · 밤)
        /// 위젯 띠 모양으로 자르고, 모서리 둥글게, 아래쪽은 글자가 보이게 살짝 어둡게
        private fun photo(context: Context, mgr: AppWidgetManager, id: Int, bottomDp: Int, big: Boolean,
                          tall: Boolean = false): Bitmap? {
            // 사진 칸 크기(dp): 위젯 크기 - 아래 줄 (4×2 바로가기 64 · 4×3 최근에 들은 것)
            val opt = mgr.getAppWidgetOptions(id)
            val vw = opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH).takeIf { it > 0 } ?: 250
            val vh = ((opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT).takeIf { it > 0 } ?: if (tall) 270 else if (big) 280 else 180) - bottomDp)
                .coerceAtLeast(56)
            // 바깥 모서리 크기(dp) = res/values 의 paran_w_radius (안드로이드 12 이상은 폰이 정한 크기)
            val dens = context.resources.displayMetrics.density
            val radiusDp = context.resources.getDimension(R.dimen.paran_w_radius) / dens
            // 위젯 사진 6장 중 하루에 한 장 (하루 동안은 같고, 어제와 같은 사진은 안 나옴)
            val cal = Calendar.getInstance()
            val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
            fun pick(d: Int) = java.util.Random(d.toLong() * 7919).nextInt(6)
            var n = pick(day)
            if (n == pick(day - 1)) n = (n + 1) % 6
            val path = "flutter_assets/assets/widget_photo${n + 1}.jpg"
            // 직접 넣은 사진(⋮ → 위젯 사진 바꾸기)이 있으면 그걸로
            val custom = java.io.File(context.filesDir, "widget_photo.jpg")
            val useCustom = custom.exists()
            fun openSrc(): java.io.InputStream = if (useCustom) custom.inputStream() else context.assets.open(path)
            return try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                openSrc().use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 560) sample *= 2
                val src = openSrc().use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: return null
                // 자를 곳 (sl · top = 왼쪽 위, w · bh = 크기)
                val left: Int
                val top: Int
                val w: Int
                val bh: Int
                if (useCustom) {
                    // 자르기 화면에서 정한 곳을 가운데로, 이 위젯 사진 칸 모양에 맞게
                    val wp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    val cx = wp.getFloat("photo_cx", 0.5f)
                    val cy = wp.getFloat("photo_cy", 0.5f)
                    val zoom = wp.getFloat("photo_zoom", 1f).coerceIn(1f, 4f)
                    val aspect = vw.toFloat() / vh
                    var cw = src.width.toFloat()
                    var ch = cw / aspect
                    if (ch > src.height) {
                        ch = src.height.toFloat()
                        cw = ch * aspect
                    }
                    w = (cw / zoom).toInt().coerceIn(1, src.width)
                    bh = (ch / zoom).toInt().coerceIn(1, src.height)
                    left = (cx * src.width - w / 2f).toInt().coerceIn(0, src.width - w)
                    top = (cy * src.height - bh / 2f).toInt().coerceIn(0, src.height - bh)
                } else {
                    left = 0
                    w = src.width
                    bh = (w * vh.toFloat() / vw).toInt().coerceIn(1, src.height)
                    top = ((src.height - bh) * 0.35f).toInt()
                }
                val out = Bitmap.createBitmap(w, bh, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                // 세로 위젯 + 안드로이드 12 이상: 폰이 바깥 모서리를 깎아 주니 사진은 그대로 (두 번 깎이면 틈이 생김)
                val r = if (tall && android.os.Build.VERSION.SDK_INT >= 31) 0f else radiusDp * w / vw
                c.clipPath(Path().apply {
                    addRoundRect(RectF(0f, 0f, w.toFloat(), bh.toFloat()),
                        floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), Path.Direction.CW)
                })
                c.drawBitmap(src, Rect(left, top, left + w, top + bh), Rect(0, 0, w, bh), Paint(Paint.FILTER_BITMAP_FLAG))
                if (tall) {
                    // 세로 위젯: 글자가 사진 밖(아래 크림 칸)이라 위쪽만 살짝 (Paransori · ⋮ 잘 보이게)
                    c.drawRect(0f, 0f, w.toFloat(), bh.toFloat(), Paint().apply {
                        shader = LinearGradient(0f, 0f, 0f, bh * 0.45f,
                            0x47000000, 0x00000000, Shader.TileMode.CLAMP)
                    })
                } else {
                    c.drawRect(0f, 0f, w.toFloat(), bh.toFloat(), Paint().apply {
                        shader = LinearGradient(0f, bh * 0.25f, 0f, bh.toFloat(),
                            0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
                    })
                }
                src.recycle()
                out
            } catch (e: Exception) {
                null
            }
        }
    }
}
