// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Paransori';

  @override
  String get songs => 'Songs';

  @override
  String get albums => 'Albums';

  @override
  String get artists => 'Artists';

  @override
  String get playlists => 'Playlists';

  @override
  String get folders => 'Folders';

  @override
  String get videos => 'Videos';

  @override
  String get settings => 'Settings';

  @override
  String get search => 'Search';

  @override
  String get favorites => 'Favorites';

  @override
  String get recent => 'Recent';

  @override
  String get all => 'All';

  @override
  String get play => 'Play';

  @override
  String get pause => 'Pause';

  @override
  String get next => 'Next';

  @override
  String get previous => 'Previous';

  @override
  String get shuffle => 'Shuffle';

  @override
  String get repeat => 'Repeat';

  @override
  String get nowPlaying => 'Playing';

  @override
  String get noSongs => 'No MP3 files found';

  @override
  String get addMusic => 'Add music files to your device';

  @override
  String get scanningMusic => 'Scanning music...';

  @override
  String get editSong => 'Edit Song Info';

  @override
  String get save => 'Save';

  @override
  String get cancel => 'Cancel';

  @override
  String get delete => 'Delete';

  @override
  String get title => 'Title';

  @override
  String get artist => 'Artist';

  @override
  String get album => 'Album';

  @override
  String get share => 'Share';

  @override
  String get songInfo => 'Song Info';

  @override
  String get equalizer => 'Equalizer';

  @override
  String get sleepTimer => 'Sleep Timer';

  @override
  String get playbackSpeed => 'Playback Speed';

  @override
  String get repeatMode => 'Repeat Mode';

  @override
  String get noRepeat => 'No Repeat';

  @override
  String get repeatOne => 'Repeat One';

  @override
  String get repeatAll => 'Repeat All';

  @override
  String get textSize => 'Text Size';

  @override
  String get fontChange => 'Font Change';

  @override
  String get playerStyle => 'Player Style';

  @override
  String get flashlight => 'Flashlight';

  @override
  String get sos => 'SOS Emergency Light';

  @override
  String get ringtone => 'Set Ringtone';

  @override
  String get widget => 'Home Widget';

  @override
  String get version => 'Version Info';

  @override
  String get promoCode => 'Promo Code';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get termsOfService => 'Terms of Service';

  @override
  String get noRecentSongs => 'No recently played songs';

  @override
  String get playMusic => 'Play some music';

  @override
  String get clearRecent => 'Clear Recent Songs';

  @override
  String get clearRecentConfirm => 'Clear all recently played songs?';

  @override
  String get playAll => 'Play All';

  @override
  String get noAlbums => 'No albums found';

  @override
  String get noArtists => 'No artists found';

  @override
  String get searchAlbums => 'Search albums...';

  @override
  String get searchArtists => 'Search artists...';

  @override
  String get close => 'Close';

  @override
  String get defaultValue => 'Default';

  @override
  String get preview => 'Preview';

  @override
  String get playing => 'Playing...';

  @override
  String get ringtoneFailed => 'Failed to set ringtone';

  @override
  String get promoInvalid => 'Invalid promo code';

  @override
  String get promoEnter => 'Enter promo code';

  @override
  String get confirm => 'Confirm';

  @override
  String get permissionRequired => 'Storage Permission Required';

  @override
  String get permissionMessage =>
      'Storage permission is required\nto scan MP3 files.';

  @override
  String get allowPermission => 'Allow Permission';

  @override
  String get retry => 'Retry';

  @override
  String get deleteSong => 'Delete Song';

  @override
  String get deleted => 'Deleted';

  @override
  String get deleteFailed => 'Delete failed';

  @override
  String get playNext => 'Play Next';

  @override
  String get searchHint => 'Search songs, artists, albums...';

  @override
  String get timerCancel => 'Cancel Timer';

  @override
  String get set => 'Set';

  @override
  String get small => 'Small';

  @override
  String get large => 'Large';

  @override
  String get apply => 'Apply';

  @override
  String get songCount => 'songs';

  @override
  String get on => 'On';

  @override
  String get off => 'Off';

  @override
  String get flashlightError => 'Flashlight error';

  @override
  String get minuteShort => 'min';

  @override
  String get hourShort => 'hr';

  @override
  String get privacyPolicyUrl => 'https://www.ssing.kr/privacy_policy_en.html';

  @override
  String get termsOfServiceUrl =>
      'https://www.ssing.kr/terms_of_service_en.html';

  @override
  String get preset => 'Preset';

  @override
  String get bassBooster => 'Bass Booster';

  @override
  String get enhancesBass => 'Enhances bass sound';

  @override
  String get virtualizer => 'Virtualizer';

  @override
  String get surroundEffect => 'Creates surround sound effect';

  @override
  String get reset => 'Reset';

  @override
  String get reviewTitle => 'Do you enjoy Paransori?';

  @override
  String get reviewMessage =>
      'Please leave a rating!\nIt helps us improve the app 😊';

  @override
  String get reviewButton => '⭐ Leave a Rating';

  @override
  String get reviewLater => 'Maybe Later';

  @override
  String get fontDefault => 'Default Font';

  @override
  String get fontNotoSans => 'Noto Sans KR (Clean)';

  @override
  String get fontJua => 'Jua (Cute)';

  @override
  String get fontGaegu => 'Gaegu (Handwriting)';

  @override
  String get fontNanumGothic => 'Nanum Gothic (Soft)';

  @override
  String get fontDoHyeon => 'Do Hyeon (Modern)';

  @override
  String get fontCuteFont => 'Cute Font (Cute)';

  @override
  String get fontStylish => 'Stylish (Elegant)';

  @override
  String get fontSunflower => 'Sunflower (Light)';

  @override
  String get fontHiMelody => 'Hi Melody (Emotional)';

  @override
  String get fontPoorStory => 'Poor Story (Handwriting)';

  @override
  String get fontEastSeaDokdo => 'East Sea Dokdo (Unique)';

  @override
  String get fontNanumBrush => 'Nanum Brush Script (Brush)';

  @override
  String get fontNanumMyeongjo => 'Nanum Myeongjo (Serif)';

  @override
  String get fontBlackAndWhite => 'Black And White Picture (Special)';

  @override
  String get fontGowunDodum => 'Gowun Dodum (Round)';

  @override
  String get fontGowunBatang => 'Gowun Batang (Batang)';

  @override
  String get fontNanumPen => 'Nanum Pen Script (Pen)';

  @override
  String get fontSingleDay => 'Single Day (Cute)';

  @override
  String get fontYeonSung => 'Yeon Sung (Soft)';

  @override
  String get styleCD => 'CD Rotation';

  @override
  String get styleCard => 'Album Art Card';

  @override
  String get hourWord => 'hr';

  @override
  String autoStopFormat(Object time) {
    return 'Turns off automatically in $time';
  }

  @override
  String get autoStopCountdownSuffix => 'until auto stop';

  @override
  String get secondShort => 'sec';

  @override
  String get unknownArtist => 'Unknown Artist';

  @override
  String get unknownAlbum => 'Unknown Album';

  @override
  String get noTitle => 'No Title';

  @override
  String selectedCount(Object count) {
    return '$count selected';
  }

  @override
  String get selectAll => 'Select All';

  @override
  String get noVideosFound => 'No videos found';

  @override
  String get rename => 'Rename';

  @override
  String get playTime => 'Duration';

  @override
  String get path => 'Path';

  @override
  String get playlistNameHint => 'Playlist name';

  @override
  String get create => 'Create';

  @override
  String get playlistLabel => 'Playlist';

  @override
  String get change => 'Change';

  @override
  String get songCountSuffix => 'songs';

  @override
  String get lyrics => 'Lyrics';

  @override
  String get lyricsLoading => 'Loading lyrics...';

  @override
  String get lyricsErrorNotFound => 'Lyrics not found';

  @override
  String get lyricsErrorNetwork => 'Please check your internet connection';

  @override
  String get justNow => 'Just now';

  @override
  String minutesAgo(Object minutes) {
    return '${minutes}m ago';
  }

  @override
  String hoursAgo(Object hours) {
    return '${hours}h ago';
  }

  @override
  String dateFormat(Object day, Object month, Object year) {
    return '$year-$month-$day';
  }

  @override
  String get radioTitle => 'Radio';

  @override
  String get radioRecentListening => 'Recently Listened';

  @override
  String get radioSelectCountry => 'Select Country';

  @override
  String get radioChannelCount => 'channels';

  @override
  String get radioPopular200 => 'Popular 200';

  @override
  String get radioSleep => 'Sleep';

  @override
  String get radioSchedule => 'Schedule';

  @override
  String get sleepTimerDesc =>
      'Turns off automatically after the selected time';

  @override
  String get sleepTimerActiveDesc => 'Timer is running';

  @override
  String get remainingTime => 'Time Remaining';

  @override
  String get cancelTimerX => '× Cancel Timer';

  @override
  String get countryKR => 'Korea';

  @override
  String get countryUS => 'USA';

  @override
  String get countryJP => 'Japan';

  @override
  String get countryTW => 'Taiwan';

  @override
  String get countryCN => 'China';

  @override
  String get countryHK => 'Hong Kong';

  @override
  String get countryGB => 'UK';

  @override
  String get countryVN => 'Vietnam';

  @override
  String get countryPH => 'Philippines';

  @override
  String get countryDE => 'Germany';

  @override
  String get countryFR => 'France';

  @override
  String get countryTH => 'Thailand';

  @override
  String get countryID => 'Indonesia';

  @override
  String get countryIN => 'India';

  @override
  String get countryES => 'Spain';

  @override
  String get countryIT => 'Italy';

  @override
  String get countryBR => 'Brazil';

  @override
  String get countryCA => 'Canada';

  @override
  String get countryAU => 'Australia';

  @override
  String get countryMX => 'Mexico';

  @override
  String get countryTR => 'Turkey';

  @override
  String get countryNL => 'Netherlands';

  @override
  String get countrySE => 'Sweden';

  @override
  String get countryPL => 'Poland';

  @override
  String get countryAR => 'Argentina';

  @override
  String get countryCO => 'Colombia';

  @override
  String get countryNZ => 'New Zealand';

  @override
  String get countryMY => 'Malaysia';

  @override
  String get countrySG => 'Singapore';

  @override
  String get countryRU => 'Russia';

  @override
  String get countryZA => 'South Africa';

  @override
  String get countryPK => 'Pakistan';

  @override
  String get countryBD => 'Bangladesh';

  @override
  String get countryLK => 'Sri Lanka';

  @override
  String get countryNP => 'Nepal';

  @override
  String get countryMM => 'Myanmar';

  @override
  String get countryKH => 'Cambodia';

  @override
  String get countryAT => 'Austria';

  @override
  String get countryCH => 'Switzerland';

  @override
  String get countryBE => 'Belgium';

  @override
  String get countryPT => 'Portugal';

  @override
  String get countryGR => 'Greece';

  @override
  String get countryIE => 'Ireland';

  @override
  String get countryNO => 'Norway';

  @override
  String get countryDK => 'Denmark';

  @override
  String get countryFI => 'Finland';

  @override
  String get countryCZ => 'Czech Republic';

  @override
  String get countryRO => 'Romania';

  @override
  String get countryUA => 'Ukraine';

  @override
  String get countryEG => 'Egypt';

  @override
  String get countrySA => 'Saudi Arabia';

  @override
  String get countryAE => 'UAE';

  @override
  String get countryNG => 'Nigeria';

  @override
  String get countryKE => 'Kenya';

  @override
  String get countryCL => 'Chile';

  @override
  String get countryPE => 'Peru';

  @override
  String get countryVE => 'Venezuela';

  @override
  String get countryCU => 'Cuba';

  @override
  String get countryJM => 'Jamaica';

  @override
  String get countryIQ => 'Iraq';

  @override
  String get countryIR => 'Iran';

  @override
  String get countryIL => 'Israel';

  @override
  String get countryMN => 'Mongolia';

  @override
  String get countryUZ => 'Uzbekistan';

  @override
  String get countryKZ => 'Kazakhstan';

  @override
  String get countryLA => 'Laos';

  @override
  String get countryHU => 'Hungary';

  @override
  String get countryHR => 'Croatia';

  @override
  String get countryRS => 'Serbia';

  @override
  String get countryBG => 'Bulgaria';

  @override
  String get countrySK => 'Slovakia';

  @override
  String get countryLT => 'Lithuania';

  @override
  String get countryLV => 'Latvia';

  @override
  String get countryEE => 'Estonia';

  @override
  String get countryIS => 'Iceland';

  @override
  String get countryGH => 'Ghana';

  @override
  String get countryTZ => 'Tanzania';

  @override
  String get countryMA => 'Morocco';

  @override
  String get countryTN => 'Tunisia';

  @override
  String get countryET => 'Ethiopia';

  @override
  String get countryUG => 'Uganda';

  @override
  String get countryEC => 'Ecuador';

  @override
  String get countryBO => 'Bolivia';

  @override
  String get countryPY => 'Paraguay';

  @override
  String get countryUY => 'Uruguay';

  @override
  String get countryPA => 'Panama';

  @override
  String get countryCR => 'Costa Rica';

  @override
  String get countryDO => 'Dominican Republic';

  @override
  String get countryTT => 'Trinidad and Tobago';

  @override
  String get countryHT => 'Haiti';

  @override
  String get countryFJ => 'Fiji';

  @override
  String get countryPG => 'Papua New Guinea';

  @override
  String get countryJO => 'Jordan';

  @override
  String get countryLB => 'Lebanon';

  @override
  String get countryGE => 'Georgia';

  @override
  String get countryAM => 'Armenia';

  @override
  String get countryAZ => 'Azerbaijan';

  @override
  String get countrySI => 'Slovenia';

  @override
  String get countryAL => 'Albania';

  @override
  String get countryMK => 'North Macedonia';

  @override
  String get countryME => 'Montenegro';

  @override
  String get countryBA => 'Bosnia';

  @override
  String get countryMT => 'Malta';

  @override
  String get countryLU => 'Luxembourg';

  @override
  String get countryCY => 'Cyprus';

  @override
  String get countryCM => 'Cameroon';

  @override
  String get countrySN => 'Senegal';

  @override
  String get countryZW => 'Zimbabwe';

  @override
  String get countryMZ => 'Mozambique';

  @override
  String get countryMG => 'Madagascar';

  @override
  String get countryGT => 'Guatemala';

  @override
  String get countryHN => 'Honduras';

  @override
  String get countryNI => 'Nicaragua';

  @override
  String get countrySV => 'El Salvador';

  @override
  String get countryPR => 'Puerto Rico';

  @override
  String get categoryNational => 'National';

  @override
  String get categorySeoulGyeonggi => 'Seoul/Gyeonggi';

  @override
  String get categoryRegionalMBC => 'Regional MBC';

  @override
  String get categoryRegionalPrivate => 'Regional Private';

  @override
  String get categoryTraffic => 'Traffic Broadcasting';

  @override
  String get categoryEtc => 'Others';

  @override
  String get regionAll => 'All';

  @override
  String get regionCapital => 'Capital Area';

  @override
  String get regionBusanGyeongnam => 'Busan/Gyeongnam';

  @override
  String get regionDaeguGyeongbuk => 'Daegu/Gyeongbuk';

  @override
  String get regionGwangjuJeonnam => 'Gwangju/Jeonnam';

  @override
  String get regionJeonbuk => 'Jeonbuk';

  @override
  String get regionDaejeonChungnam => 'Daejeon/Chungnam';

  @override
  String get regionChungbuk => 'Chungbuk';

  @override
  String get regionGangwon => 'Gangwon';

  @override
  String get regionJeju => 'Jeju';

  @override
  String get radioNoFavorites => 'No favorites yet';

  @override
  String get radioNoFavoritesDesc => 'Tap ♡ on a channel to add it';

  @override
  String get radioLoadingPopular => 'Loading popular stations...';

  @override
  String radioScheduleTitle(Object station) {
    return '$station Schedule';
  }

  @override
  String get radioLoadingSchedule => 'Loading schedule...';

  @override
  String get radioBroadcastSchedule => 'Schedule';

  @override
  String get radioPlayFirst => 'Please play a radio station first';

  @override
  String radioScheduleCompleteToast(Object time, Object title) {
    return '$title $time scheduled';
  }

  @override
  String get radioPlaybackFailed => 'Playback failed.';

  @override
  String get radioRerun => 'Rerun';

  @override
  String get radioLive => '● LIVE';

  @override
  String get radioStatusConnecting => 'Connecting...';

  @override
  String get radioStatusFailed => 'Connection failed';

  @override
  String get radioStatusPaused => 'Paused';

  @override
  String get radioAfterEnd => 'until stop';

  @override
  String get radioNoStationsFound => 'No stations found';

  @override
  String get sleepMin => 'min';

  @override
  String get sleepHour => 'hr';

  @override
  String sleepMinuteUnit(Object minutes) {
    return '$minutes min';
  }

  @override
  String sleepHourUnit(Object hours) {
    return '$hours hr';
  }

  @override
  String sleepHourMinuteUnit(Object hours, Object minutes) {
    return '$hours hr $minutes min';
  }

  @override
  String sleepCountdownHMS(Object hours, Object minutes, Object seconds) {
    return '${hours}h ${minutes}m ${seconds}s';
  }

  @override
  String sleepCountdownMS(Object minutes, Object seconds) {
    return '${minutes}m ${seconds}s';
  }

  @override
  String sleepCountdownS(Object seconds) {
    return '${seconds}s';
  }

  @override
  String sleepAutoStopToast(Object time) {
    return 'Turns off automatically in $time';
  }

  @override
  String get radioKoreaTitle => 'Korea Radio';

  @override
  String get radioOnAirTitle => 'ON AIR';

  @override
  String get radioKoreaSlogan => 'Sounds from Around the World';

  @override
  String get radioSloganUS => 'The Voice of Freedom';

  @override
  String get radioSloganJP => 'A Little Comfort in Daily Life';

  @override
  String get radioSloganTW => 'Songs Flowing Through the Island';

  @override
  String get radioSloganCN => 'Sounds of a Vast Land';

  @override
  String get radioSloganHK => 'Riding the City\'s Rhythm';

  @override
  String get radioSloganGB => 'Where Tradition Meets the Present';

  @override
  String get radioSloganVN => 'Melodies of the Mekong';

  @override
  String get radioSloganPH => 'Sounds of the Islands';

  @override
  String get radioSloganDE => 'Sounds from the Heart of Europe';

  @override
  String get radioSloganFR => 'Melodies of Life';

  @override
  String get radioSloganTH => 'Sounds of Siam';

  @override
  String get radioSloganID => 'Rhythms of the Archipelago';

  @override
  String get radioSloganIN => 'Tunes of India';

  @override
  String get radioSloganES => 'Rhythms of the Soul';

  @override
  String get radioSloganIT => 'The Music of Life';

  @override
  String get radioSloganBR => 'The Sound of Brazil';

  @override
  String get radioSloganCA => 'Voices Across the North';

  @override
  String get radioSloganAU => 'Sounds Down Under';

  @override
  String get radioSloganMX => 'The Rhythm of Mexico';

  @override
  String get radioSloganTR => 'Voice of Anatolia';

  @override
  String get radioSloganNL => 'Sounds of the Lowlands';

  @override
  String get radioSloganSE => 'Sounds from the North';

  @override
  String get radioSloganPL => 'Melodies of the Vistula';

  @override
  String get radioSloganAR => 'Tango of the Soul';

  @override
  String get radioSloganCO => 'Rhythms of Colombia';

  @override
  String get radioSloganNZ => 'Echoes of Aotearoa';

  @override
  String get radioSloganMY => 'Rhythms of Malaysia';

  @override
  String get radioSloganSG => 'The Lion City Vibes';

  @override
  String get radioSloganRU => 'Sounds of Russia';

  @override
  String get radioSloganZA => 'Sounds of the Rainbow Nation';

  @override
  String get radioSloganPK => 'Melodies of Pakistan';

  @override
  String get radioSloganBD => 'Sounds of Bengal';

  @override
  String get radioSloganLK => 'Sounds of Sri Lanka';

  @override
  String get radioSloganNP => 'Tunes of the Himalayas';

  @override
  String get radioSloganMM => 'Sounds of Myanmar';

  @override
  String get radioSloganKH => 'Sounds of Angkor';

  @override
  String get radioSloganAT => 'Echoes of the Alps';

  @override
  String get radioSloganCH => 'Voices of Switzerland';

  @override
  String get radioSloganBE => 'Sounds of Belgium';

  @override
  String get radioSloganPT => 'Sounds of Portugal';

  @override
  String get radioSloganGR => 'Sounds of Greece';

  @override
  String get radioSloganIE => 'Sounds of the Emerald Isle';

  @override
  String get radioSloganNO => 'Sounds of the Fjords';

  @override
  String get radioSloganDK => 'Sounds of Denmark';

  @override
  String get radioSloganFI => 'Sounds of Finland';

  @override
  String get radioSloganCZ => 'Sounds of Bohemia';

  @override
  String get radioSloganRO => 'Sounds of Romania';

  @override
  String get radioSloganUA => 'Sounds of Ukraine';

  @override
  String get radioSloganEG => 'Sounds of the Nile';

  @override
  String get radioSloganSA => 'Sounds of Arabia';

  @override
  String get radioSloganAE => 'Sounds of the Gulf';

  @override
  String get radioSloganNG => 'Sounds of Naija';

  @override
  String get radioSloganKE => 'Sounds of Kenya';

  @override
  String get radioSloganCL => 'Sounds of Chile';

  @override
  String get radioSloganPE => 'Sounds of Peru';

  @override
  String get radioSloganVE => 'Rhythms of Venezuela';

  @override
  String get radioSloganCU => 'Rhythms of Cuba';

  @override
  String get radioSloganJM => 'Riddims of Jamaica';

  @override
  String get radioSloganIQ => 'Sounds of Mesopotamia';

  @override
  String get radioSloganIR => 'Melodies of Iran';

  @override
  String get radioSloganIL => 'Sounds of Israel';

  @override
  String get radioSloganMN => 'Melodies of the Steppe';

  @override
  String get radioSloganUZ => 'Sounds of Uzbekistan';

  @override
  String get radioSloganKZ => 'Sounds of Kazakhstan';

  @override
  String get radioSloganLA => 'Sounds of Laos';

  @override
  String get radioSloganHU => 'Sounds of the Danube';

  @override
  String get radioSloganHR => 'Sounds of the Adriatic';

  @override
  String get radioSloganRS => 'Sounds of Serbia';

  @override
  String get radioSloganBG => 'Sounds of Bulgaria';

  @override
  String get radioSloganSK => 'Sounds of Slovakia';

  @override
  String get radioSloganLT => 'Sounds of Lithuania';

  @override
  String get radioSloganLV => 'Sounds of Latvia';

  @override
  String get radioSloganEE => 'Sounds of Estonia';

  @override
  String get radioSloganIS => 'Sounds of Iceland';

  @override
  String get radioSloganGH => 'Sounds of Ghana';

  @override
  String get radioSloganTZ => 'Sounds of Tanzania';

  @override
  String get radioSloganMA => 'Sounds of Morocco';

  @override
  String get radioSloganTN => 'Sounds of Tunisia';

  @override
  String get radioSloganET => 'Sounds of Ethiopia';

  @override
  String get radioSloganUG => 'Sounds of Uganda';

  @override
  String get radioSloganEC => 'Sounds of Ecuador';

  @override
  String get radioSloganBO => 'Sounds of Bolivia';

  @override
  String get radioSloganPY => 'Sounds of Paraguay';

  @override
  String get radioSloganUY => 'Sounds of Uruguay';

  @override
  String get radioSloganPA => 'Sounds of Panama';

  @override
  String get radioSloganCR => 'Sounds of Costa Rica';

  @override
  String get radioSloganDO => 'Dominican Rhythms';

  @override
  String get radioSloganTT => 'Sounds of Trinidad';

  @override
  String get radioSloganHT => 'Sounds of Haiti';

  @override
  String get selectSong => 'Select Song';

  @override
  String get selectRange => 'Select Range';

  @override
  String get start => 'Start';

  @override
  String get end => 'End';

  @override
  String get deselectAll => 'Deselect All';

  @override
  String get exit => 'Exit';

  @override
  String get timerLabel => 'Timer';

  @override
  String get playbackSpeedLabel => 'Speed';

  @override
  String get updateReadyTitle => 'Update Ready';

  @override
  String get updateReadyMessage =>
      'New features have been downloaded.\nRestarting now is recommended.';

  @override
  String get updateReadyButton => 'Restart Now';

  @override
  String get updateReadyLater => 'Later';

  @override
  String get radioNextProgram => 'Next';

  @override
  String get radioExitConfirmTitle => 'Exit the radio?';

  @override
  String get radioExitConfirmMessage => 'Leaving now will stop playback.';

  @override
  String get radioExitKeepListening => 'Keep listening';

  @override
  String get radioExitConfirmButton => 'Exit';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get darkModeOn => 'On';

  @override
  String get darkModeOff => 'Off';

  @override
  String get rateApp => 'Rate App';

  @override
  String get musicExitConfirmTitle => 'Stop playing music?';

  @override
  String get musicExitConfirmMessage => 'Playback will stop if you leave now.';

  @override
  String get homeNewSongs => 'New songs';

  @override
  String get homeTipWidgetTitle => 'Add the home screen widget';

  @override
  String get homeTipWidgetSub => 'Long-press home screen → Widgets';

  @override
  String get homeTipAlarmTitle => 'Wake up with Paransori';

  @override
  String get homeTipAlarmSub => 'Music, radio or nature sounds';

  @override
  String get homeTipScheduleTitle => 'Schedule the radio';

  @override
  String get homeTipScheduleSub => 'Tap Schedule under the radio player';

  @override
  String get homeTipCastTitle => 'Play on your TV or speaker';

  @override
  String get homeTipCastSub => 'Same Wi-Fi → player ⋮ menu';

  @override
  String get homeTipSleepTitle => 'Sleep timer for bedtime';

  @override
  String get homeTipSleepSub => 'Tap Sleep under the player';

  @override
  String get homeTodayTip => 'TIP';

  @override
  String get accentColor => 'Accent color';

  @override
  String get homeColorTitle => 'Make it your color';

  @override
  String get homeColorSub => '10 colors like Forest, Sunset, Blossom';

  @override
  String get homeColorAction => 'Try it';

  @override
  String get homeColorQuestion => 'Pick a color for today';

  @override
  String get homeColorHint => 'You can change it again\nanytime in Settings.';

  @override
  String get done => 'Done';

  @override
  String get homeStartTitle => 'Set as start screen?';

  @override
  String get homeStartMessage =>
      'This screen will open first when you start Paransori.';

  @override
  String get homeStartConfirm => 'Set';

  @override
  String deleteSongsTitle(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Delete $count songs?',
      one: 'Delete 1 song?',
    );
    return '$_temp0';
  }

  @override
  String get deleteSongsMessage =>
      'The selected songs will be deleted from your phone.';

  @override
  String deletedSongsToast(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Deleted $count songs',
      one: 'Deleted 1 song',
    );
    return '$_temp0';
  }

  @override
  String get couldNotDelete => 'Couldn\'t delete';

  @override
  String get menuShareTitle => 'Share with friends';

  @override
  String get menuShareSub => 'Tell your friends\nabout Paransori.';

  @override
  String get shareAppMessage => 'I\'m listening to music on Paransori! 🎧';

  @override
  String get menuRateTitle => 'Rate the app';

  @override
  String get menuRateSub => 'Your rating\nmeans a lot to us.';

  @override
  String get menuSettingsSub => 'Adjust the app\nto your liking.';

  @override
  String get menuRadioTitle => 'Radio stations';

  @override
  String get menuRadioSub => 'Listen to radio\nfrom around the world.';

  @override
  String get recentSearches => 'Recent searches';

  @override
  String get clearAll => 'Clear all';

  @override
  String get catMusic => 'Music';

  @override
  String get catMusicSub => 'My music · MP3 player';

  @override
  String get catRadio => 'Radio';

  @override
  String get catRadioSub => 'World radio · Favorites';

  @override
  String get catNature => 'Nature';

  @override
  String get catNatureSub => 'Rain · Wind · Forest · Waves';

  @override
  String get catRest => 'Rest · Focus';

  @override
  String get catRestSub => 'White noise · Focus (soon)';

  @override
  String get homeSoundsHeader => 'How about these sounds?';

  @override
  String get homeRestHeader => 'Take a short break';

  @override
  String get homeRecentHeader => 'Recently played';

  @override
  String get homeRecentEmpty => 'Nothing played yet';

  @override
  String get homeRecentEmptySub => 'Anything played for 30s+ shows up here';

  @override
  String get cleanLabel => 'Clean up';

  @override
  String cleanTitle(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Tidy up $count song titles',
      one: 'Tidy up 1 song title',
    );
    return '$_temp0';
  }

  @override
  String get later => 'Later';

  @override
  String get cleanAction => 'Clean up';

  @override
  String get dailyOftenMorning => 'Your morning favorite';

  @override
  String get dailyOftenDay => 'Your daytime favorite';

  @override
  String get dailyOftenEvening => 'Your evening favorite';

  @override
  String get dailyOftenNight => 'Your late-night favorite';

  @override
  String get dailyLongTime => 'Long time no listen';

  @override
  String get dailySongOfDay => 'Song of the day';

  @override
  String get dailyHowAboutThis => 'How about this one today';

  @override
  String get listen => 'Play';

  @override
  String get dailyListenAgain => 'Listen again';

  @override
  String dailyNotPlayedTitle(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count songs unplayed for a month',
      one: '1 song unplayed for a month',
    );
    return '$_temp0';
  }

  @override
  String get dailyNotPlayedSub => 'Give them another listen?';

  @override
  String get dailyShufflePlay => 'Shuffle';

  @override
  String get dailyMyStats => 'My stats';

  @override
  String dailyWeekCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Played $count times in the last 7 days',
      one: 'Played once in the last 7 days',
    );
    return '$_temp0';
  }

  @override
  String get dailyMostPlayed => 'Most played';

  @override
  String get dailyMorningTitle => 'Good morning';

  @override
  String get dailyMorningLine => 'Start your day with birdsong';

  @override
  String get dailyDayTitle => 'Take a short break';

  @override
  String get dailyDayLine => 'Unwind with a flowing stream';

  @override
  String get dailyEveningTitle => 'You did great today';

  @override
  String get dailyEveningLine => 'Relax to the sound of waves';

  @override
  String get dailyNightTitle => 'Keep it calm tonight';

  @override
  String get dailyNightLine => 'Relax to the sound of rain';

  @override
  String get dailyRightNow => 'Right now';

  @override
  String get dailyTipBatteryTitle => 'Keep playing with the screen off';

  @override
  String get dailyTipBatterySub => 'Set battery to \'Unrestricted\'';

  @override
  String get dailyTipRingtoneTitle => 'Make a song your ringtone';

  @override
  String get dailyTipRingtoneSub => 'From the song\'s ⋮ menu';

  @override
  String get dailyTipVideoTitle => 'Save audio from videos';

  @override
  String get dailyTipVideoSub => 'Video ⋮ menu → \'Save as music\'';

  @override
  String get dailyTipMixTitle => 'Add rain to your music';

  @override
  String get dailyTipMixSub => 'Player ⋮ menu → Nature sound mix';

  @override
  String get dailyTipLyricsTitle => 'Share a line of lyrics';

  @override
  String get dailyTipLyricsSub => 'Long-press lyrics to share as a card';

  @override
  String get dailyOffTitle => 'Turn off the daily card?';

  @override
  String get dailyOffMessage => 'You can turn it back on anytime in Settings.';

  @override
  String get turnOff => 'Turn off';

  @override
  String get dailyOffKeep => 'Keep it';

  @override
  String get callRecordingsChip => 'Calls ›';

  @override
  String get sortedByArtist => 'Sorted by artist';

  @override
  String get sortedByTitle => 'Sorted by title';

  @override
  String get sortArtist => 'Artist';

  @override
  String get sortTitle => 'Title';

  @override
  String get today => 'Today';

  @override
  String get yesterday => 'Yesterday';

  @override
  String get within3Days => 'Last 3 days';

  @override
  String get withinWeek => 'Last 7 days';

  @override
  String get colorParansori => 'Paransori';

  @override
  String get colorForest => 'Forest';

  @override
  String get colorSunset => 'Sunset';

  @override
  String get colorLavender => 'Lavender';

  @override
  String get colorInk => 'Ink';

  @override
  String get colorBlossom => 'Blossom';

  @override
  String get colorOcean => 'Ocean';

  @override
  String get colorSunlight => 'Sunlight';

  @override
  String get colorWine => 'Wine';

  @override
  String get colorNightSky => 'Night sky';
}
