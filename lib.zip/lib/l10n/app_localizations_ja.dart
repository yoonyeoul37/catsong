// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Japanese (`ja`).
class AppLocalizationsJa extends AppLocalizations {
  AppLocalizationsJa([String locale = 'ja']) : super(locale);

  @override
  String get appName => 'Paransori';

  @override
  String get songs => '曲';

  @override
  String get albums => 'アルバム';

  @override
  String get artists => '歌手';

  @override
  String get playlists => '再生リスト';

  @override
  String get folders => 'フォルダ';

  @override
  String get videos => '動画';

  @override
  String get settings => '設定';

  @override
  String get search => '検索';

  @override
  String get favorites => 'お気に入り';

  @override
  String get recent => '最近';

  @override
  String get all => 'すべて';

  @override
  String get play => '再生';

  @override
  String get pause => '一時停止';

  @override
  String get next => '次へ';

  @override
  String get previous => '前へ';

  @override
  String get shuffle => 'シャッフル';

  @override
  String get repeat => 'リピート';

  @override
  String get nowPlaying => '再生中';

  @override
  String get noSongs => 'MP3ファイルが見つかりません';

  @override
  String get addMusic => 'デバイスに音楽ファイルを追加してください';

  @override
  String get scanningMusic => '音楽をスキャン中...';

  @override
  String get editSong => '曲情報を編集';

  @override
  String get save => '保存';

  @override
  String get cancel => 'キャンセル';

  @override
  String get delete => '削除';

  @override
  String get title => 'タイトル';

  @override
  String get artist => 'アーティスト';

  @override
  String get album => 'アルバム';

  @override
  String get addToPlaylist => 'プレイリストに追加';

  @override
  String get addToFavorites => 'お気に入りに追加';

  @override
  String get removeFromFavorites => 'お気に入りから削除';

  @override
  String get setRingtone => '着信音に設定';

  @override
  String get share => '共有';

  @override
  String get songInfo => '曲情報';

  @override
  String get equalizer => 'イコライザー';

  @override
  String get sleepTimer => 'スリープタイマー';

  @override
  String get playbackSpeed => '再生速度';

  @override
  String get repeatMode => 'リピートモード';

  @override
  String get noRepeat => 'リピートなし';

  @override
  String get repeatOne => '1曲リピート';

  @override
  String get repeatAll => '全曲リピート';

  @override
  String get themeColor => 'テーマカラー';

  @override
  String get textSize => '文字サイズ';

  @override
  String get fontChange => 'フォント変更';

  @override
  String get playerStyle => 'プレイヤースタイル';

  @override
  String get flashlight => '懐中電灯';

  @override
  String get sos => 'SOS緊急ライト';

  @override
  String get ringtone => '着信音設定';

  @override
  String get widget => 'ホームウィジェット';

  @override
  String get version => 'バージョン情報';

  @override
  String get promoCode => 'プロモコード';

  @override
  String get privacyPolicy => 'プライバシーポリシー';

  @override
  String get termsOfService => '利用規約';

  @override
  String get noRecentSongs => '最近再生した曲はありません';

  @override
  String get playMusic => '音楽を再生してみてください';

  @override
  String get clearAll => 'すべて削除';

  @override
  String get clearRecent => '最近の再生をすべて削除';

  @override
  String get clearRecentConfirm => '最近の再生リストをすべて削除しますか？';

  @override
  String get playAll => 'すべて再生';

  @override
  String get addedToFavorites => 'お気に入りに追加しました';

  @override
  String get removedFromFavorites => 'お気に入りから削除しました';

  @override
  String get songSaved => '曲情報を保存しました';

  @override
  String get swipeToChange => 'スワイプで曲を変更';

  @override
  String get noAlbums => 'アルバムがありません';

  @override
  String get noArtists => 'アーティストがありません';

  @override
  String get searchAlbums => 'アルバムを検索...';

  @override
  String get searchArtists => 'アーティストを検索...';

  @override
  String get close => '閉じる';

  @override
  String get defaultValue => 'デフォルト';

  @override
  String get preview => 'プレビュー';

  @override
  String get playing => '再生中...';

  @override
  String get ringtoneSet => '着信音を設定しました！🎵';

  @override
  String get ringtoneFailed => '着信音の設定に失敗しました';

  @override
  String get promoUnlocked => '🎉 広告が削除されました！';

  @override
  String get promoInvalid => '無効なコードです';

  @override
  String get promoEnter => 'プロモコードを入力してください';

  @override
  String get confirm => '確認';

  @override
  String get permissionRequired => 'ストレージの許可が必要です';

  @override
  String get permissionMessage => 'MP3ファイルをスキャンするには\nストレージの許可が必要です。';

  @override
  String get allowPermission => '許可する';

  @override
  String get retry => '再試行';

  @override
  String get deleteSong => '曲を削除';

  @override
  String get deleteSongConfirm => 'この曲を削除しますか？\n端末から完全に削除されます。';

  @override
  String get deleted => '削除しました';

  @override
  String get deleteFailed => '削除に失敗しました';

  @override
  String get playNext => '次に再生';

  @override
  String get addedToQueue => '次に再生されます';

  @override
  String get noPlaylists => 'プレイリストがありません。\nプレイリストタブで作成してください。';

  @override
  String get addedToPlaylist => 'プレイリストに追加しました';

  @override
  String get searchHint => '曲、アーティスト、アルバムを検索...';

  @override
  String get timerCancel => 'タイマーをキャンセル';

  @override
  String get minutesAfterEnd => '分後に停止';

  @override
  String get hoursAfterEnd => '時間後に停止';

  @override
  String get set => '設定';

  @override
  String get small => '小さく';

  @override
  String get large => '大きく';

  @override
  String get apply => '適用';

  @override
  String get songCount => '曲';

  @override
  String get on => 'オン';

  @override
  String get off => 'オフ';

  @override
  String get sosWorking => '動作中...';

  @override
  String get flashlightError => '懐中電灯エラー';

  @override
  String get minuteShort => '分';

  @override
  String get hourShort => '時';

  @override
  String get privacyPolicyUrl => 'https://www.ssing.kr/privacy_policy_ja.html';

  @override
  String get termsOfServiceUrl =>
      'https://www.ssing.kr/terms_of_service_ja.html';

  @override
  String get preset => 'プリセット';

  @override
  String get bassBooster => 'バスブースター';

  @override
  String get enhancesBass => '低音を強化します';

  @override
  String get virtualizer => 'バーチャライザー';

  @override
  String get surroundEffect => '立体音響を作ります';

  @override
  String get reset => 'リセット';

  @override
  String get reviewTitle => 'Paransoriはいかがですか？';

  @override
  String get reviewMessage => '評価を残していただけると\nアプリ改善に大変役立ちます 😊';

  @override
  String get reviewButton => '⭐ 評価を残す';

  @override
  String get reviewLater => '後で';

  @override
  String get fontDefault => 'デフォルトフォント';

  @override
  String get fontNotoSans => 'Noto Sans KR (すっきり)';

  @override
  String get fontJua => 'Jua (かわいい)';

  @override
  String get fontGaegu => 'Gaegu (手書き)';

  @override
  String get fontNanumGothic => 'Nanum Gothic (やわらか)';

  @override
  String get fontDoHyeon => 'Do Hyeon (モダン)';

  @override
  String get fontCuteFont => 'Cute Font (かわいい)';

  @override
  String get fontStylish => 'Stylish (上品)';

  @override
  String get fontSunflower => 'Sunflower (軽い)';

  @override
  String get fontHiMelody => 'Hi Melody (感性的)';

  @override
  String get fontPoorStory => 'Poor Story (手書き)';

  @override
  String get fontEastSeaDokdo => 'East Sea Dokdo (個性的)';

  @override
  String get fontNanumBrush => 'Nanum Brush Script (筆書き)';

  @override
  String get fontNanumMyeongjo => 'Nanum Myeongjo (明朝体)';

  @override
  String get fontBlackAndWhite => 'Black And White Picture (ユニーク)';

  @override
  String get fontGowunDodum => 'Gowun Dodum (丸み)';

  @override
  String get fontGowunBatang => 'Gowun Batang (バタン体)';

  @override
  String get fontNanumPen => 'Nanum Pen Script (ペン書き)';

  @override
  String get fontSingleDay => 'Single Day (かわいい)';

  @override
  String get fontYeonSung => 'Yeon Sung (やわらか)';

  @override
  String get styleCD => 'CD回転';

  @override
  String get styleCDDesc => 'クラシックなCD回転アニメーション';

  @override
  String get styleCassette => 'カセットテープ';

  @override
  String get styleCassetteDesc => 'レトロなカセットテープスタイル';

  @override
  String get styleCard => 'アルバムアートカード';

  @override
  String get styleCardDesc => 'シンプルなアルバムアートカード';

  @override
  String get styleVisualizer => '波形ビジュアライザー';

  @override
  String get styleVisualizerDesc => '音波アニメーション';

  @override
  String get styleGradient => 'グラデーション';

  @override
  String get styleGradientDesc => 'アルバムアートカラーグラデーション背景';

  @override
  String get themeColorHint => '設定で背景色を変更できます';

  @override
  String get hourWord => '時間';

  @override
  String autoStopFormat(Object time) {
    return '$time後に自動的にオフになります';
  }

  @override
  String get autoStopCountdownSuffix => '後に自動終了';

  @override
  String get secondShort => '秒';

  @override
  String get unknownArtist => '不明なアーティスト';

  @override
  String get unknownAlbum => '不明なアルバム';

  @override
  String get noTitle => 'タイトルなし';

  @override
  String selectedCount(Object count) {
    return '$count件選択';
  }

  @override
  String get selectAll => 'すべて選択';

  @override
  String get deleteSelected => '選択を削除';

  @override
  String deleteSelectedConfirm(Object count) {
    return '$count曲を削除しますか？\n端末から完全に削除されます。';
  }

  @override
  String deletedCount(Object count) {
    return '$count件削除しました';
  }

  @override
  String get noVideosFound => '動画が見つかりません';

  @override
  String videoCount(Object count) {
    return '$count件';
  }

  @override
  String get rename => '名前を変更';

  @override
  String get deleteVideoTitle => '動画を削除';

  @override
  String deleteVideoConfirm(Object name) {
    return '$nameを削除しますか？';
  }

  @override
  String get nameChanged => '名前が変更されました';

  @override
  String renameFailed(Object error) {
    return '名前変更に失敗しました: $error';
  }

  @override
  String deleteFailedWithError(Object error) {
    return '削除に失敗しました: $error';
  }

  @override
  String get videoPermissionRequired => '動画アクセス権限が必要です';

  @override
  String get videoPermissionMessage => '動画を表示するには\nアクセス権限が必要です。';

  @override
  String get openSettings => '設定を開く';

  @override
  String deleteSongConfirmFormat(Object title) {
    return '$titleを削除しますか？\n端末から完全に削除されます。';
  }

  @override
  String get playTime => '再生時間';

  @override
  String get path => 'パス';

  @override
  String get newPlaylist => '新しいプレイリスト';

  @override
  String get playlistNameHint => 'プレイリスト名';

  @override
  String get create => '作成';

  @override
  String get playlistLabel => 'プレイリスト';

  @override
  String get renamePlaylistTitle => '名前を変更';

  @override
  String get deletePlaylistTitle => 'プレイリストを削除';

  @override
  String deletePlaylistConfirm(Object name) {
    return '$nameを削除しますか？';
  }

  @override
  String get change => '変更';

  @override
  String get songCountSuffix => '曲';

  @override
  String get lyrics => '歌詞';

  @override
  String get lyricsLoading => '歌詞を読み込み中...';

  @override
  String get lyricsNotFound => '歌詞が見つかりません';

  @override
  String get lyricsSearchPrompt => '歌詞を検索してみてください';

  @override
  String get lyricsSearchButton => '歌詞検索';

  @override
  String get lyricsErrorNotFound => '歌詞が見つかりません';

  @override
  String get lyricsErrorLoadFailed => '歌詞の読み込みに失敗しました';

  @override
  String get lyricsErrorNetwork => 'インターネット接続をご確認ください';

  @override
  String get justNow => 'たった今';

  @override
  String minutesAgo(Object minutes) {
    return '$minutes分前';
  }

  @override
  String hoursAgo(Object hours) {
    return '$hours時間前';
  }

  @override
  String dateFormat(Object day, Object month, Object year) {
    return '$year年$month月$day日';
  }

  @override
  String get deleteAllTooltip => 'すべて削除';

  @override
  String get radioTitle => 'ラジオ';

  @override
  String get radioRecentListening => '最近聴いた';

  @override
  String get radioSelectCountry => '国を選択';

  @override
  String get radioChannelCount => 'チャンネル';

  @override
  String get radioPopular200 => '人気200';

  @override
  String get radioSleep => 'スリープ';

  @override
  String get radioSchedule => '予約';

  @override
  String get sleepTimerDesc => '選択した時間後に自動的にオフになります';

  @override
  String get sleepTimerActiveDesc => 'タイマー作動中です';

  @override
  String get remainingTime => '残り時間';

  @override
  String get cancelTimerX => '× タイマーをキャンセル';

  @override
  String get countryKR => '韓国';

  @override
  String get countryUS => 'アメリカ';

  @override
  String get countryJP => '日本';

  @override
  String get countryTW => '台湾';

  @override
  String get countryCN => '中国';

  @override
  String get countryHK => '香港';

  @override
  String get countryGB => 'イギリス';

  @override
  String get countryVN => 'ベトナム';

  @override
  String get countryPH => 'フィリピン';

  @override
  String get countryDE => 'ドイツ';

  @override
  String get countryFR => 'フランス';

  @override
  String get countryTH => 'タイ';

  @override
  String get countryID => 'インドネシア';

  @override
  String get countryIN => 'インド';

  @override
  String get countryES => 'スペイン';

  @override
  String get countryIT => 'イタリア';

  @override
  String get countryBR => 'ブラジル';

  @override
  String get countryCA => 'カナダ';

  @override
  String get countryAU => 'オーストラリア';

  @override
  String get countryMX => 'メキシコ';

  @override
  String get countryTR => 'トルコ';

  @override
  String get countryNL => 'オランダ';

  @override
  String get countrySE => 'スウェーデン';

  @override
  String get countryPL => 'ポーランド';

  @override
  String get countryAR => 'アルゼンチン';

  @override
  String get countryCO => 'コロンビア';

  @override
  String get countryNZ => 'ニュージーランド';

  @override
  String get countryMY => 'マレーシア';

  @override
  String get countrySG => 'シンガポール';

  @override
  String get countryRU => 'ロシア';

  @override
  String get countryZA => '南アフリカ';

  @override
  String get countryPK => 'パキスタン';

  @override
  String get countryBD => 'バングラデシュ';

  @override
  String get countryLK => 'スリランカ';

  @override
  String get countryNP => 'ネパール';

  @override
  String get countryMM => 'ミャンマー';

  @override
  String get countryKH => 'カンボジア';

  @override
  String get countryAT => 'オーストリア';

  @override
  String get countryCH => 'スイス';

  @override
  String get countryBE => 'ベルギー';

  @override
  String get countryPT => 'ポルトガル';

  @override
  String get countryGR => 'ギリシャ';

  @override
  String get countryIE => 'アイルランド';

  @override
  String get countryNO => 'ノルウェー';

  @override
  String get countryDK => 'デンマーク';

  @override
  String get countryFI => 'フィンランド';

  @override
  String get countryCZ => 'チェコ';

  @override
  String get countryRO => 'ルーマニア';

  @override
  String get countryUA => 'ウクライナ';

  @override
  String get countryEG => 'エジプト';

  @override
  String get countrySA => 'サウジアラビア';

  @override
  String get countryAE => 'UAE';

  @override
  String get countryNG => 'ナイジェリア';

  @override
  String get countryKE => 'ケニア';

  @override
  String get countryCL => 'チリ';

  @override
  String get countryPE => 'ペルー';

  @override
  String get countryVE => 'ベネズエラ';

  @override
  String get countryCU => 'キューバ';

  @override
  String get countryJM => 'ジャマイカ';

  @override
  String get countryIQ => 'イラク';

  @override
  String get countryIR => 'イラン';

  @override
  String get countryIL => 'イスラエル';

  @override
  String get countryMN => 'モンゴル';

  @override
  String get countryUZ => 'ウズベキスタン';

  @override
  String get countryKZ => 'カザフスタン';

  @override
  String get countryLA => 'ラオス';

  @override
  String get countryHU => 'ハンガリー';

  @override
  String get countryHR => 'クロアチア';

  @override
  String get countryRS => 'セルビア';

  @override
  String get countryBG => 'ブルガリア';

  @override
  String get countrySK => 'スロバキア';

  @override
  String get countryLT => 'リトアニア';

  @override
  String get countryLV => 'ラトビア';

  @override
  String get countryEE => 'エストニア';

  @override
  String get countryIS => 'アイスランド';

  @override
  String get countryGH => 'ガーナ';

  @override
  String get countryTZ => 'タンザニア';

  @override
  String get countryMA => 'モロッコ';

  @override
  String get countryTN => 'チュニジア';

  @override
  String get countryET => 'エチオピア';

  @override
  String get countryUG => 'ウガンダ';

  @override
  String get countryEC => 'エクアドル';

  @override
  String get countryBO => 'ボリビア';

  @override
  String get countryPY => 'パラグアイ';

  @override
  String get countryUY => 'ウルグアイ';

  @override
  String get countryPA => 'パナマ';

  @override
  String get countryCR => 'コスタリカ';

  @override
  String get countryDO => 'ドミニカ共和国';

  @override
  String get countryTT => 'トリニダード・トバゴ';

  @override
  String get countryHT => 'ハイチ';

  @override
  String get countryFJ => 'フィジー';

  @override
  String get countryPG => 'パプアニューギニア';

  @override
  String get countryJO => 'ヨルダン';

  @override
  String get countryLB => 'レバノン';

  @override
  String get countryGE => 'ジョージア';

  @override
  String get countryAM => 'アルメニア';

  @override
  String get countryAZ => 'アゼルバイジャン';

  @override
  String get countrySI => 'スロベニア';

  @override
  String get countryAL => 'アルバニア';

  @override
  String get countryMK => '北マケドニア';

  @override
  String get countryME => 'モンテネグロ';

  @override
  String get countryBA => 'ボスニア';

  @override
  String get countryMT => 'マルタ';

  @override
  String get countryLU => 'ルクセンブルク';

  @override
  String get countryCY => 'キプロス';

  @override
  String get countryCM => 'カメルーン';

  @override
  String get countrySN => 'セネガル';

  @override
  String get countryZW => 'ジンバブエ';

  @override
  String get countryMZ => 'モザンビーク';

  @override
  String get countryMG => 'マダガスカル';

  @override
  String get countryGT => 'グアテマラ';

  @override
  String get countryHN => 'ホンジュラス';

  @override
  String get countryNI => 'ニカラグア';

  @override
  String get countrySV => 'エルサルバドル';

  @override
  String get countryPR => 'プエルトリコ';

  @override
  String get categoryNational => '全国';

  @override
  String get categorySeoulGyeonggi => 'ソウル/京畿';

  @override
  String get categoryRegionalMBC => '地域MBC';

  @override
  String get categoryRegionalPrivate => '地域民放';

  @override
  String get categoryTraffic => '交通放送';

  @override
  String get categoryEtc => 'その他';

  @override
  String get regionAll => 'すべて';

  @override
  String get regionCapital => '首都圏';

  @override
  String get regionBusanGyeongnam => '釜山/慶南';

  @override
  String get regionDaeguGyeongbuk => '大邱/慶北';

  @override
  String get regionGwangjuJeonnam => '光州/全南';

  @override
  String get regionJeonbuk => '全北';

  @override
  String get regionDaejeonChungnam => '大田/忠南';

  @override
  String get regionChungbuk => '忠北';

  @override
  String get regionGangwon => '江原';

  @override
  String get regionJeju => '済州';

  @override
  String get radioNoFavorites => 'お気に入りがありません';

  @override
  String get radioNoFavoritesDesc => 'チャンネル一覧で♡をタップして追加してみてください';

  @override
  String get radioRemovedFromFavorites => 'お気に入りから削除しました';

  @override
  String get radioAddedToFavoritesToast => 'お気に入りに追加しました';

  @override
  String get radioConnecting => '接続中...';

  @override
  String radioPopularCount(Object count) {
    return '人気放送$count件';
  }

  @override
  String get radioLoadingPopular => '人気放送を読み込み中...';

  @override
  String radioScheduleTitle(Object station) {
    return '$station 編成表';
  }

  @override
  String get radioLoadingSchedule => '編成表を読み込み中...';

  @override
  String get radioScheduleChannelSwitch => '予約チャンネル切替';

  @override
  String radioMaxSchedules(Object count) {
    return '最大5個 ($count/5)';
  }

  @override
  String get radioSelectTime => '時間を選択';

  @override
  String get radioSetSchedule => '予約設定';

  @override
  String get radioBroadcastSchedule => '編成表';

  @override
  String get radioPlayFirst => 'まずラジオを再生してください';

  @override
  String get radioCancelAllSchedules => 'すべての予約をキャンセル';

  @override
  String get radioScheduleSetToast => '予約が設定されました';

  @override
  String radioScheduleCompleteToast(Object time, Object title) {
    return '$title $time 予約完了';
  }

  @override
  String get radioPlaybackFailed => '再生に失敗しました。';

  @override
  String get radioRerun => '再放送';

  @override
  String get radioLive => '● LIVE';

  @override
  String get radioStatusConnecting => '接続中...';

  @override
  String get radioStatusFailed => '接続失敗';

  @override
  String get radioStatusPaused => '一時停止';

  @override
  String get radioAfterEnd => '後に終了';

  @override
  String get radioNoStationsFound => '放送が見つかりません';

  @override
  String get sleepMin => '分';

  @override
  String get sleepHour => '時間';

  @override
  String sleepMinuteUnit(Object minutes) {
    return '$minutes分';
  }

  @override
  String sleepHourUnit(Object hours) {
    return '$hours時間';
  }

  @override
  String sleepHourMinuteUnit(Object hours, Object minutes) {
    return '$hours時間$minutes分';
  }

  @override
  String sleepCountdownHMS(Object hours, Object minutes, Object seconds) {
    return '$hours時間$minutes分$seconds秒';
  }

  @override
  String sleepCountdownMS(Object minutes, Object seconds) {
    return '$minutes分$seconds秒';
  }

  @override
  String sleepCountdownS(Object seconds) {
    return '$seconds秒';
  }

  @override
  String sleepAutoStopToast(Object time) {
    return '$time後に自動的にオフになります';
  }

  @override
  String get radioKoreaTitle => '韓国ラジオ';

  @override
  String get radioOnAirTitle => 'ON AIR';

  @override
  String get radioKoreaSlogan => '世界の音を届ける';

  @override
  String get radioSloganUS => '自由の声を聴く';

  @override
  String get radioSloganJP => '日常に寄り添う小さな癒し';

  @override
  String get radioSloganTW => '島を流れる歌';

  @override
  String get radioSloganCN => '広大な大地の音';

  @override
  String get radioSloganHK => '都市のリズムに乗る';

  @override
  String get radioSloganGB => '伝統と現在が出会う場所';

  @override
  String get radioSloganVN => 'メコン川の調べ';

  @override
  String get radioSloganPH => '島々の響き';

  @override
  String get radioSloganDE => 'ヨーロッパの心臓からの音';

  @override
  String get radioSloganFR => '人生のメロディー';

  @override
  String get radioSloganTH => 'シャムの響き';

  @override
  String get radioSloganID => '群島のリズム';

  @override
  String get radioSloganIN => 'インドの調べ';

  @override
  String get radioSloganES => '魂のリズム';

  @override
  String get radioSloganIT => '人生の音楽';

  @override
  String get radioSloganBR => 'ブラジルの音';

  @override
  String get radioSloganCA => '北の大地を渡る声';

  @override
  String get radioSloganAU => '南半球の響き';

  @override
  String get radioSloganMX => 'メキシコのリズム';

  @override
  String get radioSloganTR => 'アナトリアの声';

  @override
  String get radioSloganNL => '低地の響き';

  @override
  String get radioSloganSE => '北欧の音';

  @override
  String get radioSloganPL => 'ヴィスワ川の調べ';

  @override
  String get radioSloganAR => '魂のタンゴ';

  @override
  String get radioSloganCO => 'コロンビアのリズム';

  @override
  String get radioSloganNZ => 'アオテアロアの響き';

  @override
  String get radioSloganMY => 'マレーシアのリズム';

  @override
  String get radioSloganSG => 'ライオンシティの響き';

  @override
  String get radioSloganRU => 'ロシアの音';

  @override
  String get radioSloganZA => '虹の国の響き';

  @override
  String get radioSloganPK => 'パキスタンの旋律';

  @override
  String get radioSloganBD => 'ベンガルの音';

  @override
  String get radioSloganLK => 'スリランカの音';

  @override
  String get radioSloganNP => 'ヒマラヤの調べ';

  @override
  String get radioSloganMM => 'ミャンマーの音';

  @override
  String get radioSloganKH => 'アンコールの音';

  @override
  String get radioSloganAT => 'アルプスの響き';

  @override
  String get radioSloganCH => 'スイスの声';

  @override
  String get radioSloganBE => 'ベルギーの響き';

  @override
  String get radioSloganPT => 'ポルトガルの音';

  @override
  String get radioSloganGR => 'ギリシャの音';

  @override
  String get radioSloganIE => 'エメラルドの島の音';

  @override
  String get radioSloganNO => 'フィヨルドの音';

  @override
  String get radioSloganDK => 'デンマークの音';

  @override
  String get radioSloganFI => 'フィンランドの音';

  @override
  String get radioSloganCZ => 'ボヘミアの音';

  @override
  String get radioSloganRO => 'ルーマニアの音';

  @override
  String get radioSloganUA => 'ウクライナの音';

  @override
  String get radioSloganEG => 'ナイルの音';

  @override
  String get radioSloganSA => 'アラビアの音';

  @override
  String get radioSloganAE => '湾岸の音';

  @override
  String get radioSloganNG => 'ナイジェリアの音';

  @override
  String get radioSloganKE => 'ケニアの音';

  @override
  String get radioSloganCL => 'チリの音';

  @override
  String get radioSloganPE => 'ペルーの音';

  @override
  String get radioSloganVE => 'ベネズエラのリズム';

  @override
  String get radioSloganCU => 'キューバのリズム';

  @override
  String get radioSloganJM => 'ジャマイカのリズム';

  @override
  String get radioSloganIQ => 'メソポタミアの音';

  @override
  String get radioSloganIR => 'イランの旋律';

  @override
  String get radioSloganIL => 'イスラエルの音';

  @override
  String get radioSloganMN => '草原の調べ';

  @override
  String get radioSloganUZ => 'ウズベキスタンの音';

  @override
  String get radioSloganKZ => 'カザフスタンの音';

  @override
  String get radioSloganLA => 'ラオスの音';

  @override
  String get radioSloganHU => 'ドナウの音';

  @override
  String get radioSloganHR => 'アドリア海の音';

  @override
  String get radioSloganRS => 'セルビアの音';

  @override
  String get radioSloganBG => 'ブルガリアの音';

  @override
  String get radioSloganSK => 'スロバキアの音';

  @override
  String get radioSloganLT => 'リトアニアの音';

  @override
  String get radioSloganLV => 'ラトビアの音';

  @override
  String get radioSloganEE => 'エストニアの音';

  @override
  String get radioSloganIS => 'アイスランドの音';

  @override
  String get radioSloganGH => 'ガーナの音';

  @override
  String get radioSloganTZ => 'タンザニアの音';

  @override
  String get radioSloganMA => 'モロッコの音';

  @override
  String get radioSloganTN => 'チュニジアの音';

  @override
  String get radioSloganET => 'エチオピアの音';

  @override
  String get radioSloganUG => 'ウガンダの音';

  @override
  String get radioSloganEC => 'エクアドルの音';

  @override
  String get radioSloganBO => 'ボリビアの音';

  @override
  String get radioSloganPY => 'パラグアイの音';

  @override
  String get radioSloganUY => 'ウルグアイの音';

  @override
  String get radioSloganPA => 'パナマの音';

  @override
  String get radioSloganCR => 'コスタリカの音';

  @override
  String get radioSloganDO => 'ドミニカのリズム';

  @override
  String get radioSloganTT => 'トリニダードの音';

  @override
  String get radioSloganHT => 'ハイチの音';

  @override
  String get selectSong => '曲を選択';

  @override
  String get selectRange => '範囲を選択';

  @override
  String get start => '開始';

  @override
  String get end => '終了';

  @override
  String rangeFormat(Object end, Object seconds, Object start) {
    return '範囲: $start ~ $end ($seconds秒)';
  }

  @override
  String get deselectAll => '選択解除';

  @override
  String get exit => '終了';

  @override
  String get timerLabel => 'タイマー';

  @override
  String get playbackSpeedLabel => '再生速度';

  @override
  String get updateReadyTitle => 'アップデート準備完了';

  @override
  String get updateReadyMessage => '新機能がダウンロードされました。\n今すぐ再起動することをお勧めします。';

  @override
  String get updateReadyButton => '今すぐ再起動';

  @override
  String get updateReadyLater => '後で';

  @override
  String get radioNextProgram => '次の番組';

  @override
  String get radioExitConfirmTitle => 'ラジオを終了しますか？';

  @override
  String get radioExitConfirmMessage => '今終了すると再生が止まります。';

  @override
  String get radioExitKeepListening => '聴き続ける';

  @override
  String get radioExitConfirmButton => '終了';

  @override
  String get darkMode => 'ダークモード';

  @override
  String get darkModeOn => 'オン';

  @override
  String get darkModeOff => 'オフ';

  @override
  String get rateApp => 'アプリを評価する';

  @override
  String get musicExitConfirmTitle => '音楽を終了しますか？';

  @override
  String get musicExitConfirmMessage => '今出ると再生が止まります。';
}
