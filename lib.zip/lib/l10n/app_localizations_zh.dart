// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get appName => 'Paransori';

  @override
  String get songs => '歌曲';

  @override
  String get albums => '專輯';

  @override
  String get artists => '藝術家';

  @override
  String get playlists => '播放清單';

  @override
  String get folders => '資料夾';

  @override
  String get videos => '影片';

  @override
  String get settings => '設定';

  @override
  String get search => '搜尋';

  @override
  String get favorites => '我的最愛';

  @override
  String get recent => '最近';

  @override
  String get all => '全部';

  @override
  String get play => '播放';

  @override
  String get pause => '暫停';

  @override
  String get next => '下一首';

  @override
  String get previous => '上一首';

  @override
  String get shuffle => '隨機播放';

  @override
  String get repeat => '重複';

  @override
  String get nowPlaying => '播放中';

  @override
  String get noSongs => '找不到MP3檔案';

  @override
  String get addMusic => '請將音樂檔案新增至裝置';

  @override
  String get scanningMusic => '正在掃描音樂...';

  @override
  String get editSong => '編輯歌曲資訊';

  @override
  String get save => '儲存';

  @override
  String get cancel => '取消';

  @override
  String get delete => '刪除';

  @override
  String get title => '標題';

  @override
  String get artist => '藝術家';

  @override
  String get album => '專輯';

  @override
  String get addToPlaylist => '新增至播放清單';

  @override
  String get addToFavorites => '加入我的最愛';

  @override
  String get removeFromFavorites => '從我的最愛移除';

  @override
  String get setRingtone => '設為鈴聲';

  @override
  String get share => '分享';

  @override
  String get songInfo => '歌曲資訊';

  @override
  String get equalizer => '等化器';

  @override
  String get sleepTimer => '睡眠計時器';

  @override
  String get playbackSpeed => '播放速度';

  @override
  String get repeatMode => '重複模式';

  @override
  String get noRepeat => '不重複';

  @override
  String get repeatOne => '單曲重複';

  @override
  String get repeatAll => '全部重複';

  @override
  String get themeColor => '主題顏色';

  @override
  String get textSize => '文字大小';

  @override
  String get fontChange => '字體變更';

  @override
  String get playerStyle => '播放器樣式';

  @override
  String get flashlight => '手電筒';

  @override
  String get sos => 'SOS緊急燈';

  @override
  String get ringtone => '設定鈴聲';

  @override
  String get widget => '主畫面小工具';

  @override
  String get version => '版本資訊';

  @override
  String get promoCode => '促銷代碼';

  @override
  String get privacyPolicy => '隱私權政策';

  @override
  String get termsOfService => '服務條款';

  @override
  String get noRecentSongs => '沒有最近播放的歌曲';

  @override
  String get playMusic => '播放一些音樂吧';

  @override
  String get clearAll => '全部清除';

  @override
  String get clearRecent => '清除最近播放';

  @override
  String get clearRecentConfirm => '要清除所有最近播放的歌曲嗎？';

  @override
  String get playAll => '全部播放';

  @override
  String get addedToFavorites => '已加入我的最愛';

  @override
  String get removedFromFavorites => '已從我的最愛移除';

  @override
  String get songSaved => '歌曲資訊已儲存';

  @override
  String get swipeToChange => '滑動切換歌曲';

  @override
  String get noAlbums => '找不到專輯';

  @override
  String get noArtists => '找不到藝術家';

  @override
  String get searchAlbums => '搜尋專輯...';

  @override
  String get searchArtists => '搜尋藝術家...';

  @override
  String get close => '關閉';

  @override
  String get defaultValue => '預設';

  @override
  String get preview => '預覽';

  @override
  String get playing => '播放中...';

  @override
  String get ringtoneSet => '鈴聲已設定！🎵';

  @override
  String get ringtoneFailed => '設定鈴聲失敗';

  @override
  String get promoUnlocked => '🎉 廣告已移除！';

  @override
  String get promoInvalid => '無效的代碼';

  @override
  String get promoEnter => '請輸入促銷代碼';

  @override
  String get confirm => '確認';

  @override
  String get permissionRequired => '需要儲存空間權限';

  @override
  String get permissionMessage => '需要儲存空間權限\n才能掃描MP3檔案。';

  @override
  String get allowPermission => '允許權限';

  @override
  String get retry => '重試';

  @override
  String get deleteSong => '刪除歌曲';

  @override
  String get deleteSongConfirm => '要刪除這首歌嗎？\n將從裝置中永久刪除。';

  @override
  String get deleted => '已刪除';

  @override
  String get deleteFailed => '刪除失敗';

  @override
  String get playNext => '下一首播放';

  @override
  String get addedToQueue => '已加入播放佇列';

  @override
  String get noPlaylists => '沒有播放清單。\n請在播放清單標籤中建立。';

  @override
  String get addedToPlaylist => '已加入播放清單';

  @override
  String get searchHint => '搜尋歌曲、藝術家、專輯...';

  @override
  String get timerCancel => '取消計時器';

  @override
  String get minutesAfterEnd => '分鐘後停止';

  @override
  String get hoursAfterEnd => '小時後停止';

  @override
  String get set => '設定';

  @override
  String get small => '小';

  @override
  String get large => '大';

  @override
  String get apply => '套用';

  @override
  String get songCount => '首';

  @override
  String get on => '開啟';

  @override
  String get off => '關閉';

  @override
  String get sosWorking => '運作中...';

  @override
  String get flashlightError => '手電筒錯誤';

  @override
  String get minuteShort => '分';

  @override
  String get hourShort => '時';

  @override
  String get privacyPolicyUrl => 'https://www.ssing.kr/privacy_policy_zh.html';

  @override
  String get termsOfServiceUrl =>
      'https://www.ssing.kr/terms_of_service_zh.html';

  @override
  String get preset => '預設';

  @override
  String get bassBooster => '低音增強';

  @override
  String get enhancesBass => '增強低音效果';

  @override
  String get virtualizer => '虛擬環繞';

  @override
  String get surroundEffect => '創造環繞音效';

  @override
  String get reset => '重置';

  @override
  String get reviewTitle => '您喜歡 Paransori 嗎？';

  @override
  String get reviewMessage => '請留下評分！\n這將幫助我們改善應用程式 😊';

  @override
  String get reviewButton => '⭐ 留下評分';

  @override
  String get reviewLater => '稍後再說';

  @override
  String get fontDefault => '預設字體';

  @override
  String get fontNotoSans => 'Noto Sans KR (簡潔)';

  @override
  String get fontJua => 'Jua (可愛)';

  @override
  String get fontGaegu => 'Gaegu (手寫)';

  @override
  String get fontNanumGothic => 'Nanum Gothic (柔和)';

  @override
  String get fontDoHyeon => 'Do Hyeon (現代)';

  @override
  String get fontCuteFont => 'Cute Font (可愛)';

  @override
  String get fontStylish => 'Stylish (優雅)';

  @override
  String get fontSunflower => 'Sunflower (輕盈)';

  @override
  String get fontHiMelody => 'Hi Melody (感性)';

  @override
  String get fontPoorStory => 'Poor Story (手寫)';

  @override
  String get fontEastSeaDokdo => 'East Sea Dokdo (獨特)';

  @override
  String get fontNanumBrush => 'Nanum Brush Script (毛筆)';

  @override
  String get fontNanumMyeongjo => 'Nanum Myeongjo (明體)';

  @override
  String get fontBlackAndWhite => 'Black And White Picture (特別)';

  @override
  String get fontGowunDodum => 'Gowun Dodum (圓潤)';

  @override
  String get fontGowunBatang => 'Gowun Batang (仿宋)';

  @override
  String get fontNanumPen => 'Nanum Pen Script (鋼筆)';

  @override
  String get fontSingleDay => 'Single Day (可愛)';

  @override
  String get fontYeonSung => 'Yeon Sung (柔和)';

  @override
  String get styleCD => 'CD旋轉';

  @override
  String get styleCDDesc => '經典CD旋轉動畫';

  @override
  String get styleCassette => '卡帶';

  @override
  String get styleCassetteDesc => '復古卡帶風格';

  @override
  String get styleCard => '專輯封面卡片';

  @override
  String get styleCardDesc => '簡約專輯封面卡片';

  @override
  String get styleVisualizer => '波形視覺化';

  @override
  String get styleVisualizerDesc => '音波動畫';

  @override
  String get styleGradient => '漸層';

  @override
  String get styleGradientDesc => '專輯封面顏色漸層背景';

  @override
  String get themeColorHint => '您可以在設定中變更背景顏色';

  @override
  String get hourWord => '小時';

  @override
  String autoStopFormat(Object time) {
    return '$time後自動關閉';
  }

  @override
  String get autoStopCountdownSuffix => '後自動結束';

  @override
  String get secondShort => '秒';

  @override
  String get unknownArtist => '未知藝術家';

  @override
  String get unknownAlbum => '未知專輯';

  @override
  String get noTitle => '無標題';

  @override
  String selectedCount(Object count) {
    return '已選擇$count項';
  }

  @override
  String get selectAll => '全選';

  @override
  String get deleteSelected => '刪除所選';

  @override
  String deleteSelectedConfirm(Object count) {
    return '要刪除$count首歌曲嗎？\n將從裝置中永久刪除。';
  }

  @override
  String deletedCount(Object count) {
    return '已刪除$count項';
  }

  @override
  String get noVideosFound => '找不到影片';

  @override
  String videoCount(Object count) {
    return '$count部';
  }

  @override
  String get rename => '重新命名';

  @override
  String get deleteVideoTitle => '刪除影片';

  @override
  String deleteVideoConfirm(Object name) {
    return '要刪除$name嗎？';
  }

  @override
  String get nameChanged => '名稱已變更';

  @override
  String renameFailed(Object error) {
    return '重新命名失敗：$error';
  }

  @override
  String deleteFailedWithError(Object error) {
    return '刪除失敗：$error';
  }

  @override
  String get videoPermissionRequired => '需要影片存取權限';

  @override
  String get videoPermissionMessage => '需要存取權限\n才能觀看影片。';

  @override
  String get openSettings => '開啟設定';

  @override
  String deleteSongConfirmFormat(Object title) {
    return '要刪除$title嗎？\n將從裝置中永久刪除。';
  }

  @override
  String get playTime => '播放時間';

  @override
  String get path => '路徑';

  @override
  String get newPlaylist => '新增播放清單';

  @override
  String get playlistNameHint => '播放清單名稱';

  @override
  String get create => '建立';

  @override
  String get playlistLabel => '播放清單';

  @override
  String get renamePlaylistTitle => '重新命名';

  @override
  String get deletePlaylistTitle => '刪除播放清單';

  @override
  String deletePlaylistConfirm(Object name) {
    return '要刪除$name嗎？';
  }

  @override
  String get change => '變更';

  @override
  String get songCountSuffix => '首';

  @override
  String get lyrics => '歌詞';

  @override
  String get lyricsLoading => '正在載入歌詞...';

  @override
  String get lyricsNotFound => '找不到歌詞';

  @override
  String get lyricsSearchPrompt => '搜尋歌詞看看';

  @override
  String get lyricsSearchButton => '搜尋歌詞';

  @override
  String get lyricsErrorNotFound => '找不到歌詞';

  @override
  String get lyricsErrorLoadFailed => '歌詞載入失敗';

  @override
  String get lyricsErrorNetwork => '請確認網路連線';

  @override
  String get justNow => '剛剛';

  @override
  String minutesAgo(Object minutes) {
    return '$minutes分鐘前';
  }

  @override
  String hoursAgo(Object hours) {
    return '$hours小時前';
  }

  @override
  String dateFormat(Object day, Object month, Object year) {
    return '$year年$month月$day日';
  }

  @override
  String get deleteAllTooltip => '全部刪除';

  @override
  String get radioTitle => '廣播';

  @override
  String get radioRecentListening => '最近收聽';

  @override
  String get radioSelectCountry => '選擇國家';

  @override
  String get radioChannelCount => '個頻道';

  @override
  String get radioPopular200 => '熱門200個';

  @override
  String get radioSleep => '睡眠';

  @override
  String get radioSchedule => '預約';

  @override
  String get sleepTimerDesc => '選擇的時間後將自動關閉';

  @override
  String get sleepTimerActiveDesc => '計時器運作中';

  @override
  String get remainingTime => '剩餘時間';

  @override
  String get cancelTimerX => '× 取消計時器';

  @override
  String get countryKR => '韓國';

  @override
  String get countryUS => '美國';

  @override
  String get countryJP => '日本';

  @override
  String get countryTW => '台灣';

  @override
  String get countryCN => '中國';

  @override
  String get countryHK => '香港';

  @override
  String get countryGB => '英國';

  @override
  String get countryVN => '越南';

  @override
  String get countryPH => '菲律賓';

  @override
  String get countryDE => '德國';

  @override
  String get countryFR => '法國';

  @override
  String get countryTH => '泰國';

  @override
  String get countryID => '印尼';

  @override
  String get countryIN => '印度';

  @override
  String get countryES => '西班牙';

  @override
  String get countryIT => '義大利';

  @override
  String get countryBR => '巴西';

  @override
  String get countryCA => '加拿大';

  @override
  String get countryAU => '澳洲';

  @override
  String get countryMX => '墨西哥';

  @override
  String get countryTR => '土耳其';

  @override
  String get countryNL => '荷蘭';

  @override
  String get countrySE => '瑞典';

  @override
  String get countryPL => '波蘭';

  @override
  String get countryAR => '阿根廷';

  @override
  String get countryCO => '哥倫比亞';

  @override
  String get countryNZ => '紐西蘭';

  @override
  String get countryMY => '馬來西亞';

  @override
  String get countrySG => '新加坡';

  @override
  String get countryRU => '俄羅斯';

  @override
  String get countryZA => '南非';

  @override
  String get countryPK => '巴基斯坦';

  @override
  String get countryBD => '孟加拉';

  @override
  String get countryLK => '斯里蘭卡';

  @override
  String get countryNP => '尼泊爾';

  @override
  String get countryMM => '緬甸';

  @override
  String get countryKH => '柬埔寨';

  @override
  String get countryAT => '奧地利';

  @override
  String get countryCH => '瑞士';

  @override
  String get countryBE => '比利時';

  @override
  String get countryPT => '葡萄牙';

  @override
  String get countryGR => '希臘';

  @override
  String get countryIE => '愛爾蘭';

  @override
  String get countryNO => '挪威';

  @override
  String get countryDK => '丹麥';

  @override
  String get countryFI => '芬蘭';

  @override
  String get countryCZ => '捷克';

  @override
  String get countryRO => '羅馬尼亞';

  @override
  String get countryUA => '烏克蘭';

  @override
  String get countryEG => '埃及';

  @override
  String get countrySA => '沙烏地阿拉伯';

  @override
  String get countryAE => '阿聯酋';

  @override
  String get countryNG => '奈及利亞';

  @override
  String get countryKE => '肯亞';

  @override
  String get countryCL => '智利';

  @override
  String get countryPE => '秘魯';

  @override
  String get countryVE => '委內瑞拉';

  @override
  String get countryCU => '古巴';

  @override
  String get countryJM => '牙買加';

  @override
  String get countryIQ => '伊拉克';

  @override
  String get countryIR => '伊朗';

  @override
  String get countryIL => '以色列';

  @override
  String get countryMN => '蒙古';

  @override
  String get countryUZ => '烏茲別克';

  @override
  String get countryKZ => '哈薩克';

  @override
  String get countryLA => '寮國';

  @override
  String get countryHU => '匈牙利';

  @override
  String get countryHR => '克羅埃西亞';

  @override
  String get countryRS => '塞爾維亞';

  @override
  String get countryBG => '保加利亞';

  @override
  String get countrySK => '斯洛伐克';

  @override
  String get countryLT => '立陶宛';

  @override
  String get countryLV => '拉脫維亞';

  @override
  String get countryEE => '愛沙尼亞';

  @override
  String get countryIS => '冰島';

  @override
  String get countryGH => '迦納';

  @override
  String get countryTZ => '坦尚尼亞';

  @override
  String get countryMA => '摩洛哥';

  @override
  String get countryTN => '突尼西亞';

  @override
  String get countryET => '衣索比亞';

  @override
  String get countryUG => '烏干達';

  @override
  String get countryEC => '厄瓜多';

  @override
  String get countryBO => '玻利維亞';

  @override
  String get countryPY => '巴拉圭';

  @override
  String get countryUY => '烏拉圭';

  @override
  String get countryPA => '巴拿馬';

  @override
  String get countryCR => '哥斯大黎加';

  @override
  String get countryDO => '多明尼加共和國';

  @override
  String get countryTT => '千里達及托巴哥';

  @override
  String get countryHT => '海地';

  @override
  String get countryFJ => '斐濟';

  @override
  String get countryPG => '巴布亞紐幾內亞';

  @override
  String get countryJO => '約旦';

  @override
  String get countryLB => '黎巴嫩';

  @override
  String get countryGE => '喬治亞';

  @override
  String get countryAM => '亞美尼亞';

  @override
  String get countryAZ => '亞塞拜然';

  @override
  String get countrySI => '斯洛維尼亞';

  @override
  String get countryAL => '阿爾巴尼亞';

  @override
  String get countryMK => '北馬其頓';

  @override
  String get countryME => '蒙特內哥羅';

  @override
  String get countryBA => '波士尼亞';

  @override
  String get countryMT => '馬爾他';

  @override
  String get countryLU => '盧森堡';

  @override
  String get countryCY => '賽普勒斯';

  @override
  String get countryCM => '喀麥隆';

  @override
  String get countrySN => '塞內加爾';

  @override
  String get countryZW => '辛巴威';

  @override
  String get countryMZ => '莫三比克';

  @override
  String get countryMG => '馬達加斯加';

  @override
  String get countryGT => '瓜地馬拉';

  @override
  String get countryHN => '宏都拉斯';

  @override
  String get countryNI => '尼加拉瓜';

  @override
  String get countrySV => '薩爾瓦多';

  @override
  String get countryPR => '波多黎各';

  @override
  String get categoryNational => '全國';

  @override
  String get categorySeoulGyeonggi => '首爾/京畿';

  @override
  String get categoryRegionalMBC => '地區MBC';

  @override
  String get categoryRegionalPrivate => '地區民營';

  @override
  String get categoryTraffic => '交通廣播';

  @override
  String get categoryEtc => '其他';

  @override
  String get regionAll => '全部';

  @override
  String get regionCapital => '首都圈';

  @override
  String get regionBusanGyeongnam => '釜山/慶南';

  @override
  String get regionDaeguGyeongbuk => '大邱/慶北';

  @override
  String get regionGwangjuJeonnam => '光州/全南';

  @override
  String get regionJeonbuk => '全北';

  @override
  String get regionDaejeonChungnam => '大田/忠南';

  @override
  String get regionChungbuk => '忠北';

  @override
  String get regionGangwon => '江原';

  @override
  String get regionJeju => '濟州';

  @override
  String get radioNoFavorites => '沒有收藏的頻道';

  @override
  String get radioNoFavoritesDesc => '在頻道列表中點擊♡來新增收藏';

  @override
  String get radioRemovedFromFavorites => '已從我的最愛移除';

  @override
  String get radioAddedToFavoritesToast => '已加入我的最愛';

  @override
  String get radioConnecting => '連線中...';

  @override
  String radioPopularCount(Object count) {
    return '熱門廣播$count個';
  }

  @override
  String get radioLoadingPopular => '正在載入熱門廣播...';

  @override
  String radioScheduleTitle(Object station) {
    return '$station 節目表';
  }

  @override
  String get radioLoadingSchedule => '正在載入節目表...';

  @override
  String get radioScheduleChannelSwitch => '預約頻道切換';

  @override
  String radioMaxSchedules(Object count) {
    return '最多5個 ($count/5)';
  }

  @override
  String get radioSelectTime => '選擇時間';

  @override
  String get radioSetSchedule => '設定預約';

  @override
  String get radioBroadcastSchedule => '節目表';

  @override
  String get radioPlayFirst => '請先播放廣播';

  @override
  String get radioCancelAllSchedules => '取消全部預約';

  @override
  String get radioScheduleSetToast => '已設定預約';

  @override
  String radioScheduleCompleteToast(Object time, Object title) {
    return '$title $time 預約完成';
  }

  @override
  String get radioPlaybackFailed => '播放失敗。';

  @override
  String get radioRerun => '重播';

  @override
  String get radioLive => '● LIVE';

  @override
  String get radioStatusConnecting => '連線中...';

  @override
  String get radioStatusFailed => '連線失敗';

  @override
  String get radioStatusPaused => '已暫停';

  @override
  String get radioAfterEnd => '後結束';

  @override
  String get radioNoStationsFound => '找不到廣播';

  @override
  String get sleepMin => '分';

  @override
  String get sleepHour => '小時';

  @override
  String sleepMinuteUnit(Object minutes) {
    return '$minutes分';
  }

  @override
  String sleepHourUnit(Object hours) {
    return '$hours小時';
  }

  @override
  String sleepHourMinuteUnit(Object hours, Object minutes) {
    return '$hours小時$minutes分';
  }

  @override
  String sleepCountdownHMS(Object hours, Object minutes, Object seconds) {
    return '$hours小時$minutes分$seconds秒';
  }

  @override
  String sleepCountdownMS(Object minutes, Object seconds) {
    return '$minutes分$seconds秒';
  }

  @override
  String sleepCountdownS(Object seconds) {
    return '$seconds秒';
  }

  @override
  String sleepAutoStopToast(Object time) {
    return '$time後自動關閉';
  }

  @override
  String get radioKoreaTitle => '韓國廣播';

  @override
  String get radioOnAirTitle => '直播中';

  @override
  String get radioKoreaSlogan => '聆聽世界之聲';

  @override
  String get radioSloganUS => '聆聽自由之聲';

  @override
  String get radioSloganJP => '日常中的小確幸';

  @override
  String get radioSloganTW => '流淌在島嶼的歌';

  @override
  String get radioSloganCN => '遼闊大地之聲';

  @override
  String get radioSloganHK => '乘上城市的節奏';

  @override
  String get radioSloganGB => '傳統與當代的交會';

  @override
  String get radioSloganVN => '湄公河的旋律';

  @override
  String get radioSloganPH => '群島的迴響';

  @override
  String get radioSloganDE => '歐洲心臟的聲音';

  @override
  String get radioSloganFR => '生活的旋律';

  @override
  String get radioSloganTH => '暹羅之聲';

  @override
  String get radioSloganID => '群島的節奏';

  @override
  String get radioSloganIN => '印度的旋律';

  @override
  String get radioSloganES => '靈魂的節奏';

  @override
  String get radioSloganIT => '生命的樂章';

  @override
  String get radioSloganBR => '巴西之聲';

  @override
  String get radioSloganCA => '穿越北方的聲音';

  @override
  String get radioSloganAU => '南半球的聲音';

  @override
  String get radioSloganMX => '墨西哥的節奏';

  @override
  String get radioSloganTR => '安納托利亞之聲';

  @override
  String get radioSloganNL => '低地之聲';

  @override
  String get radioSloganSE => '北歐之聲';

  @override
  String get radioSloganPL => '維斯瓦河的旋律';

  @override
  String get radioSloganAR => '靈魂的探戈';

  @override
  String get radioSloganCO => '哥倫比亞的節奏';

  @override
  String get radioSloganNZ => '奧特亞羅瓦的迴響';

  @override
  String get radioSloganMY => '馬來西亞的節奏';

  @override
  String get radioSloganSG => '獅城的律動';

  @override
  String get radioSloganRU => '俄羅斯之聲';

  @override
  String get radioSloganZA => '彩虹國度之聲';

  @override
  String get radioSloganPK => '巴基斯坦的旋律';

  @override
  String get radioSloganBD => '孟加拉之聲';

  @override
  String get radioSloganLK => '斯里蘭卡之聲';

  @override
  String get radioSloganNP => '喜馬拉雅的旋律';

  @override
  String get radioSloganMM => '緬甸之聲';

  @override
  String get radioSloganKH => '吳哥之聲';

  @override
  String get radioSloganAT => '阿爾卑斯的迴響';

  @override
  String get radioSloganCH => '瑞士之聲';

  @override
  String get radioSloganBE => '比利時的迴響';

  @override
  String get radioSloganPT => '葡萄牙之聲';

  @override
  String get radioSloganGR => '希臘之聲';

  @override
  String get radioSloganIE => '翡翠島之聲';

  @override
  String get radioSloganNO => '峽灣之聲';

  @override
  String get radioSloganDK => '丹麥之聲';

  @override
  String get radioSloganFI => '芬蘭之聲';

  @override
  String get radioSloganCZ => '波希米亞之聲';

  @override
  String get radioSloganRO => '羅馬尼亞之聲';

  @override
  String get radioSloganUA => '烏克蘭之聲';

  @override
  String get radioSloganEG => '尼羅河之聲';

  @override
  String get radioSloganSA => '阿拉伯之聲';

  @override
  String get radioSloganAE => '海灣之聲';

  @override
  String get radioSloganNG => '奈及利亞之聲';

  @override
  String get radioSloganKE => '肯亞之聲';

  @override
  String get radioSloganCL => '智利之聲';

  @override
  String get radioSloganPE => '秘魯之聲';

  @override
  String get radioSloganVE => '委內瑞拉的節奏';

  @override
  String get radioSloganCU => '古巴的節奏';

  @override
  String get radioSloganJM => '牙買加的節奏';

  @override
  String get radioSloganIQ => '美索不達米亞之聲';

  @override
  String get radioSloganIR => '伊朗的旋律';

  @override
  String get radioSloganIL => '以色列之聲';

  @override
  String get radioSloganMN => '草原的旋律';

  @override
  String get radioSloganUZ => '烏茲別克之聲';

  @override
  String get radioSloganKZ => '哈薩克之聲';

  @override
  String get radioSloganLA => '寮國之聲';

  @override
  String get radioSloganHU => '多瑙河之聲';

  @override
  String get radioSloganHR => '亞得里亞海之聲';

  @override
  String get radioSloganRS => '塞爾維亞之聲';

  @override
  String get radioSloganBG => '保加利亞之聲';

  @override
  String get radioSloganSK => '斯洛伐克之聲';

  @override
  String get radioSloganLT => '立陶宛之聲';

  @override
  String get radioSloganLV => '拉脫維亞之聲';

  @override
  String get radioSloganEE => '愛沙尼亞之聲';

  @override
  String get radioSloganIS => '冰島之聲';

  @override
  String get radioSloganGH => '迦納之聲';

  @override
  String get radioSloganTZ => '坦尚尼亞之聲';

  @override
  String get radioSloganMA => '摩洛哥之聲';

  @override
  String get radioSloganTN => '突尼西亞之聲';

  @override
  String get radioSloganET => '衣索比亞之聲';

  @override
  String get radioSloganUG => '烏干達之聲';

  @override
  String get radioSloganEC => '厄瓜多之聲';

  @override
  String get radioSloganBO => '玻利維亞之聲';

  @override
  String get radioSloganPY => '巴拉圭之聲';

  @override
  String get radioSloganUY => '烏拉圭之聲';

  @override
  String get radioSloganPA => '巴拿馬之聲';

  @override
  String get radioSloganCR => '哥斯大黎加之聲';

  @override
  String get radioSloganDO => '多明尼加的節奏';

  @override
  String get radioSloganTT => '千里達之聲';

  @override
  String get radioSloganHT => '海地之聲';

  @override
  String get selectSong => '選擇歌曲';

  @override
  String get selectRange => '選擇範圍';

  @override
  String get start => '開始';

  @override
  String get end => '結束';

  @override
  String rangeFormat(Object end, Object seconds, Object start) {
    return '範圍: $start ~ $end ($seconds秒)';
  }

  @override
  String get deselectAll => '取消全選';

  @override
  String get exit => '退出';

  @override
  String get timerLabel => '定時器';

  @override
  String get playbackSpeedLabel => '播放速度';

  @override
  String get updateReadyTitle => '更新已就緒';

  @override
  String get updateReadyMessage => '新功能已下載完成。\n建議立即重新啟動。';

  @override
  String get updateReadyButton => '立即重新啟動';

  @override
  String get updateReadyLater => '稍後';

  @override
  String get radioNextProgram => '下一節目';

  @override
  String get radioExitConfirmTitle => '要結束收音機嗎？';

  @override
  String get radioExitConfirmMessage => '現在離開將停止播放。';

  @override
  String get radioExitKeepListening => '繼續收聽';

  @override
  String get radioExitConfirmButton => '結束';

  @override
  String get darkMode => '深色模式';

  @override
  String get darkModeOn => '開啟';

  @override
  String get darkModeOff => '關閉';

  @override
  String get rateApp => '評分應用程式';

  @override
  String get musicExitConfirmTitle => '要結束音樂嗎？';

  @override
  String get musicExitConfirmMessage => '現在離開將停止播放。';
}
