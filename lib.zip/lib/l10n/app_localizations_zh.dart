// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get appName => 'Paransori';

  @override
  String get songs => '歌曲';

  @override
  String get albums => '专辑';

  @override
  String get artists => '艺术家';

  @override
  String get playlists => '播放列表';

  @override
  String get folders => '文件夹';

  @override
  String get videos => '视频';

  @override
  String get settings => '设置';

  @override
  String get search => '搜索';

  @override
  String get favorites => '收藏';

  @override
  String get recent => '最近';

  @override
  String get all => '全部';

  @override
  String get play => '播放';

  @override
  String get pause => '暂停';

  @override
  String get next => '下一首';

  @override
  String get previous => '上一首';

  @override
  String get shuffle => '随机播放';

  @override
  String get repeat => '重复';

  @override
  String get nowPlaying => '播放中';

  @override
  String get noSongs => '找不到MP3文件';

  @override
  String get addMusic => '请将音乐文件添加至设备';

  @override
  String get scanningMusic => '正在扫描音乐...';

  @override
  String get editSong => '编辑歌曲信息';

  @override
  String get save => '保存';

  @override
  String get cancel => '取消';

  @override
  String get delete => '删除';

  @override
  String get title => '标题';

  @override
  String get artist => '艺术家';

  @override
  String get album => '专辑';

  @override
  String get share => '分享';

  @override
  String get songInfo => '歌曲信息';

  @override
  String get equalizer => '均衡器';

  @override
  String get sleepTimer => '睡眠计时器';

  @override
  String get playbackSpeed => '播放速度';

  @override
  String get repeatMode => '重复模式';

  @override
  String get noRepeat => '不重复';

  @override
  String get repeatOne => '单曲重复';

  @override
  String get repeatAll => '全部重复';

  @override
  String get textSize => '字体大小';

  @override
  String get fontChange => '更改字体';

  @override
  String get playerStyle => '播放器样式';

  @override
  String get flashlight => '手电筒';

  @override
  String get sos => 'SOS紧急灯';

  @override
  String get ringtone => '设置铃声';

  @override
  String get widget => '桌面小组件';

  @override
  String get version => '版本信息';

  @override
  String get promoCode => '促销代码';

  @override
  String get privacyPolicy => '隐私政策';

  @override
  String get termsOfService => '服务条款';

  @override
  String get noRecentSongs => '没有最近播放的歌曲';

  @override
  String get playMusic => '播放一些音乐吧';

  @override
  String get clearRecent => '清除最近播放';

  @override
  String get clearRecentConfirm => '要清除所有最近播放的歌曲吗？';

  @override
  String get playAll => '全部播放';

  @override
  String get noAlbums => '找不到专辑';

  @override
  String get noArtists => '找不到艺术家';

  @override
  String get searchAlbums => '搜索专辑...';

  @override
  String get searchArtists => '搜索艺术家...';

  @override
  String get close => '关闭';

  @override
  String get defaultValue => '默认';

  @override
  String get preview => '预览';

  @override
  String get playing => '播放中...';

  @override
  String get ringtoneFailed => '设置铃声失败';

  @override
  String get promoInvalid => '无效的代码';

  @override
  String get promoEnter => '请输入促销代码';

  @override
  String get confirm => '确认';

  @override
  String get permissionRequired => '需要存储空间权限';

  @override
  String get permissionMessage => '需要存储空间权限\n才能扫描MP3文件。';

  @override
  String get allowPermission => '允许权限';

  @override
  String get retry => '重试';

  @override
  String get deleteSong => '删除歌曲';

  @override
  String get deleted => '已删除';

  @override
  String get deleteFailed => '删除失败';

  @override
  String get playNext => '下一首播放';

  @override
  String get searchHint => '搜索歌曲、艺术家、专辑...';

  @override
  String get timerCancel => '取消计时器';

  @override
  String get set => '设置';

  @override
  String get small => '小';

  @override
  String get large => '大';

  @override
  String get apply => '应用';

  @override
  String get songCount => '首';

  @override
  String get on => '开启';

  @override
  String get off => '关闭';

  @override
  String get flashlightError => '手电筒错误';

  @override
  String get minuteShort => '分';

  @override
  String get hourShort => '时';

  @override
  String get privacyPolicyUrl => 'https://www.ssing.kr/privacy_policy_zh.html';

  @override
  String get termsOfServiceUrl =>
      'https://www.ssing.kr/terms_of_service_zh.html';

  @override
  String get preset => '预设';

  @override
  String get bassBooster => '低音增强';

  @override
  String get enhancesBass => '增强低音效果';

  @override
  String get virtualizer => '虚拟环绕';

  @override
  String get surroundEffect => '创造环绕音效';

  @override
  String get reset => '重置';

  @override
  String get reviewTitle => '您喜欢 Paransori 吗？';

  @override
  String get reviewMessage => '请留下评分！\n这将帮助我们改进应用 😊';

  @override
  String get reviewButton => '⭐ 留下评分';

  @override
  String get reviewLater => '稍后再说';

  @override
  String get fontDefault => '默认字体';

  @override
  String get fontNotoSans => 'Noto Sans KR (简洁)';

  @override
  String get fontJua => 'Jua (可爱)';

  @override
  String get fontGaegu => 'Gaegu (手写)';

  @override
  String get fontNanumGothic => 'Nanum Gothic (柔和)';

  @override
  String get fontDoHyeon => 'Do Hyeon (现代)';

  @override
  String get fontCuteFont => 'Cute Font (可爱)';

  @override
  String get fontStylish => 'Stylish (优雅)';

  @override
  String get fontSunflower => 'Sunflower (轻盈)';

  @override
  String get fontHiMelody => 'Hi Melody (感性)';

  @override
  String get fontPoorStory => 'Poor Story (手写)';

  @override
  String get fontEastSeaDokdo => 'East Sea Dokdo (独特)';

  @override
  String get fontNanumBrush => 'Nanum Brush Script (毛笔)';

  @override
  String get fontNanumMyeongjo => 'Nanum Myeongjo (明体)';

  @override
  String get fontBlackAndWhite => 'Black And White Picture (特别)';

  @override
  String get fontGowunDodum => 'Gowun Dodum (圆润)';

  @override
  String get fontGowunBatang => 'Gowun Batang (仿宋)';

  @override
  String get fontNanumPen => 'Nanum Pen Script (钢笔)';

  @override
  String get fontSingleDay => 'Single Day (可爱)';

  @override
  String get fontYeonSung => 'Yeon Sung (柔和)';

  @override
  String get styleCD => 'CD旋转';

  @override
  String get styleCard => '专辑封面卡片';

  @override
  String get hourWord => '小时';

  @override
  String autoStopFormat(Object time) {
    return '$time后自动关闭';
  }

  @override
  String get autoStopCountdownSuffix => '后自动结束';

  @override
  String get secondShort => '秒';

  @override
  String get unknownArtist => '未知艺术家';

  @override
  String get unknownAlbum => '未知专辑';

  @override
  String get noTitle => '无标题';

  @override
  String selectedCount(Object count) {
    return '已选择$count项';
  }

  @override
  String get selectAll => '全选';

  @override
  String get noVideosFound => '找不到视频';

  @override
  String get rename => '重命名';

  @override
  String get playTime => '播放时间';

  @override
  String get path => '路径';

  @override
  String get playlistNameHint => '播放列表名称';

  @override
  String get create => '创建';

  @override
  String get playlistLabel => '播放列表';

  @override
  String get change => '更改';

  @override
  String get songCountSuffix => '首';

  @override
  String get lyrics => '歌词';

  @override
  String get lyricsLoading => '正在加载歌词...';

  @override
  String get lyricsErrorNotFound => '找不到歌词';

  @override
  String get lyricsErrorNetwork => '请确认网络连接';

  @override
  String get justNow => '刚刚';

  @override
  String minutesAgo(Object minutes) {
    return '$minutes分钟前';
  }

  @override
  String hoursAgo(Object hours) {
    return '$hours小时前';
  }

  @override
  String dateFormat(Object day, Object month, Object year) {
    return '$year年$month月$day日';
  }

  @override
  String get radioTitle => '广播';

  @override
  String get radioRecentListening => '最近收听';

  @override
  String get radioSelectCountry => '选择国家';

  @override
  String get radioChannelCount => '个频道';

  @override
  String get radioPopular200 => '热门200个';

  @override
  String get radioSleep => '睡眠';

  @override
  String get radioSchedule => '预约';

  @override
  String get sleepTimerDesc => '选择的时间后将自动关闭';

  @override
  String get sleepTimerActiveDesc => '计时器运行中';

  @override
  String get remainingTime => '剩余时间';

  @override
  String get cancelTimerX => '× 取消计时器';

  @override
  String get countryKR => '韩国';

  @override
  String get countryUS => '美国';

  @override
  String get countryJP => '日本';

  @override
  String get countryTW => '台湾';

  @override
  String get countryCN => '中国';

  @override
  String get countryHK => '香港';

  @override
  String get countryGB => '英国';

  @override
  String get countryVN => '越南';

  @override
  String get countryPH => '菲律宾';

  @override
  String get countryDE => '德国';

  @override
  String get countryFR => '法国';

  @override
  String get countryTH => '泰国';

  @override
  String get countryID => '印度尼西亚';

  @override
  String get countryIN => '印度';

  @override
  String get countryES => '西班牙';

  @override
  String get countryIT => '意大利';

  @override
  String get countryBR => '巴西';

  @override
  String get countryCA => '加拿大';

  @override
  String get countryAU => '澳大利亚';

  @override
  String get countryMX => '墨西哥';

  @override
  String get countryTR => '土耳其';

  @override
  String get countryNL => '荷兰';

  @override
  String get countrySE => '瑞典';

  @override
  String get countryPL => '波兰';

  @override
  String get countryAR => '阿根廷';

  @override
  String get countryCO => '哥伦比亚';

  @override
  String get countryNZ => '新西兰';

  @override
  String get countryMY => '马来西亚';

  @override
  String get countrySG => '新加坡';

  @override
  String get countryRU => '俄罗斯';

  @override
  String get countryZA => '南非';

  @override
  String get countryPK => '巴基斯坦';

  @override
  String get countryBD => '孟加拉国';

  @override
  String get countryLK => '斯里兰卡';

  @override
  String get countryNP => '尼泊尔';

  @override
  String get countryMM => '缅甸';

  @override
  String get countryKH => '柬埔寨';

  @override
  String get countryAT => '奥地利';

  @override
  String get countryCH => '瑞士';

  @override
  String get countryBE => '比利时';

  @override
  String get countryPT => '葡萄牙';

  @override
  String get countryGR => '希腊';

  @override
  String get countryIE => '爱尔兰';

  @override
  String get countryNO => '挪威';

  @override
  String get countryDK => '丹麦';

  @override
  String get countryFI => '芬兰';

  @override
  String get countryCZ => '捷克';

  @override
  String get countryRO => '罗马尼亚';

  @override
  String get countryUA => '乌克兰';

  @override
  String get countryEG => '埃及';

  @override
  String get countrySA => '沙特阿拉伯';

  @override
  String get countryAE => '阿联酋';

  @override
  String get countryNG => '尼日利亚';

  @override
  String get countryKE => '肯尼亚';

  @override
  String get countryCL => '智利';

  @override
  String get countryPE => '秘鲁';

  @override
  String get countryVE => '委内瑞拉';

  @override
  String get countryCU => '古巴';

  @override
  String get countryJM => '牙买加';

  @override
  String get countryIQ => '伊拉克';

  @override
  String get countryIR => '伊朗';

  @override
  String get countryIL => '以色列';

  @override
  String get countryMN => '蒙古';

  @override
  String get countryUZ => '乌兹别克斯坦';

  @override
  String get countryKZ => '哈萨克斯坦';

  @override
  String get countryLA => '老挝';

  @override
  String get countryHU => '匈牙利';

  @override
  String get countryHR => '克罗地亚';

  @override
  String get countryRS => '塞尔维亚';

  @override
  String get countryBG => '保加利亚';

  @override
  String get countrySK => '斯洛伐克';

  @override
  String get countryLT => '立陶宛';

  @override
  String get countryLV => '拉脱维亚';

  @override
  String get countryEE => '爱沙尼亚';

  @override
  String get countryIS => '冰岛';

  @override
  String get countryGH => '加纳';

  @override
  String get countryTZ => '坦桑尼亚';

  @override
  String get countryMA => '摩洛哥';

  @override
  String get countryTN => '突尼斯';

  @override
  String get countryET => '埃塞俄比亚';

  @override
  String get countryUG => '乌干达';

  @override
  String get countryEC => '厄瓜多尔';

  @override
  String get countryBO => '玻利维亚';

  @override
  String get countryPY => '巴拉圭';

  @override
  String get countryUY => '乌拉圭';

  @override
  String get countryPA => '巴拿马';

  @override
  String get countryCR => '哥斯达黎加';

  @override
  String get countryDO => '多米尼加共和国';

  @override
  String get countryTT => '特立尼达和多巴哥';

  @override
  String get countryHT => '海地';

  @override
  String get countryFJ => '斐济';

  @override
  String get countryPG => '巴布亚新几内亚';

  @override
  String get countryJO => '约旦';

  @override
  String get countryLB => '黎巴嫩';

  @override
  String get countryGE => '格鲁吉亚';

  @override
  String get countryAM => '亚美尼亚';

  @override
  String get countryAZ => '阿塞拜疆';

  @override
  String get countrySI => '斯洛文尼亚';

  @override
  String get countryAL => '阿尔巴尼亚';

  @override
  String get countryMK => '北马其顿';

  @override
  String get countryME => '黑山';

  @override
  String get countryBA => '波黑';

  @override
  String get countryMT => '马耳他';

  @override
  String get countryLU => '卢森堡';

  @override
  String get countryCY => '塞浦路斯';

  @override
  String get countryCM => '喀麦隆';

  @override
  String get countrySN => '塞内加尔';

  @override
  String get countryZW => '津巴布韦';

  @override
  String get countryMZ => '莫桑比克';

  @override
  String get countryMG => '马达加斯加';

  @override
  String get countryGT => '危地马拉';

  @override
  String get countryHN => '洪都拉斯';

  @override
  String get countryNI => '尼加拉瓜';

  @override
  String get countrySV => '萨尔瓦多';

  @override
  String get countryPR => '波多黎各';

  @override
  String get categoryNational => '全国';

  @override
  String get categorySeoulGyeonggi => '首尔/京畿';

  @override
  String get categoryRegionalMBC => '地区MBC';

  @override
  String get categoryRegionalPrivate => '地区民营';

  @override
  String get categoryTraffic => '交通广播';

  @override
  String get categoryEtc => '其他';

  @override
  String get regionAll => '全部';

  @override
  String get regionCapital => '首都圈';

  @override
  String get regionBusanGyeongnam => '釜山/庆南';

  @override
  String get regionDaeguGyeongbuk => '大邱/庆北';

  @override
  String get regionGwangjuJeonnam => '光州/全南';

  @override
  String get regionJeonbuk => '全北';

  @override
  String get regionDaejeonChungnam => '大田/忠南';

  @override
  String get regionChungbuk => '忠北';

  @override
  String get regionGangwon => '江原';

  @override
  String get regionJeju => '济州';

  @override
  String get radioNoFavorites => '没有收藏的频道';

  @override
  String get radioNoFavoritesDesc => '在频道列表中点击♡来添加收藏';

  @override
  String get radioLoadingPopular => '正在加载热门广播...';

  @override
  String radioScheduleTitle(Object station) {
    return '$station 节目表';
  }

  @override
  String get radioLoadingSchedule => '正在加载节目表...';

  @override
  String get radioBroadcastSchedule => '节目表';

  @override
  String get radioPlayFirst => '请先播放广播';

  @override
  String radioScheduleCompleteToast(Object time, Object title) {
    return '$title $time 预约完成';
  }

  @override
  String get radioPlaybackFailed => '播放失败。';

  @override
  String get radioRerun => '重播';

  @override
  String get radioLive => '● LIVE';

  @override
  String get radioStatusConnecting => '连接中...';

  @override
  String get radioStatusFailed => '连接失败';

  @override
  String get radioStatusPaused => '已暂停';

  @override
  String get radioAfterEnd => '后结束';

  @override
  String get radioNoStationsFound => '找不到广播';

  @override
  String get sleepMin => '分';

  @override
  String get sleepHour => '小时';

  @override
  String sleepMinuteUnit(Object minutes) {
    return '$minutes分';
  }

  @override
  String sleepHourUnit(Object hours) {
    return '$hours小时';
  }

  @override
  String sleepHourMinuteUnit(Object hours, Object minutes) {
    return '$hours小时$minutes分';
  }

  @override
  String sleepCountdownHMS(Object hours, Object minutes, Object seconds) {
    return '$hours小时$minutes分$seconds秒';
  }

  @override
  String sleepCountdownMS(Object minutes, Object seconds) {
    return '$minutes分$seconds秒';
  }

  @override
  String sleepCountdownS(Object seconds) {
    return '$seconds秒';
  }

  @override
  String sleepAutoStopToast(Object time) {
    return '$time后自动关闭';
  }

  @override
  String get radioKoreaTitle => '韩国广播';

  @override
  String get radioOnAirTitle => '直播中';

  @override
  String get radioKoreaSlogan => '聆听世界之声';

  @override
  String get radioSloganUS => '聆听自由之声';

  @override
  String get radioSloganJP => '日常中的小确幸';

  @override
  String get radioSloganTW => '流淌在岛屿的歌';

  @override
  String get radioSloganCN => '辽阔大地之声';

  @override
  String get radioSloganHK => '乘上城市的节奏';

  @override
  String get radioSloganGB => '传统与当代的交会';

  @override
  String get radioSloganVN => '湄公河的旋律';

  @override
  String get radioSloganPH => '群岛的回响';

  @override
  String get radioSloganDE => '欧洲心脏的声音';

  @override
  String get radioSloganFR => '生活的旋律';

  @override
  String get radioSloganTH => '暹罗之声';

  @override
  String get radioSloganID => '群岛的节奏';

  @override
  String get radioSloganIN => '印度的旋律';

  @override
  String get radioSloganES => '灵魂的节奏';

  @override
  String get radioSloganIT => '生命的乐章';

  @override
  String get radioSloganBR => '巴西之声';

  @override
  String get radioSloganCA => '穿越北方的声音';

  @override
  String get radioSloganAU => '南半球的声音';

  @override
  String get radioSloganMX => '墨西哥的节奏';

  @override
  String get radioSloganTR => '安纳托利亚之声';

  @override
  String get radioSloganNL => '低地之声';

  @override
  String get radioSloganSE => '北欧之声';

  @override
  String get radioSloganPL => '维斯瓦河的旋律';

  @override
  String get radioSloganAR => '灵魂的探戈';

  @override
  String get radioSloganCO => '哥伦比亚的节奏';

  @override
  String get radioSloganNZ => '奥特亚罗瓦的回响';

  @override
  String get radioSloganMY => '马来西亚的节奏';

  @override
  String get radioSloganSG => '狮城的律动';

  @override
  String get radioSloganRU => '俄罗斯之声';

  @override
  String get radioSloganZA => '彩虹国度之声';

  @override
  String get radioSloganPK => '巴基斯坦的旋律';

  @override
  String get radioSloganBD => '孟加拉之声';

  @override
  String get radioSloganLK => '斯里兰卡之声';

  @override
  String get radioSloganNP => '喜马拉雅的旋律';

  @override
  String get radioSloganMM => '缅甸之声';

  @override
  String get radioSloganKH => '吴哥之声';

  @override
  String get radioSloganAT => '阿尔卑斯的回响';

  @override
  String get radioSloganCH => '瑞士之声';

  @override
  String get radioSloganBE => '比利时的回响';

  @override
  String get radioSloganPT => '葡萄牙之声';

  @override
  String get radioSloganGR => '希腊之声';

  @override
  String get radioSloganIE => '翡翠岛之声';

  @override
  String get radioSloganNO => '峡湾之声';

  @override
  String get radioSloganDK => '丹麦之声';

  @override
  String get radioSloganFI => '芬兰之声';

  @override
  String get radioSloganCZ => '波希米亚之声';

  @override
  String get radioSloganRO => '罗马尼亚之声';

  @override
  String get radioSloganUA => '乌克兰之声';

  @override
  String get radioSloganEG => '尼罗河之声';

  @override
  String get radioSloganSA => '阿拉伯之声';

  @override
  String get radioSloganAE => '海湾之声';

  @override
  String get radioSloganNG => '尼日利亚之声';

  @override
  String get radioSloganKE => '肯尼亚之声';

  @override
  String get radioSloganCL => '智利之声';

  @override
  String get radioSloganPE => '秘鲁之声';

  @override
  String get radioSloganVE => '委内瑞拉的节奏';

  @override
  String get radioSloganCU => '古巴的节奏';

  @override
  String get radioSloganJM => '牙买加的节奏';

  @override
  String get radioSloganIQ => '美索不达米亚之声';

  @override
  String get radioSloganIR => '伊朗的旋律';

  @override
  String get radioSloganIL => '以色列之声';

  @override
  String get radioSloganMN => '草原的旋律';

  @override
  String get radioSloganUZ => '乌兹别克斯坦之声';

  @override
  String get radioSloganKZ => '哈萨克斯坦之声';

  @override
  String get radioSloganLA => '老挝之声';

  @override
  String get radioSloganHU => '多瑙河之声';

  @override
  String get radioSloganHR => '亚得里亚海之声';

  @override
  String get radioSloganRS => '塞尔维亚之声';

  @override
  String get radioSloganBG => '保加利亚之声';

  @override
  String get radioSloganSK => '斯洛伐克之声';

  @override
  String get radioSloganLT => '立陶宛之声';

  @override
  String get radioSloganLV => '拉脱维亚之声';

  @override
  String get radioSloganEE => '爱沙尼亚之声';

  @override
  String get radioSloganIS => '冰岛之声';

  @override
  String get radioSloganGH => '加纳之声';

  @override
  String get radioSloganTZ => '坦桑尼亚之声';

  @override
  String get radioSloganMA => '摩洛哥之声';

  @override
  String get radioSloganTN => '突尼斯之声';

  @override
  String get radioSloganET => '埃塞俄比亚之声';

  @override
  String get radioSloganUG => '乌干达之声';

  @override
  String get radioSloganEC => '厄瓜多尔之声';

  @override
  String get radioSloganBO => '玻利维亚之声';

  @override
  String get radioSloganPY => '巴拉圭之声';

  @override
  String get radioSloganUY => '乌拉圭之声';

  @override
  String get radioSloganPA => '巴拿马之声';

  @override
  String get radioSloganCR => '哥斯达黎加之声';

  @override
  String get radioSloganDO => '多米尼加的节奏';

  @override
  String get radioSloganTT => '特立尼达之声';

  @override
  String get radioSloganHT => '海地之声';

  @override
  String get selectSong => '选择歌曲';

  @override
  String get selectRange => '选择范围';

  @override
  String get start => '开始';

  @override
  String get end => '结束';

  @override
  String get deselectAll => '取消全选';

  @override
  String get exit => '退出';

  @override
  String get timerLabel => '定时器';

  @override
  String get playbackSpeedLabel => '播放速度';

  @override
  String get updateReadyTitle => '更新已就绪';

  @override
  String get updateReadyMessage => '新功能已下载完成。\n建议立即重新启动。';

  @override
  String get updateReadyButton => '立即重新启动';

  @override
  String get updateReadyLater => '稍后';

  @override
  String get radioNextProgram => '下一节目';

  @override
  String get radioExitConfirmTitle => '要结束广播吗？';

  @override
  String get radioExitConfirmMessage => '现在离开将停止播放。';

  @override
  String get radioExitKeepListening => '继续收听';

  @override
  String get radioExitConfirmButton => '结束';

  @override
  String get darkMode => '深色模式';

  @override
  String get darkModeOn => '开启';

  @override
  String get darkModeOff => '关闭';

  @override
  String get rateApp => '给应用评分';

  @override
  String get musicExitConfirmTitle => '要结束音乐吗？';

  @override
  String get musicExitConfirmMessage => '现在离开将停止播放。';

  @override
  String get homeNewSongs => '新加入的歌曲';

  @override
  String get homeTipWidgetTitle => '添加桌面小组件';

  @override
  String get homeTipWidgetSub => '长按桌面 → 小组件 → Paransori';

  @override
  String get homeTipAlarmTitle => '用闹钟叫你起床';

  @override
  String get homeTipAlarmSub => '用音乐、广播或自然声音唤醒';

  @override
  String get homeTipScheduleTitle => '定时开启广播';

  @override
  String get homeTipScheduleSub => '广播播放画面下方的[预约]';

  @override
  String get homeTipCastTitle => '投放到电视或音箱';

  @override
  String get homeTipCastSub => '同一Wi-Fi下，从播放画面⋮菜单';

  @override
  String get homeTipSleepTitle => '睡前用睡眠计时器';

  @override
  String get homeTipSleepSub => '点播放画面下方的[睡眠]';

  @override
  String get homeTodayTip => '今日小贴士';

  @override
  String get accentColor => '强调色';

  @override
  String get homeColorTitle => '换上你喜欢的颜色';

  @override
  String get homeColorSub => '森林、晚霞、樱花等10种颜色';

  @override
  String get homeColorAction => '选择';

  @override
  String get homeColorQuestion => '今天的心情配什么颜色？';

  @override
  String get homeColorHint => '之后可在设置中\n随时更改。';

  @override
  String get done => '完成';

  @override
  String get homeStartTitle => '设为启动画面吗？';

  @override
  String get homeStartMessage => '打开Paransori时会先显示这个画面。';

  @override
  String get homeStartConfirm => '设置';

  @override
  String deleteSongsTitle(int count) {
    return '要删除$count首歌曲吗？';
  }

  @override
  String get deleteSongsMessage => '所选歌曲将从手机中删除';

  @override
  String deletedSongsToast(int count) {
    return '已删除$count首歌曲';
  }

  @override
  String get couldNotDelete => '删除失败';

  @override
  String get menuShareTitle => '分享给朋友';

  @override
  String get menuShareSub => '把Paransori\n推荐给朋友吧。';

  @override
  String get shareAppMessage => '我在用Paransori听音乐！🎧';

  @override
  String get menuRateTitle => '给应用评分';

  @override
  String get menuRateSub => '您的好评\n是我们的动力。';

  @override
  String get menuSettingsSub => '可以调整\n应用设置。';

  @override
  String get menuRadioTitle => '广播电台';

  @override
  String get menuRadioSub => '马上收听\n各种广播节目。';

  @override
  String get recentSearches => '最近搜索';

  @override
  String get clearAll => '全部清除';

  @override
  String get catMusic => '音乐';

  @override
  String get catMusicSub => '我的音乐 · MP3播放器';

  @override
  String get catRadio => '广播';

  @override
  String get catRadioSub => '全球广播 · 收藏';

  @override
  String get catNature => '自然';

  @override
  String get catNatureSub => '雨 · 风 · 森林 · 海浪';

  @override
  String get catRest => '休息 · 专注';

  @override
  String get catRestSub => '白噪音 · 专注（准备中）';

  @override
  String get homeSoundsHeader => '来听听这些声音吧';

  @override
  String get homeRestHeader => '休息一下吧';

  @override
  String get homeRecentHeader => '最近收听';

  @override
  String get homeRecentEmpty => '还没有收听记录';

  @override
  String get homeRecentEmptySub => '收听超过30秒的内容会显示在这里';

  @override
  String get cleanLabel => '整理歌曲';

  @override
  String cleanTitle(int count) {
    return '整理$count个歌曲标题';
  }

  @override
  String get later => '稍后';

  @override
  String get cleanAction => '整理';

  @override
  String get dailyOftenMorning => '早上常听的歌';

  @override
  String get dailyOftenDay => '白天常听的歌';

  @override
  String get dailyOftenEvening => '傍晚常听的歌';

  @override
  String get dailyOftenNight => '夜里常听的歌';

  @override
  String get dailyLongTime => '好久没听的歌';

  @override
  String get dailySongOfDay => '今日歌曲';

  @override
  String get dailyHowAboutThis => '今天听这首怎么样';

  @override
  String get listen => '播放';

  @override
  String get dailyListenAgain => '再听一次';

  @override
  String dailyNotPlayedTitle(int count) {
    return '一个月没听的歌 $count首';
  }

  @override
  String get dailyNotPlayedSub => '要不要再听听？';

  @override
  String get dailyShufflePlay => '播放';

  @override
  String get dailyMyStats => '我的记录';

  @override
  String dailyWeekCount(int count) {
    return '最近7天听了$count次';
  }

  @override
  String get dailyMostPlayed => '最常听';

  @override
  String get dailyMorningTitle => '清爽的早晨';

  @override
  String get dailyMorningLine => '用鸟鸣开启新的一天';

  @override
  String get dailyDayTitle => '休息一下吧';

  @override
  String get dailyDayLine => '听着溪水声喘口气';

  @override
  String get dailyEveningTitle => '今天也辛苦了';

  @override
  String get dailyEveningLine => '听着海浪声放松';

  @override
  String get dailyNightTitle => '深夜静静地听';

  @override
  String get dailyNightLine => '听着雨声放松';

  @override
  String get dailyRightNow => '此刻';

  @override
  String get dailyTipBatteryTitle => '熄屏也能继续播放';

  @override
  String get dailyTipBatterySub => '将电池设为\"无限制\"';

  @override
  String get dailyTipRingtoneTitle => '把歌曲设为铃声';

  @override
  String get dailyTipRingtoneSub => '在歌曲⋮菜单中设置';

  @override
  String get dailyTipVideoTitle => '只保存视频里的音乐';

  @override
  String get dailyTipVideoSub => '视频⋮菜单 → \"保存为音乐\"';

  @override
  String get dailyTipMixTitle => '给音乐加上雨声';

  @override
  String get dailyTipMixSub => '播放画面⋮菜单 → 自然声音混音';

  @override
  String get dailyTipLyricsTitle => '分享一句歌词';

  @override
  String get dailyTipLyricsSub => '长按歌词即可生成卡片分享';

  @override
  String get dailyOffTitle => '要关闭今日卡片吗？';

  @override
  String get dailyOffMessage => '可随时在设置中重新开启';

  @override
  String get turnOff => '关闭';

  @override
  String get dailyOffKeep => '继续显示';

  @override
  String get callRecordingsChip => '通话录音 ›';

  @override
  String get sortedByArtist => '已按歌手排序';

  @override
  String get sortedByTitle => '已按标题排序';

  @override
  String get sortArtist => '歌手';

  @override
  String get sortTitle => '标题';

  @override
  String get today => '今天';

  @override
  String get yesterday => '昨天';

  @override
  String get within3Days => '3天内';

  @override
  String get withinWeek => '一周内';

  @override
  String get colorParansori => 'Paransori';

  @override
  String get colorForest => '森林';

  @override
  String get colorSunset => '晚霞';

  @override
  String get colorLavender => '薰衣草';

  @override
  String get colorInk => '墨色';

  @override
  String get colorBlossom => '樱花';

  @override
  String get colorOcean => '海洋';

  @override
  String get colorSunlight => '阳光';

  @override
  String get colorWine => '酒红';

  @override
  String get colorNightSky => '夜空';
}

/// The translations for Chinese, using the Han script (`zh_Hant`).
class AppLocalizationsZhHant extends AppLocalizationsZh {
  AppLocalizationsZhHant() : super('zh_Hant');

  @override
  String get appName => 'Paransori';

  @override
  String get songs => '歌曲';

  @override
  String get albums => '專輯';

  @override
  String get artists => '藝術家';

  @override
  String get playlists => '播放清單';

  @override
  String get folders => '資料夾';

  @override
  String get videos => '影片';

  @override
  String get settings => '設定';

  @override
  String get search => '搜尋';

  @override
  String get favorites => '我的最愛';

  @override
  String get recent => '最近';

  @override
  String get all => '全部';

  @override
  String get play => '播放';

  @override
  String get pause => '暫停';

  @override
  String get next => '下一首';

  @override
  String get previous => '上一首';

  @override
  String get shuffle => '隨機播放';

  @override
  String get repeat => '重複';

  @override
  String get nowPlaying => '播放中';

  @override
  String get noSongs => '找不到MP3檔案';

  @override
  String get addMusic => '請將音樂檔案新增至裝置';

  @override
  String get scanningMusic => '正在掃描音樂...';

  @override
  String get editSong => '編輯歌曲資訊';

  @override
  String get save => '儲存';

  @override
  String get cancel => '取消';

  @override
  String get delete => '刪除';

  @override
  String get title => '標題';

  @override
  String get artist => '藝術家';

  @override
  String get album => '專輯';

  @override
  String get share => '分享';

  @override
  String get songInfo => '歌曲資訊';

  @override
  String get equalizer => '等化器';

  @override
  String get sleepTimer => '睡眠計時器';

  @override
  String get playbackSpeed => '播放速度';

  @override
  String get repeatMode => '重複模式';

  @override
  String get noRepeat => '不重複';

  @override
  String get repeatOne => '單曲重複';

  @override
  String get repeatAll => '全部重複';

  @override
  String get textSize => '文字大小';

  @override
  String get fontChange => '字體變更';

  @override
  String get playerStyle => '播放器樣式';

  @override
  String get flashlight => '手電筒';

  @override
  String get sos => 'SOS緊急燈';

  @override
  String get ringtone => '設定鈴聲';

  @override
  String get widget => '主畫面小工具';

  @override
  String get version => '版本資訊';

  @override
  String get promoCode => '促銷代碼';

  @override
  String get privacyPolicy => '隱私權政策';

  @override
  String get termsOfService => '服務條款';

  @override
  String get noRecentSongs => '沒有最近播放的歌曲';

  @override
  String get playMusic => '播放一些音樂吧';

  @override
  String get clearRecent => '清除最近播放';

  @override
  String get clearRecentConfirm => '要清除所有最近播放的歌曲嗎？';

  @override
  String get playAll => '全部播放';

  @override
  String get noAlbums => '找不到專輯';

  @override
  String get noArtists => '找不到藝術家';

  @override
  String get searchAlbums => '搜尋專輯...';

  @override
  String get searchArtists => '搜尋藝術家...';

  @override
  String get close => '關閉';

  @override
  String get defaultValue => '預設';

  @override
  String get preview => '預覽';

  @override
  String get playing => '播放中...';

  @override
  String get ringtoneFailed => '設定鈴聲失敗';

  @override
  String get promoInvalid => '無效的代碼';

  @override
  String get promoEnter => '請輸入促銷代碼';

  @override
  String get confirm => '確認';

  @override
  String get permissionRequired => '需要儲存空間權限';

  @override
  String get permissionMessage => '需要儲存空間權限\n才能掃描MP3檔案。';

  @override
  String get allowPermission => '允許權限';

  @override
  String get retry => '重試';

  @override
  String get deleteSong => '刪除歌曲';

  @override
  String get deleted => '已刪除';

  @override
  String get deleteFailed => '刪除失敗';

  @override
  String get playNext => '下一首播放';

  @override
  String get searchHint => '搜尋歌曲、藝術家、專輯...';

  @override
  String get timerCancel => '取消計時器';

  @override
  String get set => '設定';

  @override
  String get small => '小';

  @override
  String get large => '大';

  @override
  String get apply => '套用';

  @override
  String get songCount => '首';

  @override
  String get on => '開啟';

  @override
  String get off => '關閉';

  @override
  String get flashlightError => '手電筒錯誤';

  @override
  String get minuteShort => '分';

  @override
  String get hourShort => '時';

  @override
  String get privacyPolicyUrl => 'https://www.ssing.kr/privacy_policy_zh.html';

  @override
  String get termsOfServiceUrl =>
      'https://www.ssing.kr/terms_of_service_zh.html';

  @override
  String get preset => '預設';

  @override
  String get bassBooster => '低音增強';

  @override
  String get enhancesBass => '增強低音效果';

  @override
  String get virtualizer => '虛擬環繞';

  @override
  String get surroundEffect => '創造環繞音效';

  @override
  String get reset => '重置';

  @override
  String get reviewTitle => '您喜歡 Paransori 嗎？';

  @override
  String get reviewMessage => '請留下評分！\n這將幫助我們改善應用程式 😊';

  @override
  String get reviewButton => '⭐ 留下評分';

  @override
  String get reviewLater => '稍後再說';

  @override
  String get fontDefault => '預設字體';

  @override
  String get fontNotoSans => 'Noto Sans KR (簡潔)';

  @override
  String get fontJua => 'Jua (可愛)';

  @override
  String get fontGaegu => 'Gaegu (手寫)';

  @override
  String get fontNanumGothic => 'Nanum Gothic (柔和)';

  @override
  String get fontDoHyeon => 'Do Hyeon (現代)';

  @override
  String get fontCuteFont => 'Cute Font (可愛)';

  @override
  String get fontStylish => 'Stylish (優雅)';

  @override
  String get fontSunflower => 'Sunflower (輕盈)';

  @override
  String get fontHiMelody => 'Hi Melody (感性)';

  @override
  String get fontPoorStory => 'Poor Story (手寫)';

  @override
  String get fontEastSeaDokdo => 'East Sea Dokdo (獨特)';

  @override
  String get fontNanumBrush => 'Nanum Brush Script (毛筆)';

  @override
  String get fontNanumMyeongjo => 'Nanum Myeongjo (明體)';

  @override
  String get fontBlackAndWhite => 'Black And White Picture (特別)';

  @override
  String get fontGowunDodum => 'Gowun Dodum (圓潤)';

  @override
  String get fontGowunBatang => 'Gowun Batang (仿宋)';

  @override
  String get fontNanumPen => 'Nanum Pen Script (鋼筆)';

  @override
  String get fontSingleDay => 'Single Day (可愛)';

  @override
  String get fontYeonSung => 'Yeon Sung (柔和)';

  @override
  String get styleCD => 'CD旋轉';

  @override
  String get styleCard => '專輯封面卡片';

  @override
  String get hourWord => '小時';

  @override
  String autoStopFormat(Object time) {
    return '$time後自動關閉';
  }

  @override
  String get autoStopCountdownSuffix => '後自動結束';

  @override
  String get secondShort => '秒';

  @override
  String get unknownArtist => '未知藝術家';

  @override
  String get unknownAlbum => '未知專輯';

  @override
  String get noTitle => '無標題';

  @override
  String selectedCount(Object count) {
    return '已選擇$count項';
  }

  @override
  String get selectAll => '全選';

  @override
  String get noVideosFound => '找不到影片';

  @override
  String get rename => '重新命名';

  @override
  String get playTime => '播放時間';

  @override
  String get path => '路徑';

  @override
  String get playlistNameHint => '播放清單名稱';

  @override
  String get create => '建立';

  @override
  String get playlistLabel => '播放清單';

  @override
  String get change => '變更';

  @override
  String get songCountSuffix => '首';

  @override
  String get lyrics => '歌詞';

  @override
  String get lyricsLoading => '正在載入歌詞...';

  @override
  String get lyricsErrorNotFound => '找不到歌詞';

  @override
  String get lyricsErrorNetwork => '請確認網路連線';

  @override
  String get justNow => '剛剛';

  @override
  String minutesAgo(Object minutes) {
    return '$minutes分鐘前';
  }

  @override
  String hoursAgo(Object hours) {
    return '$hours小時前';
  }

  @override
  String dateFormat(Object day, Object month, Object year) {
    return '$year年$month月$day日';
  }

  @override
  String get radioTitle => '廣播';

  @override
  String get radioRecentListening => '最近收聽';

  @override
  String get radioSelectCountry => '選擇國家';

  @override
  String get radioChannelCount => '個頻道';

  @override
  String get radioPopular200 => '熱門200個';

  @override
  String get radioSleep => '睡眠';

  @override
  String get radioSchedule => '預約';

  @override
  String get sleepTimerDesc => '選擇的時間後將自動關閉';

  @override
  String get sleepTimerActiveDesc => '計時器運作中';

  @override
  String get remainingTime => '剩餘時間';

  @override
  String get cancelTimerX => '× 取消計時器';

  @override
  String get countryKR => '韓國';

  @override
  String get countryUS => '美國';

  @override
  String get countryJP => '日本';

  @override
  String get countryTW => '台灣';

  @override
  String get countryCN => '中國';

  @override
  String get countryHK => '香港';

  @override
  String get countryGB => '英國';

  @override
  String get countryVN => '越南';

  @override
  String get countryPH => '菲律賓';

  @override
  String get countryDE => '德國';

  @override
  String get countryFR => '法國';

  @override
  String get countryTH => '泰國';

  @override
  String get countryID => '印尼';

  @override
  String get countryIN => '印度';

  @override
  String get countryES => '西班牙';

  @override
  String get countryIT => '義大利';

  @override
  String get countryBR => '巴西';

  @override
  String get countryCA => '加拿大';

  @override
  String get countryAU => '澳洲';

  @override
  String get countryMX => '墨西哥';

  @override
  String get countryTR => '土耳其';

  @override
  String get countryNL => '荷蘭';

  @override
  String get countrySE => '瑞典';

  @override
  String get countryPL => '波蘭';

  @override
  String get countryAR => '阿根廷';

  @override
  String get countryCO => '哥倫比亞';

  @override
  String get countryNZ => '紐西蘭';

  @override
  String get countryMY => '馬來西亞';

  @override
  String get countrySG => '新加坡';

  @override
  String get countryRU => '俄羅斯';

  @override
  String get countryZA => '南非';

  @override
  String get countryPK => '巴基斯坦';

  @override
  String get countryBD => '孟加拉';

  @override
  String get countryLK => '斯里蘭卡';

  @override
  String get countryNP => '尼泊爾';

  @override
  String get countryMM => '緬甸';

  @override
  String get countryKH => '柬埔寨';

  @override
  String get countryAT => '奧地利';

  @override
  String get countryCH => '瑞士';

  @override
  String get countryBE => '比利時';

  @override
  String get countryPT => '葡萄牙';

  @override
  String get countryGR => '希臘';

  @override
  String get countryIE => '愛爾蘭';

  @override
  String get countryNO => '挪威';

  @override
  String get countryDK => '丹麥';

  @override
  String get countryFI => '芬蘭';

  @override
  String get countryCZ => '捷克';

  @override
  String get countryRO => '羅馬尼亞';

  @override
  String get countryUA => '烏克蘭';

  @override
  String get countryEG => '埃及';

  @override
  String get countrySA => '沙烏地阿拉伯';

  @override
  String get countryAE => '阿聯酋';

  @override
  String get countryNG => '奈及利亞';

  @override
  String get countryKE => '肯亞';

  @override
  String get countryCL => '智利';

  @override
  String get countryPE => '秘魯';

  @override
  String get countryVE => '委內瑞拉';

  @override
  String get countryCU => '古巴';

  @override
  String get countryJM => '牙買加';

  @override
  String get countryIQ => '伊拉克';

  @override
  String get countryIR => '伊朗';

  @override
  String get countryIL => '以色列';

  @override
  String get countryMN => '蒙古';

  @override
  String get countryUZ => '烏茲別克';

  @override
  String get countryKZ => '哈薩克';

  @override
  String get countryLA => '寮國';

  @override
  String get countryHU => '匈牙利';

  @override
  String get countryHR => '克羅埃西亞';

  @override
  String get countryRS => '塞爾維亞';

  @override
  String get countryBG => '保加利亞';

  @override
  String get countrySK => '斯洛伐克';

  @override
  String get countryLT => '立陶宛';

  @override
  String get countryLV => '拉脫維亞';

  @override
  String get countryEE => '愛沙尼亞';

  @override
  String get countryIS => '冰島';

  @override
  String get countryGH => '迦納';

  @override
  String get countryTZ => '坦尚尼亞';

  @override
  String get countryMA => '摩洛哥';

  @override
  String get countryTN => '突尼西亞';

  @override
  String get countryET => '衣索比亞';

  @override
  String get countryUG => '烏干達';

  @override
  String get countryEC => '厄瓜多';

  @override
  String get countryBO => '玻利維亞';

  @override
  String get countryPY => '巴拉圭';

  @override
  String get countryUY => '烏拉圭';

  @override
  String get countryPA => '巴拿馬';

  @override
  String get countryCR => '哥斯大黎加';

  @override
  String get countryDO => '多明尼加共和國';

  @override
  String get countryTT => '千里達及托巴哥';

  @override
  String get countryHT => '海地';

  @override
  String get countryFJ => '斐濟';

  @override
  String get countryPG => '巴布亞紐幾內亞';

  @override
  String get countryJO => '約旦';

  @override
  String get countryLB => '黎巴嫩';

  @override
  String get countryGE => '喬治亞';

  @override
  String get countryAM => '亞美尼亞';

  @override
  String get countryAZ => '亞塞拜然';

  @override
  String get countrySI => '斯洛維尼亞';

  @override
  String get countryAL => '阿爾巴尼亞';

  @override
  String get countryMK => '北馬其頓';

  @override
  String get countryME => '蒙特內哥羅';

  @override
  String get countryBA => '波士尼亞';

  @override
  String get countryMT => '馬爾他';

  @override
  String get countryLU => '盧森堡';

  @override
  String get countryCY => '賽普勒斯';

  @override
  String get countryCM => '喀麥隆';

  @override
  String get countrySN => '塞內加爾';

  @override
  String get countryZW => '辛巴威';

  @override
  String get countryMZ => '莫三比克';

  @override
  String get countryMG => '馬達加斯加';

  @override
  String get countryGT => '瓜地馬拉';

  @override
  String get countryHN => '宏都拉斯';

  @override
  String get countryNI => '尼加拉瓜';

  @override
  String get countrySV => '薩爾瓦多';

  @override
  String get countryPR => '波多黎各';

  @override
  String get categoryNational => '全國';

  @override
  String get categorySeoulGyeonggi => '首爾/京畿';

  @override
  String get categoryRegionalMBC => '地區MBC';

  @override
  String get categoryRegionalPrivate => '地區民營';

  @override
  String get categoryTraffic => '交通廣播';

  @override
  String get categoryEtc => '其他';

  @override
  String get regionAll => '全部';

  @override
  String get regionCapital => '首都圈';

  @override
  String get regionBusanGyeongnam => '釜山/慶南';

  @override
  String get regionDaeguGyeongbuk => '大邱/慶北';

  @override
  String get regionGwangjuJeonnam => '光州/全南';

  @override
  String get regionJeonbuk => '全北';

  @override
  String get regionDaejeonChungnam => '大田/忠南';

  @override
  String get regionChungbuk => '忠北';

  @override
  String get regionGangwon => '江原';

  @override
  String get regionJeju => '濟州';

  @override
  String get radioNoFavorites => '沒有收藏的頻道';

  @override
  String get radioNoFavoritesDesc => '在頻道列表中點擊♡來新增收藏';

  @override
  String get radioLoadingPopular => '正在載入熱門廣播...';

  @override
  String radioScheduleTitle(Object station) {
    return '$station 節目表';
  }

  @override
  String get radioLoadingSchedule => '正在載入節目表...';

  @override
  String get radioBroadcastSchedule => '節目表';

  @override
  String get radioPlayFirst => '請先播放廣播';

  @override
  String radioScheduleCompleteToast(Object time, Object title) {
    return '$title $time 預約完成';
  }

  @override
  String get radioPlaybackFailed => '播放失敗。';

  @override
  String get radioRerun => '重播';

  @override
  String get radioLive => '● LIVE';

  @override
  String get radioStatusConnecting => '連線中...';

  @override
  String get radioStatusFailed => '連線失敗';

  @override
  String get radioStatusPaused => '已暫停';

  @override
  String get radioAfterEnd => '後結束';

  @override
  String get radioNoStationsFound => '找不到廣播';

  @override
  String get sleepMin => '分';

  @override
  String get sleepHour => '小時';

  @override
  String sleepMinuteUnit(Object minutes) {
    return '$minutes分';
  }

  @override
  String sleepHourUnit(Object hours) {
    return '$hours小時';
  }

  @override
  String sleepHourMinuteUnit(Object hours, Object minutes) {
    return '$hours小時$minutes分';
  }

  @override
  String sleepCountdownHMS(Object hours, Object minutes, Object seconds) {
    return '$hours小時$minutes分$seconds秒';
  }

  @override
  String sleepCountdownMS(Object minutes, Object seconds) {
    return '$minutes分$seconds秒';
  }

  @override
  String sleepCountdownS(Object seconds) {
    return '$seconds秒';
  }

  @override
  String sleepAutoStopToast(Object time) {
    return '$time後自動關閉';
  }

  @override
  String get radioKoreaTitle => '韓國廣播';

  @override
  String get radioOnAirTitle => '直播中';

  @override
  String get radioKoreaSlogan => '聆聽世界之聲';

  @override
  String get radioSloganUS => '聆聽自由之聲';

  @override
  String get radioSloganJP => '日常中的小確幸';

  @override
  String get radioSloganTW => '流淌在島嶼的歌';

  @override
  String get radioSloganCN => '遼闊大地之聲';

  @override
  String get radioSloganHK => '乘上城市的節奏';

  @override
  String get radioSloganGB => '傳統與當代的交會';

  @override
  String get radioSloganVN => '湄公河的旋律';

  @override
  String get radioSloganPH => '群島的迴響';

  @override
  String get radioSloganDE => '歐洲心臟的聲音';

  @override
  String get radioSloganFR => '生活的旋律';

  @override
  String get radioSloganTH => '暹羅之聲';

  @override
  String get radioSloganID => '群島的節奏';

  @override
  String get radioSloganIN => '印度的旋律';

  @override
  String get radioSloganES => '靈魂的節奏';

  @override
  String get radioSloganIT => '生命的樂章';

  @override
  String get radioSloganBR => '巴西之聲';

  @override
  String get radioSloganCA => '穿越北方的聲音';

  @override
  String get radioSloganAU => '南半球的聲音';

  @override
  String get radioSloganMX => '墨西哥的節奏';

  @override
  String get radioSloganTR => '安納托利亞之聲';

  @override
  String get radioSloganNL => '低地之聲';

  @override
  String get radioSloganSE => '北歐之聲';

  @override
  String get radioSloganPL => '維斯瓦河的旋律';

  @override
  String get radioSloganAR => '靈魂的探戈';

  @override
  String get radioSloganCO => '哥倫比亞的節奏';

  @override
  String get radioSloganNZ => '奧特亞羅瓦的迴響';

  @override
  String get radioSloganMY => '馬來西亞的節奏';

  @override
  String get radioSloganSG => '獅城的律動';

  @override
  String get radioSloganRU => '俄羅斯之聲';

  @override
  String get radioSloganZA => '彩虹國度之聲';

  @override
  String get radioSloganPK => '巴基斯坦的旋律';

  @override
  String get radioSloganBD => '孟加拉之聲';

  @override
  String get radioSloganLK => '斯里蘭卡之聲';

  @override
  String get radioSloganNP => '喜馬拉雅的旋律';

  @override
  String get radioSloganMM => '緬甸之聲';

  @override
  String get radioSloganKH => '吳哥之聲';

  @override
  String get radioSloganAT => '阿爾卑斯的迴響';

  @override
  String get radioSloganCH => '瑞士之聲';

  @override
  String get radioSloganBE => '比利時的迴響';

  @override
  String get radioSloganPT => '葡萄牙之聲';

  @override
  String get radioSloganGR => '希臘之聲';

  @override
  String get radioSloganIE => '翡翠島之聲';

  @override
  String get radioSloganNO => '峽灣之聲';

  @override
  String get radioSloganDK => '丹麥之聲';

  @override
  String get radioSloganFI => '芬蘭之聲';

  @override
  String get radioSloganCZ => '波希米亞之聲';

  @override
  String get radioSloganRO => '羅馬尼亞之聲';

  @override
  String get radioSloganUA => '烏克蘭之聲';

  @override
  String get radioSloganEG => '尼羅河之聲';

  @override
  String get radioSloganSA => '阿拉伯之聲';

  @override
  String get radioSloganAE => '海灣之聲';

  @override
  String get radioSloganNG => '奈及利亞之聲';

  @override
  String get radioSloganKE => '肯亞之聲';

  @override
  String get radioSloganCL => '智利之聲';

  @override
  String get radioSloganPE => '秘魯之聲';

  @override
  String get radioSloganVE => '委內瑞拉的節奏';

  @override
  String get radioSloganCU => '古巴的節奏';

  @override
  String get radioSloganJM => '牙買加的節奏';

  @override
  String get radioSloganIQ => '美索不達米亞之聲';

  @override
  String get radioSloganIR => '伊朗的旋律';

  @override
  String get radioSloganIL => '以色列之聲';

  @override
  String get radioSloganMN => '草原的旋律';

  @override
  String get radioSloganUZ => '烏茲別克之聲';

  @override
  String get radioSloganKZ => '哈薩克之聲';

  @override
  String get radioSloganLA => '寮國之聲';

  @override
  String get radioSloganHU => '多瑙河之聲';

  @override
  String get radioSloganHR => '亞得里亞海之聲';

  @override
  String get radioSloganRS => '塞爾維亞之聲';

  @override
  String get radioSloganBG => '保加利亞之聲';

  @override
  String get radioSloganSK => '斯洛伐克之聲';

  @override
  String get radioSloganLT => '立陶宛之聲';

  @override
  String get radioSloganLV => '拉脫維亞之聲';

  @override
  String get radioSloganEE => '愛沙尼亞之聲';

  @override
  String get radioSloganIS => '冰島之聲';

  @override
  String get radioSloganGH => '迦納之聲';

  @override
  String get radioSloganTZ => '坦尚尼亞之聲';

  @override
  String get radioSloganMA => '摩洛哥之聲';

  @override
  String get radioSloganTN => '突尼西亞之聲';

  @override
  String get radioSloganET => '衣索比亞之聲';

  @override
  String get radioSloganUG => '烏干達之聲';

  @override
  String get radioSloganEC => '厄瓜多之聲';

  @override
  String get radioSloganBO => '玻利維亞之聲';

  @override
  String get radioSloganPY => '巴拉圭之聲';

  @override
  String get radioSloganUY => '烏拉圭之聲';

  @override
  String get radioSloganPA => '巴拿馬之聲';

  @override
  String get radioSloganCR => '哥斯大黎加之聲';

  @override
  String get radioSloganDO => '多明尼加的節奏';

  @override
  String get radioSloganTT => '千里達之聲';

  @override
  String get radioSloganHT => '海地之聲';

  @override
  String get selectSong => '選擇歌曲';

  @override
  String get selectRange => '選擇範圍';

  @override
  String get start => '開始';

  @override
  String get end => '結束';

  @override
  String get deselectAll => '取消全選';

  @override
  String get exit => '退出';

  @override
  String get timerLabel => '定時器';

  @override
  String get playbackSpeedLabel => '播放速度';

  @override
  String get updateReadyTitle => '更新已就緒';

  @override
  String get updateReadyMessage => '新功能已下載完成。\n建議立即重新啟動。';

  @override
  String get updateReadyButton => '立即重新啟動';

  @override
  String get updateReadyLater => '稍後';

  @override
  String get radioNextProgram => '下一節目';

  @override
  String get radioExitConfirmTitle => '要結束收音機嗎？';

  @override
  String get radioExitConfirmMessage => '現在離開將停止播放。';

  @override
  String get radioExitKeepListening => '繼續收聽';

  @override
  String get radioExitConfirmButton => '結束';

  @override
  String get darkMode => '深色模式';

  @override
  String get darkModeOn => '開啟';

  @override
  String get darkModeOff => '關閉';

  @override
  String get rateApp => '評分應用程式';

  @override
  String get musicExitConfirmTitle => '要結束音樂嗎？';

  @override
  String get musicExitConfirmMessage => '現在離開將停止播放。';

  @override
  String get homeNewSongs => '新加入的歌曲';

  @override
  String get homeTipWidgetTitle => '新增主畫面小工具';

  @override
  String get homeTipWidgetSub => '長按主畫面 → 小工具 → Paransori';

  @override
  String get homeTipAlarmTitle => '用鬧鐘叫你起床';

  @override
  String get homeTipAlarmSub => '用音樂、廣播或自然聲音喚醒';

  @override
  String get homeTipScheduleTitle => '定時開啟廣播';

  @override
  String get homeTipScheduleSub => '廣播播放畫面下方的[預約]';

  @override
  String get homeTipCastTitle => '投放到電視或喇叭';

  @override
  String get homeTipCastSub => '同一Wi-Fi下，從播放畫面⋮選單';

  @override
  String get homeTipSleepTitle => '睡前用睡眠計時器';

  @override
  String get homeTipSleepSub => '點播放畫面下方的[睡眠]';

  @override
  String get homeTodayTip => '今日小提示';

  @override
  String get accentColor => '強調色';

  @override
  String get homeColorTitle => '換上你喜歡的顏色';

  @override
  String get homeColorSub => '森林、晚霞、櫻花等10種顏色';

  @override
  String get homeColorAction => '選擇';

  @override
  String get homeColorQuestion => '今天的心情配什麼顏色？';

  @override
  String get homeColorHint => '之後可在設定中\n隨時更改。';

  @override
  String get done => '完成';

  @override
  String get homeStartTitle => '設為啟動畫面嗎？';

  @override
  String get homeStartMessage => '開啟Paransori時會先顯示這個畫面。';

  @override
  String get homeStartConfirm => '設定';

  @override
  String deleteSongsTitle(int count) {
    return '要刪除$count首歌曲嗎？';
  }

  @override
  String get deleteSongsMessage => '所選歌曲將從手機中刪除';

  @override
  String deletedSongsToast(int count) {
    return '已刪除$count首歌曲';
  }

  @override
  String get couldNotDelete => '刪除失敗';

  @override
  String get menuShareTitle => '分享給朋友';

  @override
  String get menuShareSub => '把Paransori\n推薦給朋友吧。';

  @override
  String get shareAppMessage => '我在用Paransori聽音樂！🎧';

  @override
  String get menuRateTitle => '為應用程式評分';

  @override
  String get menuRateSub => '您的好評\n是我們的動力。';

  @override
  String get menuSettingsSub => '可以調整\n應用程式設定。';

  @override
  String get menuRadioTitle => '廣播電台';

  @override
  String get menuRadioSub => '馬上收聽\n各種廣播節目。';

  @override
  String get recentSearches => '最近搜尋';

  @override
  String get clearAll => '全部清除';

  @override
  String get catMusic => '音樂';

  @override
  String get catMusicSub => '我的音樂 · MP3播放器';

  @override
  String get catRadio => '廣播';

  @override
  String get catRadioSub => '全球廣播 · 收藏';

  @override
  String get catNature => '自然';

  @override
  String get catNatureSub => '雨 · 風 · 森林 · 海浪';

  @override
  String get catRest => '休息 · 專注';

  @override
  String get catRestSub => '白噪音 · 專注（準備中）';

  @override
  String get homeSoundsHeader => '來聽聽這些聲音吧';

  @override
  String get homeRestHeader => '休息一下吧';

  @override
  String get homeRecentHeader => '最近收聽';

  @override
  String get homeRecentEmpty => '還沒有收聽記錄';

  @override
  String get homeRecentEmptySub => '收聽超過30秒的內容會顯示在這裡';

  @override
  String get cleanLabel => '整理歌曲';

  @override
  String cleanTitle(int count) {
    return '整理$count個歌曲標題';
  }

  @override
  String get later => '稍後';

  @override
  String get cleanAction => '整理';

  @override
  String get dailyOftenMorning => '早上常聽的歌';

  @override
  String get dailyOftenDay => '白天常聽的歌';

  @override
  String get dailyOftenEvening => '傍晚常聽的歌';

  @override
  String get dailyOftenNight => '夜裡常聽的歌';

  @override
  String get dailyLongTime => '好久沒聽的歌';

  @override
  String get dailySongOfDay => '今日歌曲';

  @override
  String get dailyHowAboutThis => '今天聽這首怎麼樣';

  @override
  String get listen => '播放';

  @override
  String get dailyListenAgain => '再聽一次';

  @override
  String dailyNotPlayedTitle(int count) {
    return '一個月沒聽的歌 $count首';
  }

  @override
  String get dailyNotPlayedSub => '要不要再聽聽？';

  @override
  String get dailyShufflePlay => '播放';

  @override
  String get dailyMyStats => '我的記錄';

  @override
  String dailyWeekCount(int count) {
    return '最近7天聽了$count次';
  }

  @override
  String get dailyMostPlayed => '最常聽';

  @override
  String get dailyMorningTitle => '清爽的早晨';

  @override
  String get dailyMorningLine => '用鳥鳴開啟新的一天';

  @override
  String get dailyDayTitle => '休息一下吧';

  @override
  String get dailyDayLine => '聽著溪水聲喘口氣';

  @override
  String get dailyEveningTitle => '今天也辛苦了';

  @override
  String get dailyEveningLine => '聽著海浪聲放鬆';

  @override
  String get dailyNightTitle => '深夜靜靜地聽';

  @override
  String get dailyNightLine => '聽著雨聲放鬆';

  @override
  String get dailyRightNow => '此刻';

  @override
  String get dailyTipBatteryTitle => '關閉螢幕也能繼續播放';

  @override
  String get dailyTipBatterySub => '將電池設為「不受限制」';

  @override
  String get dailyTipRingtoneTitle => '把歌曲設為鈴聲';

  @override
  String get dailyTipRingtoneSub => '在歌曲⋮選單中設定';

  @override
  String get dailyTipVideoTitle => '只儲存影片裡的音樂';

  @override
  String get dailyTipVideoSub => '影片⋮選單 →「儲存為音樂」';

  @override
  String get dailyTipMixTitle => '為音樂加上雨聲';

  @override
  String get dailyTipMixSub => '播放畫面⋮選單 → 自然聲音混音';

  @override
  String get dailyTipLyricsTitle => '分享一句歌詞';

  @override
  String get dailyTipLyricsSub => '長按歌詞即可生成卡片分享';

  @override
  String get dailyOffTitle => '要關閉今日卡片嗎？';

  @override
  String get dailyOffMessage => '可隨時在設定中重新開啟';

  @override
  String get turnOff => '關閉';

  @override
  String get dailyOffKeep => '繼續顯示';

  @override
  String get callRecordingsChip => '通話錄音 ›';

  @override
  String get sortedByArtist => '已按歌手排序';

  @override
  String get sortedByTitle => '已按標題排序';

  @override
  String get sortArtist => '歌手';

  @override
  String get sortTitle => '標題';

  @override
  String get today => '今天';

  @override
  String get yesterday => '昨天';

  @override
  String get within3Days => '3天內';

  @override
  String get withinWeek => '一週內';

  @override
  String get colorParansori => 'Paransori';

  @override
  String get colorForest => '森林';

  @override
  String get colorSunset => '晚霞';

  @override
  String get colorLavender => '薰衣草';

  @override
  String get colorInk => '墨色';

  @override
  String get colorBlossom => '櫻花';

  @override
  String get colorOcean => '海洋';

  @override
  String get colorSunlight => '陽光';

  @override
  String get colorWine => '酒紅';

  @override
  String get colorNightSky => '夜空';
}
