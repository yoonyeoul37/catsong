import 'package:flutter/widgets.dart';
import 'app_localizations.dart';

/// 어디서든 번역 문구 꺼내기: tr.키이름 (앱 언어에 맞게)
AppLocalizations get tr => AppLocale.current ?? lookupAppLocalizations(const Locale('en'));

class AppLocale {
  static AppLocalizations? current;
}