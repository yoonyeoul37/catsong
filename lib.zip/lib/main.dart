import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:google_fonts/google_fonts.dart';
import 'utils/greeting_images.dart';
import 'utils/paran_photo.dart';
import 'package:audio_service/audio_service.dart';
import 'package:media_kit/media_kit.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'providers/music_provider.dart';
import 'providers/player_provider.dart';
import 'providers/playlist_provider.dart';
import 'providers/lyrics_provider.dart';
import 'providers/video_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/radio_provider.dart';
import 'providers/start_screen_provider.dart';
import 'providers/sound_mix_provider.dart';
import 'providers/recent_content_provider.dart';
import 'screens/home_screen.dart';
import 'services/alarm_service.dart';
import 'services/headset_resume.dart';
import 'widgets/photo_dialog.dart';
import 'theme/app_theme.dart';
import 'l10n/app_localizations.dart';
import 'l10n/locale_holder.dart';
import 'package:in_app_update/in_app_update.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:ui' show PlatformDispatcher;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart' show kDebugMode;

late AudioHandler globalAudioHandler;
late BaseAudioHandler radioAudioHandler;

void main() async {
  final binding = WidgetsFlutterBinding.ensureInitialized();
  // 사진 기억 창고: 기본 100MB → 50MB (램이 적은 폰에서 꺼지는 것 줄이기)
  PaintingBinding.instance.imageCache.maximumSizeBytes = 50 << 20;
  // 시작 화면을 최소 1.2초는 보여주기 (너무 빨리 지나가지 않게)
  FlutterNativeSplash.preserve(widgetsBinding: binding);
  Future.delayed(const Duration(milliseconds: 600), FlutterNativeSplash.remove);
  MediaKit.ensureInitialized();

  // 오류 기록 (Firebase Crashlytics): 앱이 튕기거나 빨간 오류 화면이 뜨면 자동으로 기록
  try {
    await Firebase.initializeApp();
    // 디버깅(flutter run) 중 오류는 안 보내고, 스토어에서 받은 앱 오류만 기록
    await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(!kDebugMode);
    // 화면 경고는 "튕김"이 아니라 "일반 오류"로 기록 (진짜 튕김만 비정상 종료로 집계)
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  } catch (e) {
    debugPrint('Firebase 시작 오류: $e');
  }


  final playerProvider = PlayerProvider();
  final musicProvider = MusicProvider();
  final recentContentProvider = RecentContentProvider();
  final soundMixProvider = SoundMixProvider();
  playerProvider.onSongPlayed = (song) {
    musicProvider.addToRecent(song);
    recentContentProvider.addMusic(song);
  };
  playerProvider.onNaturePlayed = (assetPath, displayName) {
    recentContentProvider.addNature(assetPath, displayName);
  };

  final simpleHandler = SimpleAudioHandler(playerProvider);
  globalAudioHandler = await AudioService.init(
    builder: () => simpleHandler,
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'kr.ssing.catsong.audio',
      androidNotificationChannelName: '파란소리',
      androidNotificationOngoing: false,
      androidStopForegroundOnPause: false,
      androidNotificationIcon: 'mipmap/ic_launcher',
      notificationColor: null,
      androidNotificationClickStartsActivity: true,
      
      preloadArtwork: false,
    ),
  );
  playerProvider.setAudioHandler(globalAudioHandler);
  soundMixProvider.attachPlayerProvider(playerProvider);
  radioAudioHandler = simpleHandler;

  // RadioProvider 생성 + 음악/라디오 상호 정지 연결
  final radioProvider = RadioProvider()
    ..onStationPlayed = ((station) => recentContentProvider.addRadio(station))
    ..setAudioHandler(radioAudioHandler);

  radioProvider.setOnStopMusic(() async {
    await playerProvider.player.stop();
    playerProvider.clearNatureSoundState();
    playerProvider.clearCurrentSong();
    await WakelockPlus.disable();
  });

  playerProvider.setOnStopRadio(() async {
    await radioProvider.stopRadioAndClear();
  });
  playerProvider.setOnStopMixMusic(() {
    soundMixProvider.stopAll();
  });

  simpleHandler.onRadioPlay = () {
    radioProvider.togglePlayPause();
  };
  simpleHandler.onRadioPause = () {
    radioProvider.togglePlayPause();
  };

  simpleHandler.onRadioNext = () {
    final radio = radioProvider;
    final queue = radio.currentQueue;
    final idx = radio.currentQueueIndex;
    if (queue.isNotEmpty && idx < queue.length - 1) {
      radio.setQueue(queue, idx + 1);
      radio.playStation(queue[idx + 1]);
    } else if (queue.isNotEmpty) {
      radio.setQueue(queue, 0);
      radio.playStation(queue[0]);
    }
  };
  simpleHandler.onRadioPrevious = () {
    final radio = radioProvider;
    final queue = radio.currentQueue;
    final idx = radio.currentQueueIndex;
    if (queue.isNotEmpty && idx > 0) {
      radio.setQueue(queue, idx - 1);
      radio.playStation(queue[idx - 1]);
    } else if (queue.isNotEmpty) {
      radio.setQueue(queue, queue.length - 1);
      radio.playStation(queue[queue.length - 1]);
    }
  };

  HeadsetResume.init(playerProvider, radioProvider); // 이어폰 연결하면 이어서 듣기

  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppTheme.surface,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarContrastEnforced: false,
    ),
  );

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final videoProvider = VideoProvider()
    ..setOnStopRadio(() async => await radioProvider.stopRadio())
    ..setOnStopMusic(() async => await playerProvider.player.stop());

  await AlarmService.init(); // 아침 알람 (알람 때문에 켜졌는지도 확인)

  runApp(MyApp(
    playerProvider: playerProvider,
    musicProvider: musicProvider,
    radioProvider: radioProvider,
    videoProvider: videoProvider,
    recentContentProvider: recentContentProvider,
    soundMixProvider: soundMixProvider,
  ));
}

class MyApp extends StatelessWidget {
  final PlayerProvider playerProvider;
  final MusicProvider musicProvider;
  final RadioProvider radioProvider;
  final VideoProvider videoProvider;
  final RecentContentProvider recentContentProvider;
  final SoundMixProvider soundMixProvider;
  const MyApp({
    super.key,
    required this.playerProvider,
    required this.musicProvider,
    required this.radioProvider,
    required this.videoProvider,
    required this.recentContentProvider,
    required this.soundMixProvider,
  });

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: musicProvider),
        ChangeNotifierProvider.value(value: playerProvider),
        ChangeNotifierProvider(create: (_) => PlaylistProvider()),
        ChangeNotifierProvider(create: (_) => LyricsProvider()),
        ChangeNotifierProvider.value(value: videoProvider),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider.value(value: radioProvider),
        ChangeNotifierProvider(create: (_) => StartScreenProvider()),
        ChangeNotifierProvider.value(value: recentContentProvider),
        ChangeNotifierProvider.value(value: soundMixProvider),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            navigatorKey: AlarmService.navKey, // 알람 화면 띄우기용
            title: '파란소리',
            debugShowCheckedModeBanner: false,
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [
              Locale('ko'),
              Locale('en'),
              Locale('ja'),
              Locale('zh'),
            ],
            theme: AppTheme.buildTheme(themeProvider.primaryColor).copyWith(
              textTheme: themeProvider.fontFamily == 'default'
                  ? AppTheme.buildTheme(themeProvider.primaryColor)
                      .textTheme
                      .apply(fontFamily: 'SpoqaHanSansNeo')
                  : AppTheme.buildTheme(themeProvider.primaryColor)
                      .textTheme
                      .apply(fontFamily: themeProvider.getTextTheme().bodyLarge?.fontFamily),
              // 제목 줄이 화면을 다시 그릴 때마다 시스템 바 색을 덮어쓰므로, 라이트/다크에 맞는 값을 쥐여준다
              appBarTheme: AppTheme.buildTheme(themeProvider.primaryColor)
                  .appBarTheme
                  .copyWith(systemOverlayStyle: themeProvider.systemBarStyle),
              // ⋮ 메뉴 공통 모양: 둥근 카드 + 부드러운 그림자 (다크면 어두운 카드)
              popupMenuTheme: PopupMenuThemeData(
                color: themeProvider.isDarkMode ? const Color(0xFF32302C) : Colors.white,
                surfaceTintColor: Colors.transparent,
                elevation: 10,
                shadowColor: Colors.black.withOpacity(themeProvider.isDarkMode ? 0.5 : 0.18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                textStyle: TextStyle(
                  color: themeProvider.isDarkMode ? const Color(0xFFF3EFE7) : const Color(0xFF17140F),
                  fontSize: 14,
                ),
                // 새 방식 메뉴도 글자색이 배경과 겹치지 않게
                labelTextStyle: WidgetStatePropertyAll(TextStyle(
                  color: themeProvider.isDarkMode ? const Color(0xFFF3EFE7) : const Color(0xFF17140F),
                  fontSize: 14,
                )),
              ),
            ),
            builder: (context, child) {
              AppLocale.current = AppLocalizations.of(context);
              debugPrint('=== 화면 크기: ${MediaQuery.of(context).size} ===');
              // 폭이 좁은 폰(엑스커버 등)은 글자를 폭에 맞춰 살짝 줄이기 → A24와 같은 비율 (최대 15%)
              final fit = (MediaQuery.of(context).size.width / 400).clamp(0.85, 1.0);
              return MediaQuery(
                data: MediaQuery.of(context).copyWith(
                  textScaler: TextScaler.linear(themeProvider.textScale * fit),
                  boldText: false,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: AppTheme.dynamicBackgroundGradient(
                        themeProvider.primaryColor),
                  ),
                  child: child!,
                ),
              );
            },
            home: const AppInitializer(),
          );
        },
      ),
    );
  }
}

class AppInitializer extends StatefulWidget {
  const AppInitializer({super.key});

  @override
  State<AppInitializer> createState() => _AppInitializerState();
}

class _AppInitializerState extends State<AppInitializer> with WidgetsBindingObserver {
  bool _showWelcome = false;
  bool _showIntro = !AlarmService.launchedByAlarm; // 알람으로 켜졌으면 인트로 없이 바로
  bool _introCleared = false; // 첫인사 사진을 램에서 비웠는지

  AudioPlayer? _welcomePlayer; // 첫인사 전용 작은 재생기
  VoidCallback? _welcomeCleanup;

  Future<void> _checkAndShowWelcome() async {
    if (AlarmService.launchedByAlarm) return; // 알람 때는 첫인사 안 함
    // 알람으로 열린 화면인지 폰에 한 번 더 확인 → 알람이면 인삿말 없이 바로 알람 화면
    if (await AlarmService.isAlarmIntent()) {
      AlarmService.showRing();
      return;
    }
    if (!mounted || AlarmService.launchedByAlarm) return;
    if (!context.read<ThemeProvider>().voiceGreetingEnabled) return;
    final langCode = Localizations.localeOf(context).languageCode;
    final welcomeAsset = langCode == 'ko' ? 'assets/welcome_ko_v4.mp3' : null;
    if (welcomeAsset == null) return;

    // 소리 주도권(오디오 포커스)은 안 가져감 → 라디오·음악과 부딪히지 않게
    final p = AudioPlayer(handleInterruptions: false, handleAudioSessionActivation: false);
    _welcomePlayer = p;

    // 인삿말 도중에 라디오나 음악을 틀면 → 인삿말 바로 멈추고 정리
    final radio = context.read<RadioProvider>();
    final music = context.read<PlayerProvider>();
    void stopIfOther() {
      if (radio.isPlaying || radio.isLoading || music.isPlaying) _stopWelcome();
    }
    radio.addListener(stopIfOther);
    music.addListener(stopIfOther);
    _welcomeCleanup = () {
      radio.removeListener(stopIfOther);
      music.removeListener(stopIfOther);
    };

    // 인삿말이 끝나면 바로 정리
    p.processingStateStream.listen((s) {
      if (s == ProcessingState.completed) _stopWelcome();
    });
    try {
      await p.setAsset(welcomeAsset);
      if (_welcomePlayer == p && !AlarmService.launchedByAlarm) p.play(); // 준비하는 사이에 멈췄으면 재생 안 함
    } catch (_) {
      _stopWelcome();
    }
  }

  /// 첫인사 멈추고 재생기 정리
  void _stopWelcome() {
    final p = _welcomePlayer;
    if (p == null) return;
    _welcomePlayer = null;
    _welcomeCleanup?.call();
    _welcomeCleanup = null;
    p.stop().whenComplete(() => p.dispose());
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AlarmService.onRingStart = _stopWelcome; // 알람이 울리면 첫인삿말 바로 멈춤
    if (AlarmService.launchedByAlarm) {
      WidgetsBinding.instance.addPostFrameCallback((_) => AlarmService.showRing());
    }
    // (첫인사 시간은 사진이 화면에 뜬 뒤부터 _IntroView가 잼)
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _checkAndShowWelcome();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final path in [
        'assets/music_bg.jpg',
        'assets/radio_bg.jpg',
        'assets/nature_bg.jpg',
        'assets/sleep_bg.jpg',
      ]) {
        precacheImage(AssetImage(path), context);
      }
      precacheImage(CachedNetworkImageProvider(farewellImageUrl(context)), context,
          onError: (_, __) {}); // 미리 받기 실패해도 조용히
      // 잠시 쉬어가요 라디오 사진(썸네일 10장)을 미리 받아두기
      for (var i = 1; i <= 10; i++) {
        precacheImage(
          CachedNetworkImageProvider(
              'https://srdzgrinceazcimdwayu.supabase.co/storage/v1/object/public/app-images/rest_radio_${i}_thumb.jpg'),
          context,
          onError: (_, __) {}, // 미리 받기 실패해도 조용히
        );
      }
      SharedPreferences.getInstance().then((prefs) {
        final bg = prefs.getString('nightBgPath');
        if (bg != null && mounted) precacheParanPhoto(bg, context);
      });
    });
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final musicProvider = context.read<MusicProvider>();
      if (musicProvider.songs.isEmpty) {
        await musicProvider.initialize();
        context
            .read<PlaylistProvider>()
            .restorePlaylistSongs(musicProvider.allSongs);
      }
      // (배터리 창은 처음에 안 띄움 → 이어폰 이어서 듣기·아침 알람 켤 때만 물어봄)
      if (!AlarmService.launchedByAlarm) {
        await _checkAndRequestReview();
        await _checkForUpdate();
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AlarmService.onRingStart = null;
    _stopWelcome();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkForUpdate();
    }
  }

  Future<void> _checkForUpdate() async {
    try {
      final info = await InAppUpdate.checkForUpdate();
      // 이미 다운로드가 끝나있는데 설치(재시작)만 안 된 경우 - 바로 안내
      if (info.installStatus == InstallStatus.downloaded) {
        _showUpdateReadySnackbar();
        return;
      }
      if (info.updateAvailability == UpdateAvailability.updateAvailable &&
          info.flexibleUpdateAllowed) {
        InAppUpdate.installUpdateListener.listen((status) {
          if (status == InstallStatus.downloaded && mounted) {
            _showUpdateReadySnackbar();
          }
        });
        await InAppUpdate.startFlexibleUpdate();
      }
    } catch (e) {
      debugPrint('업데이트 확인 오류: $e');
    }
  }

  /// 업데이트 완료 창 (아침 사진 + 워터마크)
  Future<void> _showUpdateReadySnackbar() async {
    if (!mounted) return;
    final l = AppLocalizations.of(context)!;
    final restart = await showPhotoDialog(
      context,
      image: 'assets/update_banner.jpg',
      title: l.updateReadyTitle,
      message: l.updateReadyMessage,
      primary: l.updateReadyButton,
      secondary: l.updateReadyLater,
      primaryIcon: Icons.refresh_rounded,
      barrierDismissible: false,
    );
    if (restart) InAppUpdate.completeFlexibleUpdate();
  }

  // (예전 업데이트 창 — 코드 정리할 때 지우기)
  void _oldUpdateReadySnackbar() {
    if (!mounted) return;
    const accent = AppTheme.fixedAccent;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(28, 32, 28, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.system_update, color: accent, size: 34),
              ),
              const SizedBox(height: 20),
              Text(
                AppLocalizations.of(ctx)!.updateReadyTitle,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                AppLocalizations.of(ctx)!.updateReadyMessage,
                style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 15,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    InAppUpdate.completeFlexibleUpdate();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text(
                    AppLocalizations.of(ctx)!.updateReadyButton,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black38,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: Text(AppLocalizations.of(ctx)!.updateReadyLater, style: const TextStyle(fontSize: 14)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _checkAndRequestReview() async {
    final prefs = await SharedPreferences.getInstance();
    final launchCount = (prefs.getInt('launch_count') ?? 0) + 1;
    await prefs.setInt('launch_count', launchCount);

    final lastRequest = prefs.getInt('last_review_request') ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    final oneDayMs = 24 * 60 * 60 * 1000;

    if (launchCount % 5 == 0 && (now - lastRequest) > oneDayMs) {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) {
        await _showReviewDialog();
      }
    }
  }

  /// 리뷰 부탁 창 (오후 사진 + 별 5개 + 워터마크)
  Future<void> _showReviewDialog() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final l = AppLocalizations.of(context)!;
    final go = await showPhotoDialog(
      context,
      image: 'assets/review_banner.jpg',
      title: l.reviewTitle,
      message: l.reviewMessage,
      primary: l.reviewButton,
      secondary: l.reviewLater,
      stars: true,
      barrierDismissible: false,
    );
    await prefs.setInt('last_review_request', DateTime.now().millisecondsSinceEpoch);
    if (go) {
      try {
        await launchUrl(Uri.parse('https://play.google.com/store/apps/details?id=kr.ssing.catsong'),
            mode: LaunchMode.externalApplication);
      } catch (_) {}
    }
  }

  // (예전 리뷰 창 — 코드 정리할 때 지우기)
  Future<void> _oldReviewDialog() async {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final prefs = await SharedPreferences.getInstance();
    final l = AppLocalizations.of(context)!;

    const accent = AppTheme.fixedAccent;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: const Color(0xFF2F7DE8),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.music_note_rounded,
                    color: Colors.white, size: 32),
              ),
              const SizedBox(height: 18),
              Text(
                l.reviewTitle,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.visible,
                softWrap: false,
              ),
              const SizedBox(height: 8),
              Text(
                l.reviewMessage,
                style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 13,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  5,
                  (i) => const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 2),
                    child: Icon(Icons.star_rounded,
                        color: Color(0xFFF5B83D), size: 28),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () async {
                    Navigator.pop(ctx);
                    await prefs.setInt('last_review_request',
                        DateTime.now().millisecondsSinceEpoch);
                    final uri = Uri.parse(
                        'https://play.google.com/store/apps/details?id=kr.ssing.catsong');
                    try {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                    } catch (e) {}
                  },
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xFF2F7DE8),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const StadiumBorder(),
                  ),
                  child: Text(l.reviewButton,
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 14)),
                ),
              ),
              const SizedBox(height: 4),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    prefs.setInt('last_review_request',
                        DateTime.now().millisecondsSinceEpoch);
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black38,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: Text(l.reviewLater,
                      style: const TextStyle(fontSize: 13)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_showIntro) {
      return GestureDetector(
        onTap: () => setState(() => _showIntro = false),
        child: Scaffold(
          backgroundColor: Colors.black,
          body: _IntroView(
            path: introAssetPath(context),
            onDone: () {
              if (mounted) setState(() => _showIntro = false);
            },
            // 새 사진(글자 없음)은 한국어만 → 'Paransori'를 코드로 얹기
            showTitle: Localizations.localeOf(context).languageCode == 'ko',
          ),
        ),
      );
    }
    // 첫인사가 끝나면 사진은 다시 안 쓰니까 램에서만 비우기 (화면이 바뀐 뒤에)
    if (!_introCleared) {
      _introCleared = true;
      final introPath = introAssetPath(context);
      WidgetsBinding.instance.addPostFrameCallback((_) => AssetImage(introPath).evict());
    }
    return const HomeScreen();
  }
}

/// 첫인사 화면: 사진이 아주 천천히 다가오고, 'Paransori'가 아래에서 떠오르며 나타남
class _IntroView extends StatefulWidget {
  final String path;
  final bool showTitle;
  final VoidCallback onDone;
  const _IntroView({required this.path, required this.showTitle, required this.onDone});

  @override
  State<_IntroView> createState() => _IntroViewState();
}

class _IntroViewState extends State<_IntroView> with SingleTickerProviderStateMixin {
  // 첫인사가 3초라서 3초 동안 움직임
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 4500));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    // 사진을 다 불러온 다음에 시작 (불러오는 동안 시간이 흘러가지 않게)
    precacheImage(AssetImage(widget.path), context).whenComplete(() {
      if (!mounted) return;
      _c.forward().whenComplete(() {
        if (mounted) widget.onDone();
      });
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 사진: 3초 동안 6%만 살짝 다가오기
    final zoom = Tween(begin: 1.0, end: 1.06)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOut));
    // 글자: 0.4초 뒤부터 1.4초 동안 떠오르기 (글자 사이도 천천히 모임)
    final t = CurvedAnimation(parent: _c, curve: const Interval(0.13, 0.6, curve: Curves.easeOutCubic));
    final h = MediaQuery.sizeOf(context).height;
    return Stack(
      fit: StackFit.expand,
      children: [
        AnimatedBuilder(
          animation: zoom,
          builder: (_, child) => Transform.scale(scale: zoom.value, child: child),
          child: Image.asset(widget.path, fit: BoxFit.cover), // 화면 꽉 채우기
        ),
        if (widget.showTitle)
          Positioned(
            left: 0,
            right: 0,
            top: h * 0.22, // 파란 하늘 자리
            child: AnimatedBuilder(
              animation: t,
              builder: (_, __) => Opacity(
                opacity: t.value,
                child: Transform.translate(
                  offset: Offset(0, 14 * (1 - t.value)),
                  child: Text(
                    'Paransori',
                    textAlign: TextAlign.center,
                    textScaler: TextScaler.noScaling, // 글자 크기 설정과 상관없이 고정
                    style: GoogleFonts.quicksand( // 홈 로고와 같은 글꼴
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 4 + 6 * (1 - t.value),
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.18),
                          blurRadius: 12,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _WavePainter extends CustomPainter {
  final Color color;
  _WavePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
  final paint = Paint()
  ..color = color.withOpacity(0.20)
  ..style = PaintingStyle.fill;

  final path = Path();
  path.moveTo(0, size.height * 0.6);
  for (double x = 0; x <= size.width; x++) {
  final y = size.height * 0.6 +
  20 * sin((x / size.width) * 3.14159 * 3) +
  10 * sin((x / size.width) * 3.14159 * 6);
  path.lineTo(x, y);
  }
  path.lineTo(size.width, size.height);
  path.lineTo(0, size.height);
  path.close();
  canvas.drawPath(path, paint);

  final paint2 = Paint()
  ..color = color.withOpacity(0.12)
  ..style = PaintingStyle.fill;

  final path2 = Path();
  path2.moveTo(0, size.height * 0.4);
  for (double x = 0; x <= size.width; x++) {
  final y = size.height * 0.4 +
  15 * sin((x / size.width) * 3.14159 * 4 + 1) +
  8 * sin((x / size.width) * 3.14159 * 7 + 2);
  path2.lineTo(x, y);
  }
  path2.lineTo(size.width, size.height);
  path2.lineTo(0, size.height);
  path2.close();
  canvas.drawPath(path2, paint2);
  }

  @override
  bool shouldRepaint(_WavePainter old) => old.color != color;
  }
