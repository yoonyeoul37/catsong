import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/material.dart' show TimeOfDay, DayPeriod;
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:audio_service/audio_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/radio_station.dart';
import '../models/radio_country.dart';
import 'player_provider.dart' show SimpleAudioHandler;
import '../services/schedule_service.dart';

enum RadioPlayerState { idle, loading, playing, paused, error }

class RadioProvider extends ChangeNotifier {
  late final Player _player;
  AudioHandler? _audioHandler;
  bool _isActuallyPlaying = false;
  VoidCallback? _onStopMusic;

  RadioPlayerState _playerState = RadioPlayerState.idle;
  RadioStation? _currentStation;
  List<RadioStation> _currentQueue = [];
  int _currentQueueIndex = -1;
  List<RadioStation> get currentQueue => _currentQueue;
  int get currentQueueIndex => _currentQueueIndex;
  String? _errorMessage;

  RadioCountry? _selectedCountry;
  RadioBroadcaster? _selectedBroadcaster;

  List<RadioStation> _broadcasterStations = [];
  List<RadioStation> _searchResults = [];
  List<RadioStation> _favorites = [];
  List<RadioStation> _recentlyListened = [];

  List<ScheduledStation> _schedules = [];
  Timer? _scheduleCheckTimer;
  List<ScheduledStation> get schedules => _schedules;
  static const _maxSchedules = 5;
  Timer? _sleepTimer;
  Duration? _sleepRemaining;
  Timer? _sleepCountdown;

  static const _keyFavorites = 'radio_favorites';
  static const _keyRecent = 'radio_recent';
  static const _keySchedules = 'radio_schedules';
  static const _maxRecent = 50;

  static const _apiServers = [
    'de1.api.radio-browser.info',
    'de2.api.radio-browser.info',
    'nl1.api.radio-browser.info',
  ];

  List<String>? _resolvedServers;

  Future<List<String>> _getApiServers() async {
    if (_resolvedServers != null && _resolvedServers!.isNotEmpty) {
      return _resolvedServers!;
    }
    try {
      final response = await http
          .get(Uri.https('all.api.radio-browser.info', '/json/servers'), headers: _apiHeaders)
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        final servers = data
            .map((e) => e['name'] as String?)
            .where((s) => s != null && s.isNotEmpty)
            .cast<String>()
            .toList();
        if (servers.isNotEmpty) {
          _resolvedServers = servers;
          debugPrint('동적 서버 목록 획득: $servers');
          return servers;
        }
      }
    } catch (e) {
      debugPrint('서버 목록 조회 실패, 기본 목록 사용: $e');
    }
    return _apiServers;
  }
  static const _apiHeaders = {
    'User-Agent': 'CatSong/1.0 (kr.ssing.catsong)'
  };

  RadioPlayerState get playerState => _playerState;
  RadioStation? get currentStation => _currentStation;
  String? get errorMessage => _errorMessage;

  // TV로 보내기(캐스팅)용: 마지막으로 실제 재생한 방송 주소
  String? _lastPlayUrl;
  String? _lastPlayStationId;
  String? get lastPlayUrl => _lastPlayUrl;
  String? get lastPlayStationId => _lastPlayStationId;

  /// 방송국이 요구하는 헤더 (TV로 보낼 때 폰이 대신 붙여줌)
  Map<String, String> castHeadersFor(RadioStation s) => {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        'Referer': _getReferer(s),
        'Origin': _getOrigin(s),
      };
  RadioCountry? get selectedCountry => _selectedCountry;
  RadioBroadcaster? get selectedBroadcaster => _selectedBroadcaster;
  List<RadioStation> get broadcasterStations => _broadcasterStations;
  List<RadioStation> get searchResults => _searchResults;
  List<RadioStation> get favorites => _favorites;
  List<RadioStation> get recentlyListened => _recentlyListened;
  bool get isLoadingBroadcaster => false;
  bool get isLoadingCountry => false;
  bool get isSearching => false;
  bool get isPlaying => _playerState == RadioPlayerState.playing;
  bool get isLoading => _playerState == RadioPlayerState.loading;
  Duration? get sleepRemaining => _sleepRemaining;
  bool get isSleepTimerActive => _sleepTimer != null;

  final ScheduleService _scheduleService = ScheduleService();

  StreamSubscription? _connectivitySubscription;

  RadioProvider() {
    _listenConnectivity();
    _player = Player(
      configuration: PlayerConfiguration(
        logLevel: MPVLogLevel.debug,
      ),
    );
    _configurePlayer();
    _listenAudioFocus();
    _listenNativeAudioFocus();
    _initPlayerStreams();
    _initAudioSession();
    _loadFromPrefs();
    _startScheduleRefreshTimer();
    _scheduleService.loadSchedule().then((_) {
      fetchJsonSchedule('CBS 음악FM');
      fetchJsonSchedule('CBS 표준FM');
      notifyListeners();
    });
  }

  Future<void> _initAudioSession() async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());
      session.interruptionEventStream.listen((event) {
        if (event.begin) {
          debugPrint('오디오 인터럽트 발생 - 라디오 정지');
          if (_playerState == RadioPlayerState.playing) {
          _player.pause();
          _setPlayerState(RadioPlayerState.paused);
          _updateForeground(false);
          }
        } else {
          debugPrint('오디오 인터럽트 종료 - 라디오 재개');
          if (_currentStation != null && _playerState == RadioPlayerState.paused) {
            playStation(_currentStation!);
          }
        }
      });
      session.becomingNoisyEventStream.listen((_) {
        debugPrint('이어폰 제거 - 라디오 정지');
        stopRadio();
      });
    } catch (e) {
      debugPrint('AudioSession 초기화 오류: $e');
    }
  }

  bool _pausedByFocusLoss = false;

  void _listenNativeAudioFocus() {
    const platform = MethodChannel('kr.ssing.catsong/media');
    platform.setMethodCallHandler((call) async {
      if (call.method == 'onAudioFocusLost') {
        // 이미 완전히 꺼진(idle) 상태거나, 사용자가 이미 직접 정지해둔 상태라면 건드리지 않음
        if (_playerState == RadioPlayerState.idle) return;
        if (_playerState == RadioPlayerState.paused) return;
        debugPrint('오디오 포커스 손실 - 라디오 일시정지');
        await _player.pause();
        _isActuallyPlaying = false;
        _pausedByFocusLoss = true;
        _setPlayerState(RadioPlayerState.paused);
        _updateForeground(false);
      } else if (call.method == 'onAudioFocusGain') {
        debugPrint('오디오 포커스 복구 - 라디오 재개');
        if (_currentStation != null &&
            _playerState == RadioPlayerState.paused &&
            _pausedByFocusLoss) {
          _pausedByFocusLoss = false;
          await playStation(_currentStation!);
        }
      }
    });
  }

  Future<void> _listenAudioFocus() async {
    try {
      final nativePlayer = _player.platform as NativePlayer;
      await nativePlayer.setProperty('audio-stream-exclusive', 'no');
      await nativePlayer.setProperty('audio-exclusive', 'no');
      await nativePlayer.setProperty('android-audio-focus', 'no');
    } catch (e) {
      debugPrint('오디오 포커스 설정 오류: $e');
    }
  }

  Future<void> _configurePlayer() async {
    try {
      final nativePlayer = _player.platform as NativePlayer;
      await nativePlayer.setProperty('user-agent', 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36');
      await nativePlayer.setProperty('demuxer-lavf-probesize', '4096');
      await nativePlayer.setProperty('stream-lavf-o', 'reconnect=1');
      await nativePlayer.setProperty('network-timeout', '30');
      await nativePlayer.setProperty('demuxer-max-bytes', '5242880');
      await nativePlayer.setProperty('cache', 'yes');
      await nativePlayer.setProperty('cache-secs', '10');
      debugPrint('mpv HLS 설정 완료');
    } catch (e) {
      debugPrint('mpv 설정 오류: $e');
    }
  }

  void setAudioHandler(AudioHandler handler) {
    _audioHandler = handler;
  }

  void setOnStopMusic(VoidCallback cb) {
    _onStopMusic = cb;
  }

  SimpleAudioHandler? get _simpleHandler {
    final h = _audioHandler;
    if (h is SimpleAudioHandler) return h;
    return null;
  }

  void _startForeground(RadioStation station, String url) {
    try {
      _simpleHandler?.setRadioMediaItem(
        title: station.name,
        artist: station.country ?? 'Radio',
        url: url,
      );
      _simpleHandler?.setRadioPlaybackState(playing: true);
      debugPrint('포그라운드 서비스 시작');
    } catch (e) {
      debugPrint('포그라운드 서비스 오류: $e');
    }
  }

  void _updateForeground(bool playing) {
    try {
      if (_playerState != RadioPlayerState.idle) {
        _simpleHandler?.setRadioPlaybackState(playing: playing);
      }
    } catch (e) {
      debugPrint('포그라운드 업데이트 오류: $e');
    }
  }

  void _stopForeground() {
    try {
      _simpleHandler?.setRadioPlaybackState(playing: false);
      _simpleHandler?.setRadioMode(false);
    } catch (e) {
      debugPrint('포그라운드 종료 오류: $e');
    }
  }

  void _initPlayerStreams() {
    _player.stream.playing.listen((playing) {
      debugPrint('stream.playing: $playing');
      _isActuallyPlaying = playing;
      if (playing) {
        _setPlayerState(RadioPlayerState.playing);
        _updateForeground(true);
      } else {
        if (_playerState == RadioPlayerState.playing) {
          _setPlayerState(RadioPlayerState.paused);
          _updateForeground(false);
        }
      }
    });

    _player.stream.buffering.listen((buffering) {
      debugPrint('stream.buffering: $buffering');
      if (buffering && !_isActuallyPlaying) {
        _setPlayerState(RadioPlayerState.loading);
      }
    });

    _player.stream.completed.listen((completed) async {
      if (completed) {
        debugPrint('재생 완료 신호 감지 - 자동 재연결 시도');
        _isActuallyPlaying = false;
        final station = _currentStation;
        if (station != null) {
          await Future.delayed(const Duration(seconds: 2));
          if (_currentStation?.stationUuid == station.stationUuid && !_isActuallyPlaying) {
            await playStation(station);
          }
        } else {
          _setPlayerState(RadioPlayerState.idle);
          _stopForeground();
        }
      }
    });

    _player.stream.error.listen((error) {
      debugPrint('media_kit 오류: $error');
      // 실제로 소리가 계속 나오고 있으면(mpv 자체 재연결 성공) 무시 - 순간적인 네트워크 흔들림
      if (error.isNotEmpty && !_player.state.playing) {
        _errorMessage = '방송을 불러올 수 없습니다.\n다른 채널을 선택해 주세요.';
        _isActuallyPlaying = false;
        _setPlayerState(RadioPlayerState.error);
      }
    });
  }

  Future<String?> _resolveStreamUrl(String url) async {
    try {
      if (url.contains('cfpwwwapi.kbs.co.kr')) {
        try {
          final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
          if (response.statusCode == 200) {
            final data = json.decode(response.body);
            final items = data['channel_item'] as List?;
            if (items != null && items.isNotEmpty) {
              final serviceUrl = items[0]['service_url'] as String?;
              if (serviceUrl != null && serviceUrl.isNotEmpty) {
                debugPrint('KBS API URL 추출: $serviceUrl');
                return serviceUrl;
              }
            }
          }
        } catch (e) {
          debugPrint('KBS API 파싱 오류: $e');
        }
        return null;
      }

      // MBC 표준FM/FM4U/올댓뮤직: 개인 중계 서버(serpent0) 대신 iMBC 공식 토큰 API 직접 호출
      if (url.contains('mbcsfm.pls') || url.contains('mbcfm.pls') || url.contains('mbcatm.pls')) {
        final channel = url.contains('mbcsfm.pls')
            ? 'sfm'
            : url.contains('mbcatm.pls')
                ? 'chm'
                : 'mfm';
        try {
          final tokenUri = Uri.parse('https://sminiplay.imbc.com/aacplay.ashx?agent=webapp&channel=$channel');
          final response = await http.get(tokenUri).timeout(const Duration(seconds: 10));
          if (response.statusCode == 200) {
            final fresh = response.body.trim();
            if (fresh.startsWith('http')) {
              debugPrint('MBC 토큰 URL 추출: $fresh');
              return fresh;
            }
          }
        } catch (e) {
          debugPrint('MBC 토큰 발급 오류: $e');
        }
        return null;
      }

      final client = http.Client();
      final request = http.Request('GET', Uri.parse(url));
      request.headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36';
      request.followRedirects = false;

      final response = await client.send(request).timeout(const Duration(seconds: 10));
      final statusCode = response.statusCode;
      debugPrint('resolve statusCode: $statusCode');

      if (statusCode == 301 || statusCode == 302 || statusCode == 307 || statusCode == 308) {
        final location = response.headers['location'];
        if (location != null && location.isNotEmpty) {
          debugPrint('리다이렉트: $location');
          client.close();
          return location;
        }
      }

      final body = await response.stream.bytesToString();
      final lines = body.split('\n');

      for (final line in lines) {
        final trimmed = line.trim();
        if (trimmed.startsWith('File') && trimmed.contains('=')) {
          final fileUrl = trimmed.substring(trimmed.indexOf('=') + 1).trim();
          if (fileUrl.startsWith('http')) {
            debugPrint('PLS에서 URL 추출: $fileUrl');
            client.close();
            return await _resolveStreamUrl(fileUrl) ?? fileUrl;
          }
        }
        if (trimmed.isNotEmpty && !trimmed.startsWith('#') && trimmed.startsWith('http')) {
          debugPrint('M3U에서 URL 추출: $trimmed');
          client.close();
          return trimmed;
        }
      }

      client.close();
      return null;
    } catch (e) {
      debugPrint('URL resolve 오류: $e');
      return null;
    }
  }

  void Function(RadioStation station)? onStationPlayed;

  Future<void> playStation(RadioStation station) async {
    if (_playerState == RadioPlayerState.loading) {
      debugPrint('이미 로딩 중 - 중복 호출 무시');
      return;
    }
    onStationPlayed?.call(station);

    try {
      _errorMessage = null;
      _isActuallyPlaying = false;
      // 다른 방송국으로 바뀔 때만 편성표 초기화
      final prevStationName = _currentStation?.name;
      _setPlayerState(RadioPlayerState.loading);
      _currentStation = station;
      if (prevStationName != station.name) {
        _currentProgramMap.remove(station.name);
        _nowPlayingMap.remove(station.name);
      }
      final qIdx = _currentQueue.indexWhere((s) => s.name == station.name);
      if (qIdx >= 0) _currentQueueIndex = qIdx;
      notifyListeners();

      _onStopMusic?.call();
      await Future.delayed(const Duration(milliseconds: 200));
      try {
        const MethodChannel('kr.ssing.catsong/media').invokeMethod('requestAudioFocus');
      } catch (e) {}

      debugPrint('=== 라디오 재생 시작 ===');
      debugPrint('방송국: ${station.name}');
      debugPrint('station.url: ${station.streamUrl}');
      debugPrint('station.url_resolved: ${station.urlResolved}');

      String playUrl = station.playableUrl;
      final isKoreanDomestic = station.streamUrl.contains('cfpwwwapi.kbs.co.kr') ||
          station.streamUrl.contains('imbc.com') ||
          station.streamUrl.contains('mbcsfm.pls') ||
          station.streamUrl.contains('mbcfm.pls') ||
          station.streamUrl.contains('mbcatm.pls') ||
          station.streamUrl.contains('sbs.co.kr') ||
          station.streamUrl.contains('ebs.co.kr');

      try {
        final freshUrl = await _resolveStreamUrl(station.streamUrl);
        if (freshUrl != null && freshUrl.isNotEmpty) {
          playUrl = freshUrl;
          debugPrint('리다이렉트 URL 추출: $playUrl');
        }
      } catch (e) {
        debugPrint('리다이렉트 실패 → url_resolved 사용');
      }

      if (!isKoreanDomestic && playUrl == station.playableUrl) {
        try {
          for (final server in _apiServers) {
            final uri = Uri.https(server, '/json/url/${station.stationUuid}');
            final response = await http.get(uri, headers: _apiHeaders).timeout(const Duration(seconds: 10));
            if (response.statusCode == 200) {
              final data = json.decode(response.body);
              final freshUrl = data['url'] as String?;
              if (freshUrl != null && freshUrl.isNotEmpty) {
                playUrl = freshUrl;
                debugPrint('API 최신 URL: $playUrl');
                break;
              }
            }
          }
        } catch (e) {
          debugPrint('API URL 실패');
        }
      }

      debugPrint('FINAL_URL: $playUrl');
      _lastPlayUrl = playUrl;
      _lastPlayStationId = station.stationUuid;

      await WakelockPlus.disable();
      _startForeground(station, playUrl);

      await _player.open(
        Media(
          playUrl,
          httpHeaders: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
            'Referer': _getReferer(station),
            'Origin': _getOrigin(station),
          },
        ),
        play: true,
      );

      await recordListened(station);
      _updateWidget(station.name, station.country ?? '', true);

      // JSON 편성표 확인 (KBS/MBC/SBS 아닌 경우만)
      if (station.name == '국방FM') {
        fetchKfnSchedule();
      }
      // KBS 편성표
      if (station.broadcaster == null && station.streamUrl.contains('cfpwwwapi.kbs.co.kr')) {
        fetchScheduleByUrl(station.name, station.streamUrl);
      } else if (station.name.contains('KBS')) {
        fetchScheduleByUrl(station.name, station.streamUrl);
      }
      // MBC/SBS 편성표
      if (station.name == 'MBC 표준FM' || station.name == 'MBC FM4U') {
        fetchMbcSchedule(station.name);
      }
      if (station.name == 'SBS 파워FM' || station.name == 'SBS 러브FM') {
        fetchSbsSchedule(station.name);
      }
      if (station.name == 'EBS 반디') {
        fetchEbsBandiSchedule();
      }
      if (station.name == 'EBS FM') {
        fetchEbsFmSchedule();
      }
      final isKbsMbcSbs = station.name.contains('KBS') ||
          station.name.contains('MBC') ||
          station.name.contains('SBS');
      if (!isKbsMbcSbs && _scheduleService.hasSchedule(station.name)) {
        final program = _scheduleService.getCurrentProgram(station.name);
        if (program != null) {
          _currentProgramMap[station.name] = {
            'program_title': program['title'],
            'start_time': program['start'],
            'end_time': program['end'],
            'is_rerun': false,
          };
          _nowPlayingMap[station.name] = program['title'] as String? ?? '';
          notifyListeners();
        }
        _scheduleListMap[station.name] =
            _scheduleService.getScheduleList(station.name).map((p) => {
              'program_title': p['title'],
              'start_time': p['start'],
              'end_time': p['end'],
            }).toList();
        notifyListeners();
      }
    } catch (e) {
      debugPrint('라디오 재생 실패: $e');
      _errorMessage = '방송을 불러올 수 없습니다.\n다른 채널을 선택해 주세요.';
      _setPlayerState(RadioPlayerState.error);
    }
  }

  String _getReferer(RadioStation station) {
    final url = station.playableUrl.toLowerCase();
    if (url.contains('kbs')) return 'https://www.kbs.co.kr/';
    if (url.contains('imbc') || url.contains('mbc')) return 'https://www.imbc.com/';
    if (url.contains('sbs')) return 'https://www.sbs.co.kr/';
    if (url.contains('ebs')) return 'https://www.ebs.co.kr/';
    if (url.contains('ytn')) return 'https://www.ytn.co.kr/';
    if (url.contains('cbs')) return 'https://www.cbs.co.kr/';
    if (url.contains('tbn')) return 'https://tbn.or.kr/';
    return '';
  }

  String _getOrigin(RadioStation station) {
    final url = station.playableUrl.toLowerCase();
    if (url.contains('kbs')) return 'https://www.kbs.co.kr';
    if (url.contains('imbc') || url.contains('mbc')) return 'https://www.imbc.com';
    if (url.contains('sbs')) return 'https://www.sbs.co.kr';
    if (url.contains('ebs')) return 'https://www.ebs.co.kr';
    if (url.contains('ytn')) return 'https://www.ytn.co.kr';
    if (url.contains('cbs')) return 'https://www.cbs.co.kr';
    if (url.contains('tbn')) return 'https://tbn.or.kr';
    return '';
  }

  Future<void> togglePlayPause() async {
    if (_playerState == RadioPlayerState.playing) {
      await _player.pause();
      await WakelockPlus.disable();
    } else if (_playerState == RadioPlayerState.paused) {
      if (_currentStation != null) {
        await playStation(_currentStation!);
      }
    }
  }

  Future<void> stopRadio() async {
    _setPlayerState(RadioPlayerState.idle);
    await _player.stop();
    _isActuallyPlaying = false;
    _stopForeground();
    await WakelockPlus.disable();
    cancelSleepTimer();
  }

  Future<void> stopRadioAndClear() async {
    await stopRadio();
    _currentStation = null;
    notifyListeners();
  }

  void setQueue(List<RadioStation> stations, int index) {
    _currentQueue = List.from(stations);
    _currentQueueIndex = index;
  }

  Future<void> selectCountry(RadioCountry country) async {
    _selectedCountry = country;
    _selectedBroadcaster = null;
    _broadcasterStations = [];
    notifyListeners();
  }

  List<RadioStation> _countryStations = [];
  bool _isLoadingCountryStations = false;
  List<RadioStation> get countryStations => _countryStations;
  bool get isLoadingCountryStations => _isLoadingCountryStations;
  final Map<String, int> _countryStationCounts = {};
  int? getCountryStationCount(String countryCode) => _countryStationCounts[countryCode];

  Future<void> fetchAllCountryCounts() async {
    if (_countryStationCounts.isNotEmpty) return;
    try {
      final servers = await _getApiServers();
      final uri = Uri.https(servers.first, '/json/countrycodes', {
        'hidebroken': 'true',
      });
      final response = await http.get(uri, headers: _apiHeaders).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        for (final item in data) {
          final code = item['name'] as String? ?? '';
          final count = item['stationcount'] as int? ?? 0;
          if (code.isNotEmpty && count > 0) {
            _countryStationCounts[code] = count > 200 ? 200 : count;
          }
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('국가별 채널 수 로드 실패: $e');
    }
  }

  Future<void> fetchTopStations(String countryCode, {int limit = 200, int retryCount = 0}) async {
    if (retryCount == 0) {
      _countryStations = [];
      _isLoadingCountryStations = true;
      notifyListeners();
    }

    try {
      final servers = await _getApiServers();
      for (final server in servers) {
        final uri = Uri.https(server, '/json/stations/bycountrycodeexact/$countryCode', {
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          'hidebroken': 'true',
          'lastcheckok': '1',
          'codec': 'MP3,AAC,AAC+,OGG',
        });

        final response = await http.get(uri, headers: _apiHeaders).timeout(const Duration(seconds: 15));
        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body);
          _countryStations = data
              .map((j) => RadioStation.fromJson(j as Map<String, dynamic>))
              .where((s) => s.streamUrl.isNotEmpty)
              .toList();
          _mergeFavoriteFlags(_countryStations);
          _countryStationCounts[countryCode] = _countryStations.length;
          break;
        }
      }
    } catch (e) {
      debugPrint('국가별 방송 로드 오류: $e');
    }

    if (_countryStations.isEmpty && retryCount < 4) {
      debugPrint('국가별 방송 재시도: ${retryCount + 1}회차');
      await Future.delayed(const Duration(milliseconds: 1000));
      return fetchTopStations(countryCode, limit: limit, retryCount: retryCount + 1);
    }

    _isLoadingCountryStations = false;
    notifyListeners();
  }

  // ══════ 편성표 ══════
  final Map<String, List<Map<String, dynamic>>> _scheduleListMap = {};
  List<Map<String, dynamic>> get scheduleList =>
      _scheduleListMap[_currentStation?.name ?? ''] ?? [];
  final Map<String, Map<String, dynamic>> _currentProgramMap = {};
  Map<String, dynamic>? get currentProgram {
    final station = _currentStation;
    if (station == null) return null;
    return _currentProgramMap[station.name];
  }
  Map<String, dynamic>? currentProgramFor(String stationName) =>
      _currentProgramMap[stationName];
  final Map<String, String> _nowPlayingMap = {};
  String? nowPlayingFor(String stationName) => _nowPlayingMap[stationName];

  final Set<String> _scheduleAttempted = {};
  bool hasAttemptedSchedule(String stationName) => _scheduleAttempted.contains(stationName);
  void markScheduleAttempted(String stationName) => _scheduleAttempted.add(stationName);

  // 문자 참여 번호
  static const _homepageUrls = {
    'KBS 제1라디오': 'https://radio.kbs.co.kr/',
    'KBS 해피FM': 'https://radio.kbs.co.kr/',
    'KBS Cool FM': 'https://radio.kbs.co.kr/',
    'KBS Classic FM': 'https://radio.kbs.co.kr/',
    'MBC 표준FM': 'https://www.imbc.com/broad/radio/',
    'MBC FM4U': 'https://www.imbc.com/broad/radio/',
    'SBS 파워FM': 'https://www.sbs.co.kr/radio',
    'SBS 러브FM': 'https://www.sbs.co.kr/radio',
    'EBS 반디': 'https://www.ebs.co.kr/radio/home',
    'CBS 표준FM': 'https://www.cbs.co.kr/radio',
    'CBS 음악FM': 'https://www.cbs.co.kr/radio',
  };

  String? homepageFor(String stationName) => _homepageUrls[stationName];

  static const _stationDescriptions = {
    'YTN 라디오': '대한민국 24시간 뉴스 채널',
    'CBS 표준FM': '기독교 정신으로 소통하는 방송',
    'CBS 음악FM': '좋은 음악으로 채우는 하루',
    'BBS 불교방송': '지혜와 자비를 전하는 불교 방송',
    'FEBC 극동방송': '복음을 전하는 기독교 방송',
    '국방FM': '군 장병과 함께하는 방송',
    '국악FM': '우리 소리를 지키는 국악 전문 방송',
    'TBS FM': '시민과 함께하는 교통·생활 정보 방송',
    '경인방송': '인천·경기를 대표하는 라디오 방송',
    'CPBC 가톨릭': '평화와 나눔을 전하는 가톨릭 방송',
    'JTV 매직FM': '전북을 사랑하는 라디오 방송',
    'OBS 라디오': '경인 지역 라디오 방송',
    'BeFM': '부산을 대표하는 FM 방송',
    'TBN 경인교통': '경인 지역 교통·생활 정보 방송',
    'TBN 울산교통': '울산 지역 교통·생활 정보 방송',
    '부산MBC 표준FM': '부산·경남을 대표하는 MBC 방송',
    '부산MBC FM4U': '부산·경남을 대표하는 MBC 방송',
    '광주MBC 표준FM': '광주·전남을 대표하는 MBC 방송',
    '광주MBC FM4U': '광주·전남을 대표하는 MBC 방송',
    '안동MBC 표준FM': '경북 북부를 대표하는 MBC 방송',
    '안동MBC FM4U': '경북 북부를 대표하는 MBC 방송',
    '울산MBC 표준FM': '울산을 대표하는 MBC 방송',
    '제주MBC 표준FM': '제주를 대표하는 MBC 방송',
    '제주MBC FM4U': '제주를 대표하는 MBC 방송',
    '춘천MBC 표준FM': '강원을 대표하는 MBC 방송',
    '춘천MBC FM4U': '강원을 대표하는 MBC 방송',
    '포항MBC 표준FM': '경북 동부를 대표하는 MBC 방송',
    '대전MBC 표준FM': '대전·충남을 대표하는 MBC 방송',
    '목포MBC 표준FM': '전남 서부를 대표하는 MBC 방송',
    'MBC경남 표준FM': '경남을 대표하는 MBC 방송',
    'MBC충북 표준FM': '충북을 대표하는 MBC 방송',
    'MBC충북 FM4U': '충북을 대표하는 MBC 방송',
  };

  String? descriptionFor(String stationName) => _stationDescriptions[stationName];

  static const _smsNumbers = {
    'MBC 표준FM': '8001',
    'MBC FM4U': '8000',
  };

  String? smsNumberFor(String stationName) => _smsNumbers[stationName];

  // KBS
  static const _kbsChannelCodes = {
    'KBS 제1라디오': '21',
    'KBS 해피FM': '22',
    'KBS 3라디오': '23',
    'KBS Classic FM': '24',
    'KBS Cool FM': '25',
  };

  static Map<String, String>? _parseKbsChannelFromUrl(String streamUrl) {
    final match = RegExp(r'channel_code/(\d+)(?:_(\d+))?$').firstMatch(streamUrl);
    if (match == null) return null;
    if (match.group(2) != null) {
      return {'local': match.group(1)!, 'channel': match.group(2)!};
    } else {
      return {'local': '00', 'channel': match.group(1)!};
    }
  }

  Future<void> fetchSchedule(String stationName) async {
    _scheduleListMap.remove(stationName);
    _currentProgramMap.remove(stationName);
    _nowPlayingMap.remove(stationName);
    notifyListeners();

    String? channelCode;
    for (final entry in _kbsChannelCodes.entries) {
      if (stationName.contains(entry.key)) {
        channelCode = entry.value;
        break;
      }
    }
    debugPrint('fetchSchedule 호출됨: $stationName / channelCode: $channelCode');
    if (channelCode == null) return;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final dateStr = '${today.year}${today.month.toString().padLeft(2, '0')}${today.day.toString().padLeft(2, '0')}';
    final yesterdayStr = '${yesterday.year}${yesterday.month.toString().padLeft(2, '0')}${yesterday.day.toString().padLeft(2, '0')}';

    try {
      final uri = Uri.parse(
        'https://static.api.kbs.co.kr/mediafactory/v1/schedule/weekly'
            '?&rtype=json&local_station_code=00'
            '&channel_code=$channelCode'
            '&program_planned_date_from=$yesterdayStr'
            '&program_planned_date_to=$dateStr',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        if (data.isNotEmpty) {
          final List<dynamic> allSchedules = [];
          for (final d in data) {
            allSchedules.addAll(d['schedules'] as List<dynamic>? ?? []);
          }
          // program_code 기준으로 연속된 항목 병합
          final merged = _mergeKbsSchedules(allSchedules.cast<Map<String, dynamic>>());
          for (final s in merged) {
            s['image'] = s['image_w'];
          }
          _scheduleListMap[stationName] = merged;
          final nowHour = now.hour;
          final nowMin = now.minute;
          // 자정 이후면 24시간 형식으로 변환 (예: 00:30 → 2430 형식)
          final nowTimeInt = nowHour < 6
              ? (24 + nowHour) * 1000000 + nowMin * 10000
              : nowHour * 1000000 + nowMin * 10000;
          final currentSchedules = _scheduleListMap[stationName] ?? [];
          for (int i = 0; i < currentSchedules.length; i++) {
            final s = currentSchedules[i];
            final start = s['program_planned_start_time'] as String? ?? '';
            final end = s['program_planned_end_time'] as String? ?? '';
            final startInt = int.tryParse(start) ?? 0;
            final endInt = int.tryParse(end) ?? 0;
            if (nowTimeInt >= startInt && nowTimeInt < endInt) {
              final programCode = s['program_code'] as String? ?? '';
              String finalEnd = end;
              for (int j = i + 1; j < currentSchedules.length; j++) {
                final next = currentSchedules[j];
                if (next['program_code'] == programCode) {
                  finalEnd = next['program_planned_end_time'] as String? ?? finalEnd;
                } else {
                  break;
                }
              }
              final merged = Map<String, dynamic>.from(s);
              merged['program_planned_end_time'] = finalEnd;
              merged['image'] = s['image_w'];
              _currentProgramMap[stationName] = merged;
              _nowPlayingMap[stationName] = s['program_title'] as String? ?? '';
              break;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('편성표 로드 오류: $e');
    }
    notifyListeners();
  }

  Future<void> fetchScheduleByUrl(String stationName, String streamUrl) async {
    final codes = _parseKbsChannelFromUrl(streamUrl);
    debugPrint('fetchScheduleByUrl 호출됨: $stationName / codes: $codes');
    if (codes == null) return;
    final localCode = codes['local']!;
    final channelCode = codes['channel']!;

    _scheduleListMap.remove(stationName);
    _currentProgramMap.remove(stationName);
    _nowPlayingMap.remove(stationName);

    final now = DateTime.now();
    // 새벽 0~5시는 어제 날짜 데이터에 자정 이후 편성이 포함되어 있음
    final targetDay = now.hour < 5
        ? DateTime.now().subtract(const Duration(days: 1))
        : DateTime.now();
    final dateStr = '${targetDay.year}${targetDay.month.toString().padLeft(2, '0')}${targetDay.day.toString().padLeft(2, '0')}';

    try {
      final uri = Uri.parse(
        'https://static.api.kbs.co.kr/mediafactory/v1/schedule/weekly'
            '?rtype=json&local_station_code=$localCode'
            '&channel_code=$channelCode'
            '&program_planned_date_from=$dateStr'
            '&program_planned_date_to=$dateStr',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        if (data.isNotEmpty) {
          final List<dynamic> allSchedules = [];
          for (final d in data) {
            allSchedules.addAll(d['schedules'] as List<dynamic>? ?? []);
          }
          // program_code 기준으로 연속된 항목 병합
          final merged = _mergeKbsSchedules(allSchedules.cast<Map<String, dynamic>>());
          for (final s in merged) {
            s['image'] = s['image_w'];
          }
          _scheduleListMap[stationName] = merged;
          final nowHour = now.hour;
          final nowMin = now.minute;
          final nowTimeInt = nowHour < 6
              ? (24 + nowHour) * 1000000 + nowMin * 10000
              : nowHour * 1000000 + nowMin * 10000;
          final currentSchedules = _scheduleListMap[stationName] ?? [];
          for (int i = 0; i < currentSchedules.length; i++) {
            final s = currentSchedules[i];
            final start = s['program_planned_start_time'] as String? ?? '';
            final end = s['program_planned_end_time'] as String? ?? '';
            final startInt = int.tryParse(start) ?? 0;
            final endInt = int.tryParse(end) ?? 0;
            if (nowTimeInt >= startInt && nowTimeInt < endInt) {
              final programCode = s['program_code'] as String? ?? '';
              String finalEnd = end;
              for (int j = i + 1; j < currentSchedules.length; j++) {
                final next = currentSchedules[j];
                if (next['program_code'] == programCode) {
                  finalEnd = next['program_planned_end_time'] as String? ?? finalEnd;
                } else {
                  break;
                }
              }
              final merged = Map<String, dynamic>.from(s);
              merged['program_planned_end_time'] = finalEnd;
              _currentProgramMap[stationName] = merged;
              _nowPlayingMap[stationName] = s['program_title'] as String? ?? '';
              break;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('지방 편성표 로드 오류: $e');
    }
    _updateNotification(stationName);
    notifyListeners();
  }

  // KBS 편성표: 같은 program_code 연속 항목을 하나로 병합
  // 재방송 여부: rerun_classification == '재방'
  List<Map<String, dynamic>> _mergeKbsSchedules(List<Map<String, dynamic>> schedules) {
    if (schedules.isEmpty) return [];
    final result = <Map<String, dynamic>>[];
    Map<String, dynamic>? current;

    for (final s in schedules) {
      final code = s['program_code'] as String? ?? '';
      final isRerun = (s['rerun_classification'] as String? ?? '') == '재방';

      if (current == null) {
        current = Map<String, dynamic>.from(s);
        current['is_rerun'] = isRerun;
      } else {
        final currentCode = current['program_code'] as String? ?? '';
        if (code == currentCode) {
          // 같은 프로그램 → 끝 시간만 업데이트
          current['program_planned_end_time'] = s['program_planned_end_time'];
        } else {
          result.add(current);
          current = Map<String, dynamic>.from(s);
          current['is_rerun'] = isRerun;
        }
      }
    }
    if (current != null) result.add(current);
    return result;
  }

  String formatScheduleTime(String time) {
    if (time.length < 4) return time;
    int hour = int.tryParse(time.substring(0, 2)) ?? 0;
    final min = time.substring(2, 4);
    if (hour >= 24) hour -= 24;
    final period = hour < 12 ? '오전' : '오후';
    final h12 = hour == 0 ? 12 : (hour > 12 ? hour - 12 : hour);
    return '$period $h12:$min';
  }

  // MBC
  static const _mbcChannelTypes = {
    'MBC 표준FM': 'FM',
    'MBC FM4U': 'FM4U',
  };

  Future<void> fetchMbcSchedule(String stationName) async {
    debugPrint('=== fetchMbcSchedule 호출됨: $stationName ===');
    final sType = _mbcChannelTypes[stationName];
    debugPrint('=== sType: $sType ===');
    if (sType == null) return;

    _scheduleListMap.remove(stationName);
    _currentProgramMap.remove(stationName);
    _nowPlayingMap.remove(stationName);

    try {
      final now = DateTime.now();
      final targetDateStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';

      debugPrint('=== MBC API 호출: sType=$sType, date=$targetDateStr ===');

      final response = await http.get(
        Uri.parse('https://control.imbc.com/Schedule/Radio/Time?sType=$sType&broadDate=$targetDateStr'),
      ).timeout(const Duration(seconds: 10));

      debugPrint('=== MBC API statusCode: ${response.statusCode} ===');
      debugPrint('=== MBC API body 앞부분: ${response.body.substring(0, response.body.length > 500 ? 500 : response.body.length)} ===');

      final List<dynamic> data = [];
      if (response.statusCode == 200) {
        data.addAll(json.decode(response.body) as List<dynamic>);
      }
      debugPrint('=== MBC data.length: ${data.length} ===');
      if (data.isNotEmpty) {
        var filtered = data.where((s) {
          final isToday = s['IsToday'] as String? ?? 'N';
          final start = s['StartTime'] as String? ?? '';
          if (isToday == 'Y') return true;
          final startInt = int.tryParse(start) ?? 9999;
          return startInt < 600;
        }).toList();
        // 필터 결과가 비면(새벽 시간대처럼 새벽 프로그램 정보가 없는 경우) 전체 데이터 사용
        if (filtered.isEmpty) {
          filtered = List.from(data);
        }

        // 시간 순 정렬: 새벽(0000~0559)은 맨 뒤로
        filtered.sort((a, b) {
          final sa = int.tryParse(a['StartTime'] as String? ?? '0') ?? 0;
          final sb = int.tryParse(b['StartTime'] as String? ?? '0') ?? 0;
          final wa = sa < 600 ? sa + 2400 : sa;
          final wb = sb < 600 ? sb + 2400 : sb;
          return wa.compareTo(wb);
        });
        for (final s in filtered) {
          s['image'] = s['Photo'];
        }
        _scheduleListMap[stationName] = filtered.cast<Map<String, dynamic>>();
        final now = DateTime.now();
        final nowH = now.hour;
        final nowM = now.minute;
        final nowHHMM = nowH < 6
            ? '${(nowH + 24).toString().padLeft(2, '0')}${nowM.toString().padLeft(2, '0')}'
            : '${nowH.toString().padLeft(2, '0')}${nowM.toString().padLeft(2, '0')}';
        for (final s in data) {
          String start = s['StartTime']?.toString() ?? '';
          String end = s['EndTime']?.toString() ?? '';
          if (start.isEmpty || end.isEmpty) continue;
          // 새벽 방송 시간 보정
          final startInt = int.tryParse(start) ?? 0;
          if (startInt < 600) start = '${startInt + 2400}';
          final endInt = int.tryParse(end) ?? 0;
          final endAdj = endInt >= 2400 ? '$endInt' : (endInt < 600 ? '${endInt + 2400}' : end);
          if (nowHHMM.compareTo(start) >= 0 && nowHHMM.compareTo(endAdj) < 0) {
            final merged = Map<String, dynamic>.from(s);
            merged['image'] = s['Photo'];
            _currentProgramMap[stationName] = merged;
            _nowPlayingMap[stationName] = s['Title'] as String? ?? '';
            break;
          }
        }
      }
    } catch (e) {
      debugPrint('MBC 편성표 로드 오류: $e');
    }
    _updateNotification(stationName);
    notifyListeners();
  }

  // SBS
  static const _sbsChannelTypes = {
    'SBS 파워FM': 'Power',
    'SBS 러브FM': 'Love',
  };

  Future<void> fetchBbsSchedule() async {
    const stationName = 'BBS 불교방송';
    _scheduleListMap.remove(stationName);
    _currentProgramMap.remove(stationName);
    _nowPlayingMap.remove(stationName);
    try {
      final today = DateTime.now();
      final dateStr = '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final httpClient = HttpClient()
        ..badCertificateCallback = (cert, host, port) => host == 'm.bbsi.co.kr';
      final ioClient = IOClient(httpClient);

      const commonUA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36';

      // 1단계: 메인 페이지 먼저 방문해서 쿠키 받기
      String cookieHeader = '';
      try {
        final mainResponse = await ioClient.get(
          Uri.parse('https://m.bbsi.co.kr/M/?ACT=RADIO_FM'),
          headers: {'User-Agent': commonUA},
        ).timeout(const Duration(seconds: 10));
        final setCookie = mainResponse.headers['set-cookie'];
        if (setCookie != null) {
          cookieHeader = setCookie.split(',').map((c) => c.split(';').first.trim()).join('; ');
        }
        debugPrint('BBS 쿠키 획득: $cookieHeader');
      } catch (e) {
        debugPrint('BBS 메인페이지 접속 오류: $e');
      }

      // 2단계: 쿠키 들고 편성표 요청
      final response = await ioClient.get(
        Uri.parse('https://m.bbsi.co.kr/M/ajaxSchedule.html?CODE=WWW&SchGubun=RADIO&SchDate=$dateStr'),
        headers: {
          'User-Agent': commonUA,
          'Referer': 'https://m.bbsi.co.kr/M/?ACT=RADIO_FM',
          'X-Requested-With': 'XMLHttpRequest',
          if (cookieHeader.isNotEmpty) 'Cookie': cookieHeader,
        },
      ).timeout(const Duration(seconds: 10));
      ioClient.close();

      debugPrint('BBS statusCode: ${response.statusCode}, body length: ${response.body.length}');
      if (response.statusCode == 200) {
        final body = response.body;
        debugPrint('BBS body 앞부분: ${body.substring(0, body.length > 300 ? 300 : body.length)}');
        final blockRegex = RegExp(
          r'<div class="program( onairbox)?">(.*?)<!-- UNIT E -->|<div class="program( onairbox)?">(.*?)<!-- ONAIR E -->',
          dotAll: true,
        );
        final timeRegex = RegExp(r'<p>(\d{2}:\d{2})</p>');
        final titleRegex = RegExp(r'<strong>(.*?)</strong>');
        final onAirRegex = RegExp(r'ON AIR');
        final imgRegex = RegExp(r'<img src="(.*?)">');

        final matches = blockRegex.allMatches(body).toList();
        debugPrint('BBS 매칭된 방송 개수: ${matches.length}');
        final schedules = <Map<String, dynamic>>[];
        int? currentIdx;
        for (final m in matches) {
          final block = (m.group(2) ?? m.group(4) ?? '');
          final time = timeRegex.firstMatch(block)?.group(1) ?? '';
          final title = titleRegex.firstMatch(block)?.group(1)?.trim() ?? '';
          final image = imgRegex.firstMatch(block)?.group(1);
          final isOnAir = onAirRegex.hasMatch(block);
          if (time.isEmpty || title.isEmpty) continue;
          if (schedules.isEmpty) {
            debugPrint('BBS 블록 예시(이미지 태그 확인용): ${block.substring(0, block.length > 400 ? 400 : block.length)}');
            debugPrint('BBS 추출된 image 값: $image');
          }
          schedules.add({'start_time': time, 'title': title, 'image': image});
          if (isOnAir) currentIdx = schedules.length - 1;
        }
        _scheduleListMap[stationName] = schedules;
        if (currentIdx != null) {
          final cur = schedules[currentIdx];
          final end = currentIdx + 1 < schedules.length
              ? schedules[currentIdx + 1]['start_time'] as String
              : '';
          _currentProgramMap[stationName] = {
            'program_title': cur['title'],
            'start_time': cur['start_time'],
            'end_time': end,
            'is_rerun': false,
            'image': cur['image'],
          };
          _nowPlayingMap[stationName] = cur['title'] as String? ?? '';
        }
      }
    } catch (e) {
      debugPrint('BBS 편성표 로드 오류: $e');
    }
    _updateNotification(stationName);
    notifyListeners();
  }

  void _listenConnectivity() {
    List<ConnectivityResult> _lastResults = [];
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) async {
      final isNone = results.isEmpty || (results.contains(ConnectivityResult.none) && results.length == 1);
      final wasNone = _lastResults.isEmpty || (_lastResults.contains(ConnectivityResult.none) && _lastResults.length == 1);
      final networkChanged = !isNone && _lastResults.isNotEmpty && !wasNone && results.toString() != _lastResults.toString();
      _lastResults = List.from(results);

      if (_currentStation == null) return;

      // 네트워크 없음→있음 복구 시
      if (!isNone && wasNone && !_isActuallyPlaying &&
          _playerState != RadioPlayerState.idle &&
          _playerState != RadioPlayerState.error) {
        debugPrint('네트워크 복구 감지 - 라디오 재연결 시도');
        await Future.delayed(const Duration(seconds: 2));
        if (_currentStation != null && !_isActuallyPlaying) {
          await playStation(_currentStation!);
        }
      }
      // WiFi↔LTE 전환 시 (스트림 끊김 대비)
      else if (networkChanged &&
          _playerState != RadioPlayerState.idle &&
          _playerState != RadioPlayerState.error) {
        debugPrint('네트워크 전환 감지 - 라디오 재연결 시도');
        await Future.delayed(const Duration(milliseconds: 800));
        if (_currentStation != null && !_isActuallyPlaying) {
          await playStation(_currentStation!);
        }
      }
    });
  }

  // dispose는 아래 기존 것에 합칩니다

  void _updateNotification(String stationName) {
    if (_currentStation?.name != stationName) return;
    final program = _currentProgramMap[stationName];
    debugPrint('=== _updateNotification: $stationName / program: $program ===');
    if (program == null) return;
    final programTitle = program['program_title'] as String?
        ?? program['Title'] as String?
        ?? program['title'] as String?
        ?? _nowPlayingMap[stationName]
        ?? '';
    if (programTitle.isEmpty) return;
    // 시간 추출
    final start = program['program_planned_start_time'] as String?
        ?? program['StartTime'] as String?
        ?? program['start_time'] as String?
        ?? '';
    final end = program['program_planned_end_time'] as String?
        ?? program['EndTime'] as String?
        ?? program['end_time'] as String?
        ?? '';
    String artist = programTitle;
    if (start.isNotEmpty && end.isNotEmpty) {
      // KBS 시간 포맷 변환 (20000000 → 20:00)
      String fmtTime(String t) {
        if (t.length >= 6) {
          int h = int.tryParse(t.substring(0, 2)) ?? 0;
          final m = t.substring(2, 4);
          if (h >= 24) h -= 24;
          return '$h:$m';
        }
        if (t.contains(':')) return t;
        if (t.length == 4) {
          int h = int.tryParse(t.substring(0, 2)) ?? 0;
          final m = t.substring(2, 4);
          if (h >= 24) h -= 24;
          return '$h:$m';
        }
        return t;
      }
      artist = '$programTitle ${fmtTime(start)}~${fmtTime(end)}';
    }
    _simpleHandler?.setRadioMediaItem(
      title: stationName,
      artist: artist,
      url: _currentStation?.streamUrl ?? '',
    );
  }

  Future<void> _updateWidget(String title, String artist, bool isPlaying) async {
    try {
      const platform = MethodChannel('kr.ssing.catsong/media');
      final program = _currentProgramMap[title];
      String schedule = '';
      String programTitle = '';
      if (program != null) {
        programTitle = program['program_title'] as String? ?? '';
        final start = program['start_time'] as String? ?? '';
        final end = program['end_time'] as String? ?? '';
        if (programTitle.isNotEmpty) {
          schedule = start.isNotEmpty ? '$programTitle $start~$end' : programTitle;
        }
      }
      await platform.invokeMethod('updateWidget', {
        'title': title,
        'artist': artist,
        'isPlaying': isPlaying,
        'schedule': schedule,
      });
      // 알림바(미디어 컨트롤)도 업데이트
      if (programTitle.isNotEmpty) {
        _simpleHandler?.setRadioMediaItem(
          title: title,
          artist: programTitle,
          url: '',
        );
      }
    } catch (e) {
      debugPrint('위젯 업데이트 오류: $e');
    }
  }

  Future<void> fetchKfnSchedule() async {
    const stationName = '국방FM';
    debugPrint('=== fetchKfnSchedule 호출됨 ===');
    try {
      final response = await http.post(
        Uri.parse('https://radio.dema.mil.kr/web/api/v1/media/fm/nowProgram/ajaxList.do'),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
          'Referer': 'https://radio.dema.mil.kr/web/radio/main.do',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'sort_type': 'TIME',
          'program_type': '',
          'select_type': '',
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        debugPrint('=== KFN API 응답: ${response.body} ===');
        final map = data['map'];
        if (map == null) {
          debugPrint('=== KFN map null ===');
          return;
        }

        // 현재 방송 중인 프로그램
        final current = map['timeTableExt'];
        final title = current['fm_program_title'] as String? ?? '';
        final start = current['fm_program_time'] as String? ?? '';
        final end = current['fm_program_end_time'] as String? ?? '';

        if (title.isNotEmpty) {
          // 시간 포맷 변환 (1605 → 16:05)
          String fmt(String t) {
            if (t.length < 4) return t;
            return '${t.substring(0, 2)}:${t.substring(2, 4)}';
          }
          _currentProgramMap[stationName] = {
            'program_title': title,
            'start_time': fmt(start),
            'end_time': fmt(end),
            'is_rerun': false,
          };
          _nowPlayingMap[stationName] = title;
        }

        // 전체 편성표
        final list = map['fmNowHomeList'] as List<dynamic>? ?? [];
        final schedules = <Map<String, dynamic>>[];
        for (final item in list) {
          final name = item['homepage_nm'] as String? ?? '';
          final time = item['regular_brodcasting'] as String? ?? '';
          if (name.isEmpty || time.isEmpty || time.trim().isEmpty) continue;

          // "(월~일) 16:05~18:00" 파싱
          final match = RegExp(r'(\d{2}:\d{2})~(\d{2}:\d{2})').firstMatch(time);
          if (match != null) {
            schedules.add({
              'program_title': name,
              'start_time': match.group(1)!,
              'end_time': match.group(2)!,
            });
          }
        }
        // 시간순 정렬
        schedules.sort((a, b) {
          final sa = a['start_time'] as String;
          final sb = b['start_time'] as String;
          return sa.compareTo(sb);
        });
        _scheduleListMap[stationName] = schedules;
        notifyListeners();
        if (_currentStation?.name == stationName) {
          _updateWidget(stationName, _currentStation?.country ?? '', true);
        }
      }
    } catch (e) {
      debugPrint('국방FM 편성표 로드 오류: $e');
    }
  }

  Future<void> fetchEbsFmSchedule() async {
    const stationName = 'EBS FM';
    try {
      final response = await http.get(
        Uri.parse('https://www.ebs.co.kr/onair/scheduleNew.json?channelCodeString=FM&mode=newlist'),
        headers: {'User-Agent': 'Mozilla/5.0'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final now = data['nowProgram'];
        if (now != null) {
          final title = now['title'] as String? ?? '';
          final start = now['start'] as String? ?? '';
          final end = now['end'] as String? ?? '';
          if (title.isNotEmpty) {
            _currentProgramMap[stationName] = {
              'program_title': title,
              'start_time': start,
              'end_time': end,
            };
            _nowPlayingMap[stationName] = title;
          }
        }
        final list = data['program'] as List<dynamic>? ?? [];
        final schedules = <Map<String, dynamic>>[];
        final seenTimes = <String>{};
        for (final item in list) {
          final title = item['title'] as String? ?? '';
          final start = item['start'] as String? ?? '';
          final end = item['end'] as String? ?? '';
          if (title.isEmpty || title == '라디오 캠페인') continue;
          if (seenTimes.contains(start)) continue;
          seenTimes.add(start);
          schedules.add({
            'program_title': title,
            'start_time': start,
            'end_time': end,
          });
        }
        _scheduleListMap[stationName] = schedules;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('EBS FM 편성표 로드 오류: $e');
    }
  }

  Future<void> fetchEbsBandiSchedule() async {
    const stationName = 'EBS 반디';
    try {
      final response = await http.get(
        Uri.parse('https://www.ebs.co.kr/onair/scheduleNew.json?channelCodeString=IRADIO&mode=newlist'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // 현재 방송 중인 프로그램
        final now = data['nowProgram'];
        if (now != null) {
          final title = now['title'] as String? ?? '';
          final start = now['start'] as String? ?? '';
          final end = now['end'] as String? ?? '';
          if (title.isNotEmpty) {
            _currentProgramMap[stationName] = {
              'program_title': title,
              'start_time': start,
              'end_time': end,
            };
            _nowPlayingMap[stationName] = title;
          }
        }

        // 전체 편성표 (라디오 캠페인 제외, 중복 시간 제거)
        final list = data['program'] as List<dynamic>? ?? [];
        final schedules = <Map<String, dynamic>>[];
        final seenTimes = <String>{};
        for (final item in list) {
          final title = item['title'] as String? ?? '';
          final start = item['start'] as String? ?? '';
          final end = item['end'] as String? ?? '';
          if (title.isEmpty || title == '라디오 캠페인') continue;
          if (seenTimes.contains(start)) continue;
          seenTimes.add(start);
          schedules.add({
            'program_title': title,
            'start_time': start,
            'end_time': end,
          });
        }
        _scheduleListMap[stationName] = schedules;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('EBS 반디 편성표 로드 오류: $e');
    }
  }

  Future<void> fetchJsonSchedule(String stationName) async {
    debugPrint('=== fetchJsonSchedule 호출: $stationName ===');
    debugPrint('=== hasSchedule: ${_scheduleService.hasSchedule(stationName)} ===');
    if (!_scheduleService.hasSchedule(stationName)) return;
    final program = _scheduleService.getCurrentProgram(stationName);
    debugPrint('=== getCurrentProgram: $program ===');
    if (program != null) {
      _currentProgramMap[stationName] = {
        'program_title': program['title'],
        'start_time': program['start'],
        'end_time': program['end'],
        'is_rerun': false,
      };
      _nowPlayingMap[stationName] = program['title'] as String? ?? '';
    }
    _scheduleListMap[stationName] =
        _scheduleService.getScheduleList(stationName).map((p) => {
          'program_title': p['title'],
          'start_time': p['start'],
          'end_time': p['end'],
        }).toList();
    notifyListeners();
    if (_currentStation?.name == stationName) {
      _updateWidget(stationName, _currentStation?.country ?? '', true);
    }
  }

  Future<void> fetchSbsSchedule(String stationName) async {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final cacheKey = '${stationName}_$today';
    if (_scheduleListMap.containsKey(cacheKey) && _scheduleListMap[cacheKey]!.isNotEmpty) return;
    final type = _sbsChannelTypes[stationName];
    if (type == null) return;

    _scheduleListMap.remove(stationName);
    _currentProgramMap.remove(stationName);
    _nowPlayingMap.remove(stationName);

    try {
      final now = DateTime.now();
      // 새벽 0~5시는 어제 날짜 데이터에 새벽 방송 포함
      final targetDay = now.hour < 5
          ? now.subtract(const Duration(days: 1))
          : now;
      final uri = Uri.parse(
        'https://static.cloud.sbs.co.kr/schedule/${targetDay.year}/${targetDay.month}/${targetDay.day}/$type.json',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      final List<dynamic> data = [];
      if (response.statusCode == 200) {
        data.addAll(json.decode(response.body) as List<dynamic>);
      }
      if (data.isNotEmpty) {
        for (final s in data) {
          if (s is Map<String, dynamic>) {
            s['image'] = s['program_image'];
          }
        }
        _scheduleListMap[stationName] = data.cast<Map<String, dynamic>>();
        // 현재 방송 찾기 (25:00 형식 처리)
        final nowH = now.hour;
        final nowM = now.minute;
        // 새벽이면 24 더해서 비교 (예: 01:30 → 25:30)
        final nowTotal = nowH < 5 ? (nowH + 24) * 60 + nowM : nowH * 60 + nowM;
        for (final s in data) {
          final start = s['start_time'] as String? ?? '';
          final end = s['end_time'] as String? ?? '';
          if (start.isEmpty || end.isEmpty) continue;
          final startParts = start.split(':');
          final endParts = end.split(':');
          final startTotal = int.parse(startParts[0]) * 60 + int.parse(startParts[1]);
          final endTotal = int.parse(endParts[0]) * 60 + int.parse(endParts[1]);
          if (nowTotal >= startTotal && nowTotal < endTotal) {
            final merged = Map<String, dynamic>.from(s);
            merged['image'] = s['program_image'];
            _currentProgramMap[stationName] = merged;
            _nowPlayingMap[stationName] = s['title'] as String? ?? '';
            break;
          }
        }
      }
    } catch (e) {
      debugPrint('SBS 편성표 로드 오류: $e');
    }
    _updateNotification(stationName);
    notifyListeners();
  }

  void _updateCurrentPrograms() {
    final now = DateTime.now();
    final nowTime = '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}0000';
    final nowHHMM = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final nowHHMMno = '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
    bool changed = false;

    // MBC
    for (final stationName in _mbcChannelTypes.keys) {
      if (!_scheduleListMap.containsKey(stationName)) continue;
      final schedules = _scheduleListMap[stationName] ?? [];
      for (final s in schedules) {
        final start = s['StartTime'] as String? ?? '';
        final end = s['EndTime'] as String? ?? '';
        final endAdj = end == '2400' ? '0000' : end;
        if (nowHHMMno.compareTo(start) >= 0 &&
            (end == '2400' || nowHHMMno.compareTo(endAdj) < 0)) {
          final newTitle = s['Title'] as String? ?? '';
          if (_nowPlayingMap[stationName] != newTitle) {
            _currentProgramMap[stationName] = Map<String, dynamic>.from(s);
            _nowPlayingMap[stationName] = newTitle;
            changed = true;
          }
          break;
        }
      }
    }

    // SBS
    for (final stationName in _sbsChannelTypes.keys) {
      if (!_scheduleListMap.containsKey(stationName)) continue;
      final schedules = _scheduleListMap[stationName] ?? [];
      for (final s in schedules) {
        final start = s['start_time'] as String? ?? '';
        var end = s['end_time'] as String? ?? '';
        if (end.isNotEmpty && int.parse(end.split(':')[0]) >= 24) end = '23:59';
        if (nowHHMM.compareTo(start) >= 0 && nowHHMM.compareTo(end) < 0) {
          final newTitle = s['title'] as String? ?? '';
          if (_nowPlayingMap[stationName] != newTitle) {
            _currentProgramMap[stationName] = Map<String, dynamic>.from(s);
            _nowPlayingMap[stationName] = newTitle;
            changed = true;
          }
          break;
        }
      }
    }

    // KBS
    final nowHour2 = now.hour;
    final nowMin2 = now.minute;
    final nowTimeInt2 = nowHour2 < 5
        ? (24 + nowHour2) * 1000000 + nowMin2 * 10000
        : nowHour2 * 1000000 + nowMin2 * 10000;
    for (final stationName in _scheduleListMap.keys) {
      if (_mbcChannelTypes.containsKey(stationName)) continue;
      if (_sbsChannelTypes.containsKey(stationName)) continue;
      final currentSchedules = _scheduleListMap[stationName] ?? [];
      for (int i = 0; i < currentSchedules.length; i++) {
        final s = currentSchedules[i];
        final start = s['program_planned_start_time'] as String? ?? '';
        final end = s['program_planned_end_time'] as String? ?? '';
        final startInt = int.tryParse(start) ?? 0;
        final endInt = int.tryParse(end) ?? 0;
        if (nowTimeInt2 >= startInt && nowTimeInt2 < endInt) {
          final newTitle = s['program_title'] as String? ?? '';
          if (_nowPlayingMap[stationName] != newTitle) {
            final programCode = s['program_code'] as String? ?? '';
            String finalEnd = end;
            for (int j = i + 1; j < currentSchedules.length; j++) {
              final next = currentSchedules[j];
              if (next['program_code'] == programCode) {
                finalEnd = next['program_planned_end_time'] as String? ?? finalEnd;
              } else {
                break;
              }
            }
            final merged = Map<String, dynamic>.from(s);
            merged['program_planned_end_time'] = finalEnd;
            _currentProgramMap[stationName] = merged;
            _nowPlayingMap[stationName] = newTitle;
            changed = true;
          }
          break;
        }
      }
    }

    if (changed) notifyListeners();
  }

  Timer? _scheduleRefreshTimer;
  Timer? _scheduleDisplayTimer;

  void _startScheduleRefreshTimer() {
    _scheduleRefreshTimer?.cancel();
    _scheduleRefreshTimer = Timer.periodic(
      const Duration(minutes: 10),
          (_) {
            for (final name in _kbsChannelCodes.keys) {
              if (_scheduleListMap.containsKey(name)) fetchSchedule(name);
            }
        for (final name in _mbcChannelTypes.keys) {
          if (_scheduleListMap.containsKey(name)) fetchMbcSchedule(name);
        }
        for (final name in _sbsChannelTypes.keys) {
          if (_scheduleListMap.containsKey(name)) fetchSbsSchedule(name);
        }
      },
    );
    _scheduleDisplayTimer?.cancel();
    _scheduleDisplayTimer = Timer.periodic(
      const Duration(minutes: 1),
          (_) => _updateCurrentPrograms(),
    );
  }

  Future<void> selectBroadcaster(RadioBroadcaster broadcaster) async {
    _selectedBroadcaster = broadcaster;
    _broadcasterStations = [];
    notifyListeners();

    try {
      for (final server in _apiServers) {
        final uri = Uri.https(server, '/json/stations/search', {
          'name': broadcaster.keyword,
          'countrycode': _selectedCountry?.code ?? '',
          'limit': '20',
          'order': 'votes',
          'reverse': 'true',
          'hidebroken': 'true',
        });
        final response = await http.get(uri, headers: _apiHeaders).timeout(const Duration(seconds: 15));
        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body);
          _broadcasterStations = data
              .map((j) => RadioStation.fromJson(j as Map<String, dynamic>))
              .where((s) => s.streamUrl.isNotEmpty)
              .toList();
          _mergeFavoriteFlags(_broadcasterStations);
          notifyListeners();
          for (final station in _broadcasterStations) {
            if (_kbsChannelCodes.keys.any((k) => station.name.contains(k))) {
              fetchSchedule(station.name);
            }
          }
          return;
        }
      }
    } catch (e) {
      debugPrint('방송사 로드 오류: $e');
    }
    notifyListeners();
  }

  Future<void> searchStations(String query) async {
    if (query.length < 2) {
      _searchResults = [];
      notifyListeners();
      return;
    }

    try {
      for (final server in _apiServers) {
        final uri = Uri.https(server, '/json/stations/search', {
          'name': query,
          'limit': '30',
          'order': 'votes',
          'reverse': 'true',
          'hidebroken': 'true',
        });
        final response = await http.get(uri, headers: _apiHeaders).timeout(const Duration(seconds: 15));
        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body);
          _searchResults = data
              .map((j) => RadioStation.fromJson(j as Map<String, dynamic>))
              .where((s) => s.streamUrl.isNotEmpty)
              .toList();
          _mergeFavoriteFlags(_searchResults);
          notifyListeners();
          return;
        }
      }
    } catch (e) {
      _searchResults = [];
    }
    notifyListeners();
  }

  void clearSearch() {
    _searchResults = [];
    notifyListeners();
  }

  Future<void> toggleFavorite(RadioStation station) async {
    final idx = _favorites.indexWhere((s) => s.stationUuid == station.stationUuid);
    if (idx >= 0) {
      _favorites.removeAt(idx);
      station.isFavorite = false;
    } else {
      station.isFavorite = true;
      _favorites.add(station);
    }
    _syncFavoriteFlag(station.stationUuid, station.isFavorite);
    notifyListeners();
    await _saveToPrefs();
  }

  bool isFavorite(String stationUuid) =>
      _favorites.any((s) => s.stationUuid == stationUuid);

  Future<void> recordListened(RadioStation station) async {
    station.lastListened = DateTime.now();
    _recentlyListened.removeWhere((s) => s.stationUuid == station.stationUuid);
    _recentlyListened.insert(0, station);
    if (_recentlyListened.length > _maxRecent) {
      _recentlyListened = _recentlyListened.sublist(0, _maxRecent);
    }
    notifyListeners();
    await _saveToPrefs();
  }

  void setSleepTimer(Duration duration) {
    cancelSleepTimer();
    _sleepRemaining = duration;
    _sleepTimer = Timer(duration, () async {
      await _player.stop();
      await WakelockPlus.disable();
      _isActuallyPlaying = false;
      _setPlayerState(RadioPlayerState.idle);
      _updateForeground(false);
      cancelSleepTimer();
    });
    _sleepCountdown = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_sleepRemaining == null || _sleepRemaining!.inSeconds <= 0) {
        cancelSleepTimer();
        return;
      }
      _sleepRemaining = _sleepRemaining! - const Duration(seconds: 1);
      notifyListeners();
    });
    notifyListeners();
  }

  void cancelSleepTimer() {
    _scheduleCheckTimer?.cancel();
    _sleepTimer?.cancel();
    _sleepCountdown?.cancel();
    _sleepTimer = null;
    _sleepCountdown = null;
    _sleepRemaining = null;
    notifyListeners();
  }

  void addSchedule(TimeOfDay time, RadioStation station) {
    if (_schedules.length >= _maxSchedules) return;
    _schedules.add(ScheduledStation(time: time, station: station));
    _schedules.sort((a, b) {
      final aMin = a.time.hour * 60 + a.time.minute;
      final bMin = b.time.hour * 60 + b.time.minute;
      return aMin.compareTo(bMin);
    });
    _startScheduleCheck();
    _saveSchedules();
    notifyListeners();
  }

  void removeSchedule(int index) {
    if (index >= 0 && index < _schedules.length) {
      _schedules.removeAt(index);
      if (_schedules.isEmpty) _stopScheduleCheck();
      _saveSchedules();
      notifyListeners();
    }
  }

  void clearSchedules() {
    _schedules.clear();
    _stopScheduleCheck();
    _saveSchedules();
    notifyListeners();
  }

  void _startScheduleCheck() {
    _scheduleCheckTimer?.cancel();
    _scheduleCheckTimer = Timer.periodic(
      const Duration(seconds: 30),
          (_) => _checkSchedules(),
    );
  }

  void _stopScheduleCheck() {
    _scheduleCheckTimer?.cancel();
    _scheduleCheckTimer = null;
  }

  void _checkSchedules() {
    if (_schedules.isEmpty) return;
    final now = TimeOfDay.now();
    final nowMin = now.hour * 60 + now.minute;

    for (int i = 0; i < _schedules.length; i++) {
      final s = _schedules[i];
      final sMin = s.time.hour * 60 + s.time.minute;
      if (nowMin == sMin && !s.triggered) {
        playStation(s.station);
        _schedules.removeAt(i);
        if (_schedules.isEmpty) _stopScheduleCheck();
        _saveSchedules();
        notifyListeners();
        break;
      }
    }
  }

  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final favJson = prefs.getStringList(_keyFavorites) ?? [];
    _favorites = favJson.map((s) {
      try {
        return RadioStation.fromJson(json.decode(s) as Map<String, dynamic>)..isFavorite = true;
      } catch (_) {
        return null;
      }
    }).whereType<RadioStation>().toList();

    final recentJson = prefs.getStringList(_keyRecent) ?? [];
    _recentlyListened = recentJson.map((s) {
      try {
        return RadioStation.fromJson(json.decode(s) as Map<String, dynamic>);
      } catch (_) {
        return null;
      }
    }).whereType<RadioStation>().toList();
    final oneMonthAgo = DateTime.now().subtract(const Duration(days: 30));
    _recentlyListened.removeWhere((s) => s.lastListened != null && s.lastListened!.isBefore(oneMonthAgo));

    final scheduleJson = prefs.getStringList(_keySchedules) ?? [];
    _schedules = scheduleJson.map((s) {
      try {
        return ScheduledStation.fromJson(json.decode(s) as Map<String, dynamic>);
      } catch (_) {
        return null;
      }
    }).whereType<ScheduledStation>().toList();
    if (_schedules.isNotEmpty) {
      _startScheduleCheck();
    }

    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_keyFavorites, _favorites.map((s) => json.encode(s.toJson())).toList());
    await prefs.setStringList(_keyRecent, _recentlyListened.map((s) => json.encode(s.toJson())).toList());
  }

  Future<void> _saveSchedules() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_keySchedules, _schedules.map((s) => json.encode(s.toJson())).toList());
  }

  void _setPlayerState(RadioPlayerState state) {
    _playerState = state;
    notifyListeners();
  }

  void _mergeFavoriteFlags(List<RadioStation> stations) {
    for (final s in stations) {
      s.isFavorite = isFavorite(s.stationUuid);
    }
  }

  void _syncFavoriteFlag(String uuid, bool value) {
    for (final list in [_broadcasterStations, _searchResults]) {
      for (final s in list) {
        if (s.stationUuid == uuid) s.isFavorite = value;
      }
    }
    if (_currentStation?.stationUuid == uuid) {
      _currentStation?.isFavorite = value;
    }
  }

  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    _player.dispose();
    _sleepTimer?.cancel();
    _sleepCountdown?.cancel();
    _scheduleRefreshTimer?.cancel();
    _scheduleDisplayTimer?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }
}

class ScheduledStation {
  final TimeOfDay time;
  final RadioStation station;
  bool triggered;

  ScheduledStation({
    required this.time,
    required this.station,
    this.triggered = false,
  });

  String get timeString {
    final h = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final m = time.minute.toString().padLeft(2, '0');
    final period = time.period == DayPeriod.am ? '오전' : '오후';
    return '$period $h:$m';
  }

  Map<String, dynamic> toJson() => {
    'hour': time.hour,
    'minute': time.minute,
    'station': station.toJson(),
  };

  factory ScheduledStation.fromJson(Map<String, dynamic> json) {
    return ScheduledStation(
      time: TimeOfDay(
        hour: json['hour'] as int,
        minute: json['minute'] as int,
      ),
      station: RadioStation.fromJson(json['station'] as Map<String, dynamic>),
    );
  }
}