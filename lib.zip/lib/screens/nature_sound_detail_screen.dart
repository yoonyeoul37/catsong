import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/cupertino.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../utils/paran_photo.dart';
import '../utils/greeting_images.dart';
import '../widgets/farewell_title.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../providers/sound_mix_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'settings_screen.dart';
import 'sound_mix_screen.dart';
import 'package:just_audio/just_audio.dart';
import '../widgets/more_menu_sheet.dart';
import '../widgets/exit_confirm_dialog.dart';
import 'nature_sounds_screen.dart';
import '../widgets/paran_dialog.dart';
import '../widgets/heart_pop.dart';

class NatureSoundDetailScreen extends StatefulWidget {
  final String name;
  final IconData icon;
  final String description;
  final String? assetPath;
  final Color color;
  final bool openedFromList;

  const NatureSoundDetailScreen({
    super.key,
    required this.name,
    required this.icon,
    required this.description,
    required this.assetPath,
    required this.color,
    this.openedFromList = true,
  });

  @override
  State<NatureSoundDetailScreen> createState() => _NatureSoundDetailScreenState();
}

class _NatureSoundDetailScreenState extends State<NatureSoundDetailScreen> {
  Timer? _sleepTicker;
  DateTime? _sleepEndTime;
  int? _sleepMinutes;
  String? _lastSleepLabel; // 화면에 보이는 남은 시간 글자 (바뀔 때만 다시 그림)
  bool _sleepFading = false; // 수면 타이머 끝나기 1분 전부터 작게 하는 중
  PlayerProvider? _pp; // 화면을 나갈 때도 소리 크기를 돌려놓으려고 미리 잡아둠
  Set<String> _favoriteNames = {};

  /// 소리 크기 원래대로 (다음에 틀 때 작게 나오지 않게)
  void _restoreSleepFade() {
    if (!_sleepFading) return;
    _sleepFading = false;
    _pp?.player.setVolume(1.0);
  }

  @override
  void initState() {
    super.initState();
    _pp = context.read<PlayerProvider>();
    _loadFavorites();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mix = context.read<SoundMixProvider>();
      if (mix.isPlaying) {
        mix.stopAll();
      }
      final pp = context.read<PlayerProvider>();
      final alreadyPlaying = pp.natureSoundName == widget.name && pp.isPlaying;
      if (!alreadyPlaying && widget.assetPath != null) {
        pp.playNatureSound(widget.assetPath!, widget.name);
      }
    });
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList('nature_favorites') ?? [];
    if (mounted) setState(() => _favoriteNames = favs.toSet());
  }

  Future<void> _toggleFavorite(String name) async {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList('nature_favorites') ?? [];
    final nowFavorite = !_favoriteNames.contains(name);
    setState(() {
      if (nowFavorite) {
        _favoriteNames.add(name);
      } else {
        _favoriteNames.remove(name);
      }
    });
    if (nowFavorite) {
      if (!favs.contains(name)) favs.add(name);
    } else {
      favs.remove(name);
    }
    await prefs.setStringList('nature_favorites', favs);
    // (하트가 바로 바뀌어서 따로 알림 없음)
  }

  void _showCenterToast(String message) {
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => Positioned.fill(
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: 1.0),
            duration: const Duration(milliseconds: 300),
            builder: (_, value, child) => Opacity(
              opacity: value,
              child: Transform.scale(scale: 0.85 + 0.15 * value, child: child),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Text(
                message,
                style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(entry);
    Future.delayed(const Duration(seconds: 2), () => entry.remove());
  }

  @override
  void dispose() {
    _sleepTicker?.cancel();
    _restoreSleepFade();
    super.dispose();
  }

  void _setSleepTimer(int? minutes) {
    _sleepTicker?.cancel();
    _restoreSleepFade();
    if (minutes == null) {
      setState(() {
        _sleepMinutes = null;
        _sleepEndTime = null;
      });
      return;
    }
    setState(() {
      _sleepMinutes = minutes;
      _sleepEndTime = DateTime.now().add(Duration(minutes: minutes));
    });
    _sleepTicker = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      final remaining = _sleepEndTime!.difference(DateTime.now());
      if (remaining.isNegative || remaining == Duration.zero) {
        timer.cancel();
        context.read<PlayerProvider>().stopNatureSound().then((_) {
          if (mounted) _restoreSleepFade();
        });
        setState(() {
          _sleepMinutes = null;
          _sleepEndTime = null;
        });
      } else {
        // 끝나기 1분 전부터 천천히 작게
        if (remaining.inSeconds < 60) {
          _sleepFading = true;
          context.read<PlayerProvider>().player.setVolume(remaining.inMilliseconds / 60000.0);
        }
        // 'N분' 글자가 바뀔 때만 화면 다시 그리기 (1초마다 사진까지 다시 그리지 않게)
        final label = _formatRemaining();
        if (label != _lastSleepLabel) {
          _lastSleepLabel = label;
          setState(() {});
        }
      }
    });
  }

  String _formatRemaining() {
    if (_sleepEndTime == null) return '타이머';
    final remaining = _sleepEndTime!.difference(DateTime.now());
    if (remaining.isNegative) return '타이머';
    final h = remaining.inHours;
    final m = remaining.inMinutes % 60;
    if (h > 0) return '$h시간 $m분';
    return '$m분';
  }

  void _showCustomMinutesDialog(bool isDarkMode) {
    Duration picked = const Duration(minutes: 30);
    final textColor = isDarkMode ? Colors.white : Colors.black;
    showModalBottomSheet(
      context: context,
      backgroundColor: isDarkMode ? const Color(0xFF32302C) : const Color(0xFFF4EFE5), // 다른 창과 같은 색
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 제목 가운데 + 오른쪽 ✕
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      const SizedBox(width: 40),
                      Expanded(
                        child: Column(
                          children: [
                            Text('몇 시간 몇 분 후 정지할까요?',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: textColor, fontSize: 16, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 3),
                            Text('끝나기 1분 전부터 천천히 작아져요',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: textColor.withOpacity(0.5), fontSize: 12)),
                          ],
                        ),
                      ),
                      ParanCloseX(onTap: () => Navigator.pop(ctx)),
                    ],
                  ),
                ),
                SizedBox(
                  height: 216,
                  child: CupertinoTheme(
                    data: CupertinoThemeData(
                      brightness: isDarkMode ? Brightness.dark : Brightness.light,
                      textTheme: CupertinoTextThemeData(
                        pickerTextStyle: TextStyle(color: textColor, fontSize: 20),
                      ),
                    ),
                    child: CupertinoTimerPicker(
                      mode: CupertinoTimerPickerMode.hm,
                      initialTimerDuration: picked,
                      onTimerDurationChanged: (d) => picked = d,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        final totalMinutes = picked.inMinutes;
                        Navigator.pop(ctx);
                        if (totalMinutes > 0) {
                          _setSleepTimer(totalMinutes);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        // 큰 버튼: 먹색 (다크는 크림색)
                        backgroundColor: isDarkMode ? const Color(0xFFF3EFE7) : const Color(0xFF17140F),
                        foregroundColor: isDarkMode ? const Color(0xFF24221F) : const Color(0xFFF4EFE5),
                        elevation: 6,
                        shadowColor: Colors.black.withOpacity(0.25),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text('설정', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                ),
                if (_sleepMinutes != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _setSleepTimer(null);
                      },
                      child: Text('타이머 끄기', style: TextStyle(color: textColor.withOpacity(0.5))),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _togglePlay(bool isPlaying, String currentName, String? currentAssetPath) async {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    final pp = context.read<PlayerProvider>();
    final isThisOne = pp.natureSoundName == currentName;
    if (isThisOne && isPlaying) {
      await pp.pauseNatureSound();
    } else if (isThisOne && !isPlaying) {
      await pp.resumeNatureSound();
    } else if (currentAssetPath != null) {
      await pp.playNatureSound(currentAssetPath, currentName);
    }
  }

  static const _allSounds = [
    {
      'name': '파도소리',
      'icon': Icons.waves,
      'color': Color(0xFF4A7BA6),
      'description': '규칙적인 파도 소리는 마음을 차분히 가라앉혀 깊은 휴식과 수면에 도움을 줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_sound.mp3',
      'image': 'assets/nature_wave_bg.png',
    },
    {
      'name': '잔잔한 파도',
      'icon': Icons.waves,
      'color': Color(0xFF5B8FB0),
      'description': '한결 부드럽고 잔잔하게 밀려오는 파도 소리로 편안한 휴식을 도와줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_calm_sound.mp3',
      'image': null,
    },
    {
      'name': '갈매기와 파도',
      'icon': Icons.waves,
      'color': Color(0xFF3D6E8C),
      'description': '갈매기 울음소리가 어우러진 파도 소리로 생생한 해변 분위기를 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_seagull_sound.mp3',
      'image': null,
    },
    {
      'name': '바위에 부딪히는 파도',
      'icon': Icons.waves,
      'color': Color(0xFF2A4D66),
      'description': '바위에 세게 부딪히며 부서지는 파도 소리로 역동적인 바다를 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_rocks_sound.mp3',
      'image': null,
    },
    {
      'name': '멀리서 들리는 갈매기',
      'icon': Icons.waves,
      'color': Color(0xFF6E97AD),
      'description': '고요한 바닷가, 멀리서 은은하게 들려오는 갈매기 소리로 차분한 휴식을 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_distant_seagull_sound.mp3',
      'image': null,
    },
    {
      'name': '거친 파도',
      'icon': Icons.waves,
      'color': Color(0xFF345F80),
      'description': '거칠게 밀려와 부서지는 파도 소리로 힘 있는 바다를 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/wave_rough_sound.mp3',
      'image': null,
    },
    {
      'name': '빗소리',
      'icon': Icons.water_drop_outlined,
      'color': Color(0xFF3E5A78),
      'description': '일정한 빗소리는 집중력을 높이고 불안한 마음을 편안하게 다독여줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/rain_sound.mp3',
      'image': 'assets/nature_rain_bg.png',
    },
    {
      'name': '창문에 떨어지는 비',
      'icon': Icons.water_drop_outlined,
      'color': Color(0xFF3E5A78),
      'description': '창문을 두드리는 부드러운 빗소리로 편안하게 잠들어보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/rain_window_sound.mp3',
      'image': 'assets/nature_rain_bg.png',
    },
    {
      'name': '숲속의 비와 새소리',
      'icon': Icons.water_drop_outlined,
      'color': Color(0xFF3E5A78),
      'description': '숲속에 내리는 빗소리와 새소리가 어우러져 마음을 편안하게 해줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/rain_forest_sound.mp3',
      'image': 'assets/rain3.png',
    },
    {
      'name': '숲속의 거센 밤비',
      'icon': Icons.water_drop_outlined,
      'color': Color(0xFF3E5A78),
      'description': '깊은 밤 숲속에 세차게 내리는 빗소리로 몰입감 있는 휴식을 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/rain_night_forest_sound.mp3',
      'image': 'assets/rain4.png',
    },
    {
      'name': '새소리',
      'icon': Icons.forest_outlined,
      'color': Color(0xFF5C7A5E),
      'description': '청아한 새소리는 스트레스를 줄이고 상쾌한 기분을 만들어줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/bird_sound.mp3',
      'image': 'assets/nature_bird_bg.png',
    },
    {
      'name': '뻐꾸기와 숲속 새소리',
      'icon': Icons.forest_outlined,
      'color': Color(0xFF5C7A5E),
      'description': '뻐꾸기 소리가 어우러진 숲속의 새소리로 상쾌한 아침을 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/bird_forest_cuckoo_sound.mp3',
      'image': 'assets/bird2.png',
    },
    {
      'name': '모닥불',
      'icon': Icons.local_fire_department_outlined,
      'color': Color(0xFFC97B4A),
      'description': '타닥타닥 장작 타는 소리는 아늑하고 포근한 분위기를 만들어줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/campfire_sound.mp3',
      'image': 'assets/nature_fire_bg.png',
    },
    {
      'name': '시냇물',
      'icon': Icons.water_outlined,
      'color': Color(0xFF2C6BB3),
      'description': '졸졸 흐르는 시냇물 소리는 마음을 편안하게 이완시켜줘요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/stream_sound.mp3',
      'image': 'assets/nature_stream_bg.png',
    },
    {
      'name': '잔잔한 강물',
      'icon': Icons.water_outlined,
      'color': Color(0xFF2C6BB3),
      'description': '넓은 강물이 잔잔하게 흐르는 소리로 편안한 휴식을 느껴보세요',
      'assetPath': 'https://files.ssing.kr/nature-sounds/stream_river_sound.mp3',
      'image': 'assets/stream2.png',
    },
  ];

  // 파도소리 종류는 이미지를 순서대로 하나씩 받아요.
  // (이미지보다 소리가 많아지면 처음 이미지부터 다시 돌려 써요)
  static const _waveImages = [
    'assets/nature_wave_bg.png',
    'assets/wave2.png',
    'assets/wave3.png',
    'assets/wave4.png',
    'assets/wave5.png',
    'assets/wave6.png',
  ];

  bool _isWave(Map<String, Object?> s) =>
      ((s['assetPath'] as String?) ?? '').contains('/wave_');

  String? _resolveImage(Map<String, Object?> data, String name) {
    if (!_isWave(data)) return data['image'] as String?;
    final waves = _allSounds.where((s) => _isWave(s)).toList();
    final idx = waves.indexWhere((s) => s['name'] == name);
    return _waveImages[(idx < 0 ? 0 : idx) % _waveImages.length];
  }

  void _goToAdjacentSound(BuildContext context, int direction) {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    context.read<PlayerProvider>().playAdjacentNatureSound(direction);
  }

  void _showExitConfirmDialog(BuildContext context) async {
    // 새 종료창 (사진 + 큰 질문) — 홈·음악·라디오·자연소리 공통
    if (await showExitConfirm(context) && context.mounted) _showFarewellAndExit(context);
  }

  // (예전 종료창 — 코드 정리할 때 지우기)
  void _oldExitConfirmDialog(BuildContext context) {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                '파란소리를 종료하시겠어요?',
                style: TextStyle(color: Colors.black87, fontSize: 17, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                '다음에 또 좋은 소리로 만나요.',
                style: TextStyle(color: Colors.black54, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                        Navigator.pop(ctx);
                      },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.black54,
                        side: const BorderSide(color: Colors.black26),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('계속 듣기'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                        Navigator.pop(ctx);
                        _showFarewellAndExit(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('종료', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showFarewellAndExit(BuildContext context) {
    final langCode = Localizations.localeOf(context).languageCode;
    late final String farewellAsset;
    switch (langCode) {
      case 'ko':
        farewellAsset = 'assets/farewell_ko_v4.mp3';
        break;
      case 'ja':
        farewellAsset = 'assets/farewell_ja.mp3';
        break;
      case 'zh':
        farewellAsset = 'assets/farewell_zh.mp3';
        break;
      default:
        farewellAsset = 'assets/farewell_en.mp3';
    }
    if (langCode == 'ko' && context.read<ThemeProvider>().voiceGreetingEnabled) { // 목소리는 한국어만
      final farewellPlayer = AudioPlayer();
      farewellPlayer.setAsset(farewellAsset).then((_) => farewellPlayer.play());
    }

    context.read<PlayerProvider>().player.setVolume(0.12);
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOut,
        builder: (_, value, child) => Opacity(
          opacity: value,
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.05, end: 0.85),
            duration: const Duration(milliseconds: 7000), // 끝인사: 서서히 어둡게
            curve: Curves.easeIn,
            builder: (_, darkValue, __) => Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: farewellImage(context),
                  onError: (_, __) {},
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                    Colors.black.withOpacity(darkValue),
                    BlendMode.darken,
                  ),
                ),
              ),
              alignment: Alignment.center,
              child: const FarewellTitle(), // Paransori + 소리 막대 + 한 줄 인사
            ),
          ),
        ),
      ),
    );
    overlay.insert(entry);

    Future.delayed(const Duration(milliseconds: 6500), () async {
      late OverlayEntry fadeOutEntry;
      fadeOutEntry = OverlayEntry(
        builder: (_) => TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: const Duration(milliseconds: 900),
          builder: (_, value, child) => Opacity(
            opacity: value,
            child: Container(
              color: Colors.black,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        ),
      );
      overlay.insert(fadeOutEntry);

      try {
        await context.read<PlayerProvider>().stopNatureSound();
      } catch (_) {}

      await Future.delayed(const Duration(milliseconds: 900));
      entry.remove();
      const MethodChannel('kr.ssing.catsong/media').invokeMethod('closeApp');
    });
  }

  void _goToSoundMix(BuildContext context) {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const SoundMixScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    // context.watch 대신 select를 써서, "재생 중인 곡 이름"과 "재생 여부"
    // 이 두 값이 실제로 바뀔 때만 이 화면이 다시 그려지게 한다.
    // (watch를 쓰면 재생 위치 업데이트 같은 사소한 변화에도 화면 전체가
    // 다시 그려져서 아이콘/시스템바가 깜빡이는 원인이 된다.)
    final watchedNatureSoundName = context.select<PlayerProvider, String?>((p) => p.natureSoundName);
    final watchedIsPlaying = context.select<PlayerProvider, bool>((p) => p.isPlaying);
    final currentName = watchedNatureSoundName ?? widget.name;
    final currentData = _allSounds.firstWhere(
          (s) => s['name'] == currentName,
      orElse: () => {
        'name': widget.name,
        'icon': widget.icon,
        'color': widget.color,
        'description': widget.description,
        'assetPath': widget.assetPath ?? '',
      },
    );
    final currentIcon = currentData['icon'] as IconData;
    final currentColor = currentData['color'] as Color;
    final currentDescription = currentData['description'] as String;
    final currentAssetPath = currentData['assetPath'] as String?;
    final currentImage = _resolveImage(currentData, currentName);
    final isThisOne = watchedNatureSoundName == currentName;
    final isPlaying = isThisOne && watchedIsPlaying;
    final isFavorite = _favoriteNames.contains(currentName);

    return Scaffold(
      backgroundColor: currentColor,
      body: Stack(
        children: [
          if (currentImage != null)
            Positioned.fill(
              child: paranPhoto(
                currentImage,
                fit: BoxFit.cover,
                fallback: Container(color: currentColor),
              ),
            ),
          if (currentImage != null)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.7),
                      Colors.black.withOpacity(0.15),
                      Colors.black.withOpacity(0.15),
                      Colors.black.withOpacity(0.75),
                    ],
                    stops: const [0.0, 0.2, 0.72, 1.0],
                  ),
                ),
              ),
            ),
          GestureDetector(
            onHorizontalDragEnd: (details) {
              final velocity = details.primaryVelocity ?? 0;
              if (velocity < -200) {
                _goToAdjacentSound(context, 1);
              } else if (velocity > 200) {
                _goToAdjacentSound(context, -1);
              }
            },
            child: SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            if (widget.openedFromList) {
                              Navigator.pop(context);
                            } else {
                              Navigator.of(context).pushReplacement(
                                PageRouteBuilder(
                                  pageBuilder: (context, animation, secondaryAnimation) =>
                                      const NatureSoundsScreen(),
                                  transitionsBuilder: (context, animation, secondaryAnimation, child) =>
                                      FadeTransition(opacity: animation, child: child),
                                  transitionDuration: const Duration(milliseconds: 250),
                                ),
                              );
                            }
                          },
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.38),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 13),
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                            Navigator.of(context).popUntil((route) => route.isFirst);
                          },
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.38), shape: BoxShape.circle),
                            child: const Icon(Icons.home_rounded, color: Colors.white, size: 13),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _toggleFavorite(currentName),
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.38), shape: BoxShape.circle),
                            child: HeartPop(
                              on: isFavorite,
                              child: Icon(isFavorite ? CupertinoIcons.heart_fill : CupertinoIcons.heart,
                                  color: isFavorite ? const Color(0xFFE05A4F) : Colors.white, size: 13),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                            context.read<ThemeProvider>().setDarkMode(!isDarkMode);
                          },
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.38), shape: BoxShape.circle),
                            child: Icon(isDarkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
                                color: Colors.white, size: 13),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                            showMoreMenuSheet(
                              context,
                              shareText: '파란소리 자연소리로 편안한 시간 보내요 🌊',
                            );
                            return;
                            showModalBottomSheet(
                              context: context,
                              backgroundColor: Colors.transparent,
                              barrierColor: Colors.black.withOpacity(0.45),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
                              builder: (ctx) {
                                final sheetBg = isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFFAFCFE);
                                final cardBg = isDarkMode
                                    ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                                    colors: [Color(0xFF22303F), Color(0xFF1A2632)])
                                    : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                                    colors: [Colors.white, Color(0xFFEAF3FC)]);
                                final cardBorder = isDarkMode ? Colors.white12 : const Color(0xFFE1EDF7);
                                const navy = Color(0xFF15304D);
                                final subColor = isDarkMode ? Colors.white60 : const Color(0xFF7891A8);

                                Widget menuCard({
                                  required IconData icon,
                                  required String title,
                                  required String subtitle,
                                  required VoidCallback onTap,
                                }) {
                                  return Expanded(
                                    child: GestureDetector(
                                      onTap: onTap,
                                      child: Container(
                                        padding: const EdgeInsets.all(16),
                                        decoration: BoxDecoration(
                                          gradient: cardBg,
                                          border: Border.all(color: cardBorder),
                                          borderRadius: BorderRadius.circular(18),
                                          boxShadow: [
                                            BoxShadow(
                                              color: isDarkMode
                                                  ? Colors.black.withOpacity(0.35)
                                                  : const Color(0xFF2C6BB3).withOpacity(0.08),
                                              blurRadius: 16,
                                              offset: const Offset(0, 6),
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              width: 44,
                                              height: 44,
                                              decoration: BoxDecoration(
                                                gradient: const LinearGradient(
                                                  begin: Alignment.topLeft,
                                                  end: Alignment.bottomRight,
                                                  colors: [Color(0xFF4A90D9), Color(0xFF2C6BB3)],
                                                ),
                                                borderRadius: BorderRadius.circular(14),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: const Color(0xFF2C6BB3).withOpacity(0.35),
                                                    blurRadius: 10,
                                                    offset: const Offset(0, 4),
                                                  ),
                                                ],
                                              ),
                                              child: Icon(icon, color: Colors.white, size: 21),
                                            ),
                                            const SizedBox(height: 14),
                                            Text(title,
                                                style: TextStyle(
                                                    color: isDarkMode ? Colors.white : navy,
                                                    fontSize: 14.5,
                                                    fontWeight: FontWeight.w700)),
                                            const SizedBox(height: 4),
                                            Text(subtitle,
                                                maxLines: 2,
                                                style: TextStyle(color: subColor, fontSize: 11, height: 1.4)),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                }

                                return SafeArea(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: sheetBg,
                                      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                                    ),
                                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: 40,
                                          height: 4,
                                          margin: const EdgeInsets.only(bottom: 18),
                                          decoration: BoxDecoration(
                                            color: isDarkMode ? Colors.white24 : const Color(0xFFCBD9EC),
                                            borderRadius: BorderRadius.circular(2),
                                          ),
                                        ),
                                        IntrinsicHeight(
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              menuCard(
                                                icon: Icons.share_outlined,
                                                title: '친구에게 공유하기',
                                                subtitle: '파란소리를 친구에게\n소개해보세요.',
                                                onTap: () {
                                                  Navigator.pop(ctx);
                                                  Share.share('파란소리 자연소리로 편안한 시간 보내요 🌊\nhttps://play.google.com/store/apps/details?id=kr.ssing.catsong');
                                                },
                                              ),
                                              const SizedBox(width: 12),
                                              menuCard(
                                                icon: Icons.star_border_rounded,
                                                title: '앱 평가하기',
                                                subtitle: '좋은 평가가\n큰 힘이 됩니다.',
                                                onTap: () async {
                                                  Navigator.pop(ctx);
                                                  final uri = Uri.parse('https://play.google.com/store/apps/details?id=kr.ssing.catsong');
                                                  if (await canLaunchUrl(uri)) {
                                                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                                                  }
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(height: 12),
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.pop(ctx);
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(builder: (_) => const SettingsScreen()),
                                            );
                                          },
                                          child: Container(
                                            width: double.infinity,
                                            padding: const EdgeInsets.all(16),
                                            decoration: BoxDecoration(
                                              gradient: cardBg,
                                              border: Border.all(color: cardBorder),
                                              borderRadius: BorderRadius.circular(18),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: isDarkMode
                                                      ? Colors.black.withOpacity(0.35)
                                                      : const Color(0xFF2C6BB3).withOpacity(0.08),
                                                  blurRadius: 16,
                                                  offset: const Offset(0, 6),
                                                ),
                                              ],
                                            ),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 44,
                                                  height: 44,
                                                  decoration: BoxDecoration(
                                                    gradient: const LinearGradient(
                                                      begin: Alignment.topLeft,
                                                      end: Alignment.bottomRight,
                                                      colors: [Color(0xFF4A90D9), Color(0xFF2C6BB3)],
                                                    ),
                                                    borderRadius: BorderRadius.circular(14),
                                                  ),
                                                  child: const Icon(Icons.settings_outlined, color: Colors.white, size: 21),
                                                ),
                                                const SizedBox(width: 14),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Text('설정',
                                                          style: TextStyle(
                                                              color: isDarkMode ? Colors.white : navy,
                                                              fontSize: 14.5,
                                                              fontWeight: FontWeight.w700)),
                                                      const SizedBox(height: 2),
                                                      Text('앱 환경을 설정할 수 있어요.',
                                                          style: TextStyle(color: subColor, fontSize: 11.5)),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.38), shape: BoxShape.circle),
                            child: const Icon(Icons.more_vert, color: Colors.white, size: 13),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _showExitConfirmDialog(context),
                          child: Container(
                            width: 29,
                            height: 29,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.38), shape: BoxShape.circle),
                            child: const Icon(Icons.power_settings_new_rounded, color: Colors.white, size: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 180,
                            height: 180,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.08),
                              border: Border.all(color: Colors.white.withOpacity(0.18)),
                            ),
                            child: Icon(currentIcon, size: 70, color: Colors.white),
                          ),
                          const SizedBox(height: 28),
                          Text(currentName,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  shadows: [
                                    Shadow(color: Colors.black45, blurRadius: 3, offset: Offset(0, 1)),
                                    Shadow(color: Colors.black38, blurRadius: 12, offset: Offset(0, 2)),
                                  ])),
                          const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(currentDescription,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    height: 1.6,
                                    shadows: [
                                      Shadow(color: Colors.black45, blurRadius: 3, offset: Offset(0, 1)),
                                      Shadow(color: Colors.black38, blurRadius: 10, offset: Offset(0, 2)),
                                    ])),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                    padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.35),
                      border: Border.all(color: Colors.white.withOpacity(0.16)),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          behavior: HitTestBehavior.opaque, // 아이콘 주변 빈 곳도 눌리게
                          onTap: () => _showCustomMinutesDialog(isDarkMode),
                          child: Container(
                            width: 56,
                            height: 52,
                            alignment: Alignment.center,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.bedtime,
                                    color: _sleepMinutes != null
                                        ? Colors.white
                                        : Colors.white.withOpacity(0.7),
                                    size: 22),
                                const SizedBox(height: 4),
                                Text(_formatRemaining(),
                                    maxLines: 1,
                                    style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10)),
                              ],
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _goToAdjacentSound(context, -1),
                          child: Icon(Icons.skip_previous_rounded,
                              color: Colors.white.withOpacity(0.85), size: 30),
                        ),
                        GestureDetector(
                          onTap: () => _togglePlay(isPlaying, currentName, currentAssetPath),
                          child: Container(
                            width: 62,
                            height: 62,
                            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                            child: Icon(isPlaying ? Icons.pause : Icons.play_arrow,
                                color: currentColor, size: 28),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _goToAdjacentSound(context, 1),
                          child: Icon(Icons.skip_next_rounded,
                              color: Colors.white.withOpacity(0.85), size: 30),
                        ),
                        GestureDetector(
                          behavior: HitTestBehavior.opaque, // 아이콘 주변 빈 곳도 눌리게
                          onTap: () => _goToSoundMix(context),
                          child: Container(
                            width: 56,
                            height: 52,
                            alignment: Alignment.center,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.graphic_eq_rounded, color: Colors.white.withOpacity(0.7), size: 22),
                                const SizedBox(height: 4),
                                Text('믹스', style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}