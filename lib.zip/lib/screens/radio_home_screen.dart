import 'dart:math' as math;
import 'dart:ui' show PlatformDispatcher, ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/radio_country.dart';
import '../providers/radio_provider.dart';
import '../providers/theme_provider.dart';
import 'nature_sounds_screen.dart';
import '../theme/app_theme.dart';
import '../widgets/radio_mini_player.dart';
import 'radio_broadcaster_screen.dart';
import 'radio_search_screen.dart';
import 'radio_favorites_screen.dart';
import 'radio_korea_screen2.dart';
import 'radio_country_stations_screen.dart';
import '../l10n/app_localizations.dart';


/// 라디오 진입 시 호출. 내 폰의 국가 설정에 맞는 방송국 목록이 있으면
/// 국가 선택 화면을 건너뛰고 바로 그 나라로 들어가고, 없으면 국가 선택 화면으로 간다.
Future<void> pushRadioEntry(BuildContext context, {bool instant = false}) {
  const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
  final deviceCode = PlatformDispatcher.instance.locale.countryCode;
  RadioCountry? matched;
  if (deviceCode != null) {
    for (final c in RadioCountry.supported) {
      if (c.code == deviceCode) {
        matched = c;
        break;
      }
    }
  }

  Widget screen;
  if (matched != null) {
    context.read<RadioProvider>().selectCountry(matched);
    screen = matched.code == 'KR'
        ? const RadioKoreaScreen()
        : RadioCountryStationsScreen(country: matched);
  } else {
    screen = const RadioHomeScreen();
  }

  return Navigator.push(
    context,
    PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => MediaQuery(
        data: MediaQuery.of(context).copyWith(
          textScaler: const TextScaler.linear(1.25),
        ),
        child: screen,
      ),
      transitionsBuilder: instant
          ? (context, animation, secondaryAnimation, child) => child
          : (context, animation, secondaryAnimation, child) =>
              FadeTransition(opacity: animation, child: child),
      transitionDuration: instant ? Duration.zero : const Duration(milliseconds: 250),
      reverseTransitionDuration: instant ? Duration.zero : const Duration(milliseconds: 250),
    ),
  );
}

class RadioHomeScreen extends StatelessWidget {
  const RadioHomeScreen({super.key});

  List<RadioCountry> get _sortedCountries {
    final deviceCountryCode = PlatformDispatcher.instance.locale.countryCode;
    final list = List<RadioCountry>.from(RadioCountry.supported);
    if (deviceCountryCode != null) {
      final myIndex = list.indexWhere((c) => c.code == deviceCountryCode);
      if (myIndex > 0) {
        final myCountry = list.removeAt(myIndex);
        list.insert(0, myCountry);
      }
    }
    return list;
  }

  List<Widget> _buildCountryListByContinent(BuildContext context, List<RadioCountry> countries, bool isDarkMode) {
    final deviceCountryCode = PlatformDispatcher.instance.locale.countryCode;
    const continentOrder = ['ASIA', 'EUROPE', 'NORTH_AMERICA', 'SOUTH_AMERICA', 'MIDDLE_EAST', 'AFRICA', 'OCEANIA'];
    const continentLabels = {
      'ASIA': 'Asia',
      'EUROPE': 'Europe',
      'NORTH_AMERICA': 'North America',
      'SOUTH_AMERICA': 'South America',
      'MIDDLE_EAST': 'Middle East',
      'AFRICA': 'Africa',
      'OCEANIA': 'Oceania',
    };

    // 유저 대륙을 맨 위로
    String? userContinent;
    if (deviceCountryCode != null) {
      final userCountry = countries.firstWhere(
            (c) => c.code == deviceCountryCode,
        orElse: () => countries.first,
      );
      userContinent = userCountry.continent;
    }

    final sorted = List<String>.from(continentOrder);
    if (userContinent != null && sorted.contains(userContinent)) {
      sorted.remove(userContinent);
      sorted.insert(0, userContinent);
    }

    final widgets = <Widget>[];
    for (final continent in sorted) {
      final group = countries.where((c) => c.continent == continent).toList();
      if (group.isEmpty) continue;

      // 유저 나라를 해당 대륙 맨 위로
      if (deviceCountryCode != null) {
        final idx = group.indexWhere((c) => c.code == deviceCountryCode);
        if (idx > 0) {
          final my = group.removeAt(idx);
          group.insert(0, my);
        }
      }

      // 대륙 헤더
      widgets.add(
        Padding(
          padding: const EdgeInsets.only(top: 24, bottom: 8),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: (isDarkMode ? Colors.white : Colors.black).withOpacity(0.08),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  continentLabels[continent] ?? continent,
                  style: TextStyle(
                    color: (isDarkMode ? Colors.white : Colors.black).withOpacity(0.5),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 0.5,
                  color: (isDarkMode ? Colors.white : Colors.black).withOpacity(0.1),
                ),
              ),
            ],
          ),
        ),
      );

      // 나라 목록
      for (int i = 0; i < group.length; i++) {
        final country = group[i];
        widgets.add(
          Column(
            children: [
              _CountryListTile(
                country: country,
                onTap: () => _onCountryTap(context, country),
              ),
              if (i != group.length - 1)
                Divider(height: 1, color: (isDarkMode ? Colors.white : Colors.black).withOpacity(0.16), indent: 48),
            ],
          ),
        );
      }
    }
    return widgets;
  }

  void _onCountryTap(BuildContext context, RadioCountry country) {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    context.read<RadioProvider>().selectCountry(country);
    final screen = country.code == 'KR'
        ? RadioKoreaScreen()
        : RadioCountryStationsScreen(country: country);
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => screen,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 250),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final radioProvider = context.watch<RadioProvider>();
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final countries = _sortedCountries;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      radioProvider.fetchAllCountryCounts();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      SystemChrome.setSystemUIOverlayStyle(
        isDarkMode
            ? const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
          systemNavigationBarColor: Color(0xFF17140F),
          systemNavigationBarIconBrightness: Brightness.light,
        )
            : const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
          statusBarBrightness: Brightness.light,
          systemNavigationBarColor: Color(0xFFF7F5F0),
          systemNavigationBarIconBrightness: Brightness.dark,
        ),
      );
    });

    return Scaffold(
      backgroundColor: isDarkMode ? const Color(0xFF17140F) : const Color(0xFFEDE7DA),
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: isDarkMode
            ? const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
        )
            : const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
          statusBarBrightness: Brightness.light,
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios, color: isDarkMode ? Colors.white : Colors.black, size: 20),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Radio',
              style: GoogleFonts.doHyeon(
                color: isDarkMode ? Colors.white : Colors.black,
                fontSize: 22,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(width: 6),
            const Padding(
              padding: EdgeInsets.only(bottom: 3),
              child: _LogoEqBars(),
            ),
          ],
        ),
        actions: [
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          children: [

            Text(
              AppLocalizations.of(context)!.radioSelectCountry,
              style: TextStyle(
                color: (isDarkMode ? Colors.white : Colors.black).withOpacity(0.65),
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 4),
            ..._buildCountryListByContinent(context, countries, isDarkMode),
            const SizedBox(height: 80),
          ],
        ),
      ),
      bottomNavigationBar: radioProvider.currentStation != null
          ? const SafeArea(top: false, child: RadioMiniPlayer())
          : null,
    );
  }
}

class _CountryListTile extends StatelessWidget {
  final RadioCountry country;
  final VoidCallback onTap;
  const _CountryListTile({required this.country, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final baseColor = isDarkMode ? Colors.white : Colors.black;
    return InkWell(
      onTap: onTap,
      splashColor: baseColor.withOpacity(0.04),
      highlightColor: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Row(
          children: [
            Text(country.flag, style: const TextStyle(fontSize: 30)),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    country.displayName,
                    style: TextStyle(
                      color: baseColor,
                      fontSize: 16.5,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.2,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Builder(builder: (ctx) {
                    if (country.code == 'KR') {
                      return Text(
                        '${koreanStations.length}${AppLocalizations.of(context)!.radioChannelCount}',
                        style: TextStyle(color: baseColor.withOpacity(0.4), fontSize: 12.5),
                      );
                    }
                    final count = ctx.watch<RadioProvider>().getCountryStationCount(country.code);
                    return Text(
                      count != null
                          ? '$count${AppLocalizations.of(context)!.radioChannelCount}'
                          : AppLocalizations.of(context)!.radioPopular200,
                      style: TextStyle(color: baseColor.withOpacity(0.4), fontSize: 12.5),
                    );
                  }),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: baseColor.withOpacity(0.25), size: 20),
          ],
        ),
      ),
    );
  }
}

class _RecentSection extends StatelessWidget {
  const _RecentSection();

  @override
  Widget build(BuildContext context) {
    final radioProvider = context.watch<RadioProvider>();
    final recent = radioProvider.recentlyListened;
    final primaryColor = Theme.of(context).colorScheme.primary;
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final baseColor = isDarkMode ? Colors.white : Colors.black;

    if (recent.isEmpty) return const SizedBox.shrink();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final station in recent.take(10)) {
        if (radioProvider.nowPlayingFor(station.name) == null &&
            !radioProvider.hasAttemptedSchedule(station.name)) {
          radioProvider.markScheduleAttempted(station.name);
          final streamUrl = station.streamUrl;
          if (streamUrl.contains('cfpwwwapi.kbs.co.kr')) {
            radioProvider.fetchScheduleByUrl(station.name, streamUrl);
          } else if (station.name == 'MBC 표준FM' || station.name == 'MBC FM4U') {
            radioProvider.fetchMbcSchedule(station.name);
          } else if (station.name == 'SBS 파워FM' || station.name == 'SBS 러브FM') {
            radioProvider.fetchSbsSchedule(station.name);
          } else if (station.name.contains('KBS')) {
            radioProvider.fetchSchedule(station.name);
          }
        }
      }
    });

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppLocalizations.of(context)!.radioRecentListening,
          style: TextStyle(
            color: baseColor.withOpacity(0.65),
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 116,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            clipBehavior: Clip.none,
            itemCount: recent.length > 10 ? 10 : recent.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, index) {
              final station = recent[index];
              final time = station.lastListened;
              final timeStr = time != null
                  ? '${time.month}/${time.day}, ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}'
                  : '';

              return GestureDetector(
                onTap: () {
                  const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                  context.read<RadioProvider>().playStation(station);
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                    child: Container(
                      width: 200,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: baseColor.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: baseColor.withOpacity(0.10)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.radio, color: baseColor.withOpacity(0.6), size: 13),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  station.name,
                                  style: TextStyle(color: baseColor, fontSize: 13, fontWeight: FontWeight.w600),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          Builder(builder: (ctx) {
                            final nowPlaying = radioProvider.nowPlayingFor(station.name);
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (nowPlaying != null && nowPlaying.isNotEmpty)
                                  Text(
                                    nowPlaying,
                                    style: TextStyle(color: baseColor.withOpacity(0.55), fontSize: 10.5),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                if (timeStr.isNotEmpty)
                                  Text(
                                    timeStr,
                                    style: TextStyle(color: baseColor.withOpacity(0.35), fontSize: 10.5),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

// 상단바에 쓰는 작은 이퀄라이저 막대 (은은하게 움직임)
class _LogoEqBars extends StatefulWidget {
  const _LogoEqBars();

  @override
  State<_LogoEqBars> createState() => _LogoEqBarsState();
}

class _LogoEqBarsState extends State<_LogoEqBars>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 14,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: List.generate(3, (i) {
              final t = _c.value * 2 * math.pi + i * 1.3;
              final v = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(t));
              return Padding(
                padding: EdgeInsets.only(left: i == 0 ? 0 : 2),
                child: Container(
                  width: 3,
                  height: 14 * v,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2F7DE8),
                    borderRadius: BorderRadius.circular(1.5),
                  ),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}