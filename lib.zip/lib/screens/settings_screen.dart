import 'equalizer_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:torch_light/torch_light.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../providers/theme_provider.dart';
import '../theme/app_theme.dart';
import 'ringtone_screen.dart';
import '../l10n/app_localizations.dart';
import '../widgets/paran_toast.dart';
import '../widgets/paran_dialog.dart';
import '../widgets/action_feedback.dart';
import 'bulk_clean_screen.dart';
import 'bulk_art_screen.dart';
import 'player_screen.dart' show showPlayerStyleMenu;
import '../utils/home_card_pref.dart';
import '../utils/point_color.dart';
import '../utils/font_downloader.dart';
import 'settings_help_screen.dart';
import 'policy_web_screen.dart';
import '../services/loudness.dart';
import '../services/headset_resume.dart';
import '../l10n/locale_holder.dart';

// 화면 공통 색 (베이지 바탕 · 흰 카드 · 먹색 글자)
Color _sBg(bool d) => d ? const Color(0xFF24221F) : const Color(0xFFF4EFE5);
Color _sCard(bool d) => d ? const Color(0xFF32302C) : const Color(0xFFFFFFFF);
Color _sText(bool d) => d ? const Color(0xFFF3EFE7) : const Color(0xFF17140F);
Color _sTextSub(bool d) => d ? const Color(0xFFCFC8BB) : const Color(0xFF5A5348);
Color _sTextHint(bool d) => d ? const Color(0xFFB8B0A2) : const Color(0xFF8A8378);
Color _sBorder(bool d) => d ? const Color(0xFF4A4640) : const Color(0xFFEEE9DF);
Color _sIconBg(bool d) => d ? Colors.white.withOpacity(0.08) : const Color(0xFFF4EFE5);
/// 메뉴와 같은 아이콘 베이지 칸
Widget _iconBox(IconData icon, bool d) => Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(color: _sIconBg(d), borderRadius: BorderRadius.circular(9)),
      child: Icon(icon, size: 17, color: _sTextSub(d)),
    );
Color _sInputBg(bool d) => d ? Colors.white.withOpacity(0.06) : const Color(0xFFEEEAE0);

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isFlashlightOn = false;
  bool _isSosOn = false;

  // 돋보기: 설정 글자만 크게 (기본 → 크게 → 아주 크게) — 설정 도움말과 같은 크기를 같이 기억
  static const _zoomLevels = [1.0, 1.2, 1.4];
  static List<String> get _zoomNames => [tr.zoomDefault, tr.zoomLarge, tr.zoomXLarge];
  double _zoom = 1.0;
  bool _mainReopened = false; // '다시 보기' 누른 뒤 2초 동안 "카드를 다시 켰어요"

  int get _zoomIndex {
    var best = 0;
    for (var i = 0; i < _zoomLevels.length; i++) {
      if ((_zoomLevels[i] - _zoom).abs() < (_zoomLevels[best] - _zoom).abs()) best = i;
    }
    return best;
  }

  void _nextZoom() {
    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    _hideBubble();
    final next = _zoomLevels.firstWhere((l) => l > _zoom + 0.01, orElse: () => _zoomLevels.first);
    setState(() => _zoom = next);
    SharedPreferences.getInstance().then((p) => p.setDouble('helpZoom', next));
  }

  @override
  void initState() {
    super.initState();
    HomeCardPref.load();
    MainCardPref.load();
    SharedPreferences.getInstance().then((p) {
      final z = p.getDouble('helpZoom');
      if (z != null && mounted) setState(() => _zoom = z.clamp(1.0, 1.6));
    });
  }

  @override
  void dispose() {
    _removeBubbleNow();
    _isSosOn = false;
    TorchLight.disableTorch();
    super.dispose();
  }

  Future<String> _getAppVersion() async {
    final info = await PackageInfo.fromPlatform();
    return 'v${info.version}';
  }

  String _getFontName(BuildContext context, String key) {
    final l = AppLocalizations.of(context)!;
    final isKo = tr.localeName.startsWith('ko');
    final names = isKo
        ? const {
            'default': '스포카 한 산스',
            'pretendard': '프리텐다드 (기본)',
            'line_seed': '라인 시드',
            'suit': '수트',
            'wanted_sans': '원티드 산스',
            'nanum_gothic': '나눔고딕',
            'ibm_plex': 'IBM 플렉스 산스',
            'nanum_square_round': '나눔스퀘어라운드',
            'gowun_dodum': '고운돋움',
            'maru_buri': '마루 부리',
          }
        : {
            'default': 'Spoqa Han Sans',
            'pretendard': 'Pretendard (${tr.zoomDefault})',
            'line_seed': 'LINE Seed',
            'suit': 'SUIT',
            'wanted_sans': 'Wanted Sans',
            'nanum_gothic': 'Nanum Gothic',
            'ibm_plex': 'IBM Plex Sans',
            'nanum_square_round': 'NanumSquare Round',
            'gowun_dodum': 'Gowun Dodum',
            'maru_buri': 'MaruBuri',
          };
    if (names.containsKey(key)) return names[key]!;
    switch (key) {
      case 'default': return l.fontDefault;
      case 'noto_sans': return l.fontNotoSans;
      case 'jua': return l.fontJua;
      case 'gaegu': return l.fontGaegu;
      case 'nanum_gothic': return l.fontNanumGothic;
      case 'do_hyeon': return l.fontDoHyeon;
      case 'cute_font': return l.fontCuteFont;
      case 'stylish': return l.fontStylish;
      case 'sunflower': return l.fontSunflower;
      case 'hi_melody': return l.fontHiMelody;
      case 'poor_story': return l.fontPoorStory;
      case 'east_sea_dokdo': return l.fontEastSeaDokdo;
      case 'nanum_brush': return l.fontNanumBrush;
      case 'nanum_myeongjo': return l.fontNanumMyeongjo;
      case 'black_and_white': return l.fontBlackAndWhite;
      case 'gowun_dodum': return l.fontGowunDodum;
      case 'gowun_batang': return l.fontGowunBatang;
      case 'nanum_pen': return l.fontNanumPen;
      case 'single_day': return l.fontSingleDay;
      case 'yeon_sung': return l.fontYeonSung;
      default: return key;
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final l = AppLocalizations.of(context)!;
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    return Scaffold(
      backgroundColor: _sBg(isDarkMode),
      appBar: AppBar(
        backgroundColor: _sBg(isDarkMode),
        elevation: 0,
        title: Text(l.settings, style: TextStyle(color: _sText(isDarkMode), fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -0.3)),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios, color: AppTheme.fixedAccent, size: 20),
        ),
        actions: [
          // 돋보기: 기본 → 크게 → 아주 크게 (설정 도움말과 같은 모양)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: _nextZoom,
              style: TextButton.styleFrom(
                foregroundColor: _sText(isDarkMode),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                minimumSize: const Size(48, 40),
              ),
              icon: Icon(_zoomIndex == _zoomLevels.length - 1 ? Icons.zoom_out_rounded : Icons.zoom_in_rounded, size: 22),
              label: Text(_zoomNames[_zoomIndex],
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
        bottom: PreferredSize(preferredSize: Size.fromHeight(1), child: Divider(height: 1, color: _sBorder(isDarkMode))),
      ),
      body: SafeArea(
        top: false,
        child: NotificationListener<ScrollStartNotification>(
        onNotification: (_) {
          _hideBubble();
          return false;
        },
        // 이 화면 글자만 크게 (앱 전체 글자 크기 × 돋보기)
        child: MediaQuery(
        data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(MediaQuery.of(context).textScaler.scale(1) * _zoom)),
        child: ListView(
        padding: const EdgeInsets.only(bottom: 16),
        children: [
          // ── 맨 위: Paransori 카드 + 자주 켜고 끄는 3칸 ──
          _heroCard(isDarkMode),
          Consumer<ThemeProvider>(builder: (context, t, _) => _quickTiles(t)),
          // ── 꾸미기 ──
          _buildSection(tr.secDecorate),
          Consumer<ThemeProvider>(builder: (context, t, _) => _pointColorTile(t)),
          _buildTile(context, icon: Icons.style_outlined, title: l.playerStyle, desc: tr.descPlayerStyle, onTap: () => _showPlayerStyleDialog(context), primaryColor: primaryColor),
          _buildTile(context, icon: Icons.font_download_outlined, title: l.fontChange, desc: tr.descFont, onTap: () => _showFontDialog(context), primaryColor: primaryColor),
          _buildTile(context, icon: Icons.text_fields, title: l.textSize, desc: tr.descTextSize, onTap: () => _showTextSizeDialog(context), primaryColor: primaryColor),
          // 언어: 폰 설정 따라가기 / 한국어 / English … (오른쪽에 지금 언어)
          Consumer<ThemeProvider>(
            builder: (context, t, _) => _buildTile(context,
                icon: Icons.language_rounded,
                title: l.languageTab,
                desc: _langText('desc'),
                subtitle: _langName(t.appLanguage),
                onTap: () => _showLanguageSheet(context),
                primaryColor: primaryColor),
          ),
          // 메인 홈 맨 위 카드 (나만의 색·라디오·팁) — 오늘 다 닫았으면 설명 끝에 '다시 보기 ›'
          ValueListenableBuilder<bool>(
            valueListenable: MainCardPref.on,
            builder: (context, on, _) => ValueListenableBuilder<bool>(
              valueListenable: MainCardPref.allClosedToday,
              builder: (context, allClosed, _) {
                final closed = on && allClosed && !_mainReopened;
                final point = pointColorOf(context);
                const descStyle = TextStyle(fontSize: 11.5);
                Widget? descWidget;
                if (_mainReopened) {
                  // 누른 뒤 2초: 그 자리에서 바로 알려 주기
                  descWidget = Text(tr.cardsReopened,
                      maxLines: 1, style: descStyle.copyWith(color: point, fontWeight: FontWeight.w700));
                } else if (closed) {
                  descWidget = GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _reopenMainCards,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text.rich(
                        TextSpan(children: [
                          TextSpan(text: tr.allClosedToday),
                          TextSpan(text: tr.showAgain, style: TextStyle(color: point, fontWeight: FontWeight.w700)),
                        ]),
                        maxLines: 1,
                        style: descStyle.copyWith(color: _sTextHint(isDarkMode)),
                      ),
                    ),
                  );
                }
                return _buildTile(context,
                    icon: Icons.campaign_outlined,
                    title: tr.mainCardTitle,
                    desc: tr.mainCardDesc,
                    descWidget: descWidget,
                    onTap: () => MainCardPref.setOn(!on),
                    primaryColor: primaryColor,
                    trailing: Switch(value: on, onChanged: (v) => MainCardPref.setOn(v), activeColor: primaryColor, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap));
              },
            ),
          ),
          ValueListenableBuilder<bool>(
            valueListenable: HomeCardPref.on,
            builder: (context, on, _) => _buildTile(context,
                icon: Icons.view_agenda_outlined,
                title: tr.homeCardTitle,
                // ⓘ 누르면 어떤 카드가 나오는지 (포인트 색과 같은 말풍선)
                titleExtra: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _showBubble(_homeInfoKey, context.read<ThemeProvider>().isDarkMode,
                      title: tr.homeCardInfoTitle,
                      items: _homeInfoItems,
                      foot: tr.homeCardInfoFoot),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(6, 4, 8, 4),
                    child: Icon(Icons.info_outline_rounded,
                        key: _homeInfoKey, size: 16, color: _sTextHint(context.read<ThemeProvider>().isDarkMode)),
                  ),
                ),
                desc: tr.homeCardDesc,
                onTap: () => HomeCardPref.setOn(!on),
                primaryColor: primaryColor,
                isLast: true,
                trailing: Switch(value: on, onChanged: (v) => HomeCardPref.setOn(v), activeColor: primaryColor, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap)),
          ),
          // ── 음악 관리 ──
          _buildSection(tr.secMusicManage),
          _buildTile(context, icon: Icons.auto_awesome_outlined, title: tr.moreCleanTitle, desc: tr.descClean,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BulkCleanScreen())),
              primaryColor: primaryColor, isFirst: true),
          _buildTile(context, icon: Icons.photo_library_outlined, title: tr.moreArtTitle, desc: tr.descArt,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BulkArtScreen())),
              primaryColor: primaryColor, isLast: true),
          // ── 도구 ──
          _buildSection(tr.secTools),
          _buildTile(context, icon: Icons.equalizer, title: l.equalizer, desc: tr.descEq, onTap: () => Navigator.push(context, PageRouteBuilder(pageBuilder: (context, animation, secondaryAnimation) => const EqualizerScreen(), transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(opacity: animation, child: child), transitionDuration: const Duration(milliseconds: 250))), primaryColor: primaryColor, isFirst: true),
          // 곡마다 소리 크기 맞추기 (큰 곡만 조금 줄여서 비슷하게)
          ValueListenableBuilder<bool>(
            valueListenable: Loudness.enabled,
            builder: (context, on, _) => _buildTile(context,
                icon: Icons.graphic_eq_rounded,
                title: tr.loudnessTitle,
                desc: tr.loudnessDesc,
                onTap: () => Loudness.setEnabled(!on),
                primaryColor: primaryColor,
                trailing: Switch(value: on, onChanged: (v) => Loudness.setEnabled(v), activeColor: primaryColor, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap)),
          ),
          // 이어폰·블루투스 연결하면 이어서 듣기 (끄기 · 알림으로 묻기 · 바로 재생)
          ValueListenableBuilder<int>(
            valueListenable: HeadsetResume.mode,
            builder: (context, m, _) => _buildTile(context,
                icon: Icons.headphones_outlined,
                title: tr.headsetTitle,
                desc: tr.headsetDesc,
                subtitle: HeadsetResume.names[m],
                onTap: () => _showHeadsetResumeSheet(context),
                primaryColor: primaryColor),
          ),
          _buildTile(context, icon: Icons.music_note_outlined, title: l.ringtone, desc: tr.descRingtone, onTap: () => Navigator.push(context, PageRouteBuilder(pageBuilder: (context, animation, secondaryAnimation) => const RingtoneScreen(), transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(opacity: animation, child: child), transitionDuration: const Duration(milliseconds: 250))), primaryColor: primaryColor),
          _buildTile(context, icon: _isFlashlightOn ? Icons.flashlight_on : Icons.flashlight_off, title: l.flashlight, desc: tr.descFlashlight, onTap: () => _toggleFlashlight(context), primaryColor: primaryColor,
              trailing: Switch(value: _isFlashlightOn, onChanged: (_) => _toggleFlashlight(context), activeColor: primaryColor, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap)),
          _buildTile(context, icon: Icons.emergency, title: l.sos, desc: tr.descSos, onTap: () => _toggleSOS(context), primaryColor: primaryColor,
              trailing: Switch(value: _isSosOn, onChanged: (_) => _toggleSOS(context), activeColor: Colors.redAccent, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap)),
          _buildTile(context, icon: Icons.widgets_outlined, title: l.widget, desc: tr.descWidget, onTap: () async {
            const platform = MethodChannel('kr.ssing.catsong/media');
            try { await platform.invokeMethod('requestWidgetAdd'); } catch (e) {}
          }, primaryColor: primaryColor, isLast: true),
          // ── 기타 ──
          _buildSection(tr.secOther),
          _buildTile(context, icon: Icons.help_outline_rounded, title: tr.moreHelpTitle, desc: tr.descHelp,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsHelpScreen()))
                  .then((_) => SharedPreferences.getInstance().then((p) {
                        final z = p.getDouble('helpZoom');
                        if (z != null && mounted) setState(() => _zoom = z.clamp(1.0, 1.6));
                      })),
              primaryColor: primaryColor, isFirst: true),
          _buildTile(context, icon: Icons.card_giftcard_outlined, title: l.promoCode, onTap: () async {
            await _showPromoCodeDialog(context);
            if (mounted) setState(() {}); // 맨 위 카드 글자도 바로 바뀌게
          }, primaryColor: primaryColor),
          _buildTile(context, icon: Icons.star_outline, title: l.rateApp, onTap: () => _launchUrl('https://play.google.com/store/apps/details?id=kr.ssing.catsong'), primaryColor: primaryColor),
          _buildTile(context, icon: Icons.privacy_tip_outlined, title: l.privacyPolicy, onTap: () => _openPolicy('privacy_policy', l.privacyPolicy), primaryColor: primaryColor),
          _buildTile(context, icon: Icons.description_outlined, title: l.termsOfService, onTap: () => _openPolicy('terms_of_service', l.termsOfService), primaryColor: primaryColor, isLast: true),
          const SizedBox(height: 24),
          Center(child: Text('KNEXM.Co.,LTD', style: TextStyle(color: Colors.grey[400], fontSize: 12))),
          const SizedBox(height: 8),
        ],
      ),
      ),
      ),
      ),
    );
  }

  /// '다시 보기 ›': 오늘 닫은 메인 알림 카드 다시 켜기 → 설명 자리에 2초 동안 "카드를 다시 켰어요"
  void _reopenMainCards() {
    // 효과음: 켜져 있으면 물방울 "똑" (진동 모드면 진동, 무음이면 조용) / 꺼져 있으면 터치 진동
    if (context.read<ThemeProvider>().feedbackSoundEnabled) {
      const MethodChannel('kr.ssing.catsong/media')
          .invokeMethod('feedbackSound', {'low': false})
          .catchError((Object _) => null);
    } else {
      const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    }
    MainCardPref.reopenToday();
    setState(() => _mainReopened = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _mainReopened = false);
    });
  }

  // ───────── B안 부품 ─────────

  /// 버전 + 광고 제거 여부
  Future<(String, bool)> _heroInfo() async {
    final v = await _getAppVersion();
    final p = await SharedPreferences.getInstance();
    return (v, p.getBool('promo_unlocked') ?? false);
  }

  /// 맨 위 먹색 Paransori 카드 (다크 모드는 크림색) — 누르면 프로모션 코드
  Widget _heroCard(bool isDark) {
    final bg = isDark ? const Color(0xFFF3EFE7) : const Color(0xFF17140F);
    final fg = isDark ? const Color(0xFF24221F) : const Color(0xFFF4EFE5);
    return FutureBuilder<(String, bool)>(
      future: _heroInfo(),
      builder: (context, snap) {
        final v = snap.data?.$1 ?? '';
        final noAd = snap.data?.$2 ?? false;
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: Material(
            color: bg,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () async {
                await _showPromoCodeDialog(context);
                if (mounted) setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 16, 12, 16),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text.rich(
                            TextSpan(children: [
                              TextSpan(
                                  text: 'Paran',
                                  style: TextStyle(color: isDark ? const Color(0xFF2589E8) : const Color(0xFF7FB8F0))),
                              const TextSpan(text: 'sori'),
                            ]),
                            style: GoogleFonts.quicksand(
                                color: fg, fontSize: 19, fontWeight: FontWeight.w700, letterSpacing: 0.4),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${noAd ? tr.heroNoAd : tr.heroDefault}${v.isEmpty ? '' : '  ·  $v'}',
                            style: TextStyle(color: fg.withOpacity(0.65), fontSize: 11.5),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.chevron_right_rounded, color: fg.withOpacity(0.5)),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// 자주 켜고 끄는 3칸 (흰 카드, 켜지면 아이콘 칸만 먹색 · ⓘ 누르면 아래 말풍선)
  Widget _quickTiles(ThemeProvider t) {
    final d = t.isDarkMode;
    Widget tile(IconData icon, String label, String info, bool on, VoidCallback onTap) {
      final key = _infoKeys.putIfAbsent(label, () => GlobalKey());
      return Expanded(
        child: GestureDetector(
          onTap: () {
            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
            _hideBubble();
            onTap();
          },
          child: Container(
            padding: const EdgeInsets.fromLTRB(12, 12, 6, 11),
            decoration: BoxDecoration(color: _sCard(d), borderRadius: BorderRadius.circular(16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 켜지면 아이콘 칸만 먹색 (다크 모드는 크림색)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: on ? _sText(d) : _sIconBg(d),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: Icon(icon, size: 16, color: on ? _sBg(d) : _sTextSub(d)),
                    ),
                    const Spacer(),
                    // ⓘ 누르면 카드 아래 작은 말풍선
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => _showBubble(key, d, text: info),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(8, 0, 4, 8),
                        child: Icon(Icons.info_outline_rounded, key: key, size: 16, color: _sTextHint(d)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: _sText(d), fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(on ? tr.inUse : tr.off,
                    style: TextStyle(
                        color: on ? _sText(d) : _sTextHint(d),
                        fontSize: 11,
                        fontWeight: on ? FontWeight.w700 : FontWeight.w400)),
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Row(
        children: [
          tile(Icons.dark_mode_outlined, tr.darkMode, tr.darkModeInfo, t.isDarkMode,
              () => t.setDarkMode(!t.isDarkMode)),
          const SizedBox(width: 8),
          tile(
              Icons.water_drop_outlined,
              tr.soundEffect,
              tr.soundEffectInfo,
              t.feedbackSoundEnabled,
              () => t.setFeedbackSoundEnabled(!t.feedbackSoundEnabled)),
          const SizedBox(width: 8),
          tile(Icons.record_voice_over_outlined, tr.voiceGuide, tr.voiceGuideInfo, t.voiceGreetingEnabled,
              () => t.setVoiceGreetingEnabled(!t.voiceGreetingEnabled)),
        ],
      ),
    );
  }

  // ───────── ⓘ 설명 (넓은 먹색 칸 · ✕로 닫기) ─────────
  final Map<String, GlobalKey> _infoKeys = {};
  OverlayEntry? _bubble;
  GlobalKey? _bubbleFor;
  final GlobalKey<_InfoBubbleState> _bubbleKey = GlobalKey();

  void _removeBubbleNow() {
    _bubble?.remove();
    _bubble = null;
    _bubbleFor = null;
  }

  /// 설명 닫기 (스르르)
  void _hideBubble() {
    final s = _bubbleKey.currentState;
    if (s != null) {
      s.close();
    } else {
      _removeBubbleNow();
    }
  }

  /// ⓘ 누르면 카드 아래에 넓은 설명 (꼬리는 ⓘ를 가리킴)
  /// 저절로 안 사라지고 ✕ · 다른 곳 누르기 · 스크롤로 닫힘 / 같은 ⓘ 다시 누르면 닫힘
  void _showBubble(GlobalKey iconKey, bool d,
      {String? title, String? text, List<(String, String)>? items, String? foot, bool keepOpenOnCard = false}) {
    if (_bubble != null && identical(_bubbleFor, iconKey)) {
      _hideBubble();
      return;
    }
    final box = iconKey.currentContext?.findRenderObject();
    final overlay = Overlay.maybeOf(context);
    if (box is! RenderBox || overlay == null) return;
    final ovBox = overlay.context.findRenderObject() as RenderBox;
    final iconPos = box.localToGlobal(Offset.zero, ancestor: ovBox);
    final iconCx = iconPos.dx + box.size.width / 2;
    final w = ovBox.size.width - 32;
    final cardBox = _cardBoxOf(box);
    final cardRect = cardBox != null ? cardBox.localToGlobal(Offset.zero, ancestor: ovBox) & cardBox.size : null;
    final top = (cardRect?.bottom ?? iconPos.dy + box.size.height) + 10;
    // 말풍선은 카드 위·아래 중 자리가 더 넓은 쪽으로 (위 상태바 · 아래 시스템 버튼과 안 겹치게)
    final pad = MediaQuery.of(context).padding;
    final spaceBelow = ovBox.size.height - top - pad.bottom - 12;
    final spaceAbove = (cardRect?.top ?? iconPos.dy) - 10 - pad.top - 12;
    final above = spaceAbove > spaceBelow;
    // 그래도 길면 말풍선 안에서 위아래로 밀어서 보기
    final maxH = (above ? spaceAbove : spaceBelow).clamp(160.0, double.infinity).toDouble();
    final bottomGap = ovBox.size.height - (cardRect?.top ?? iconPos.dy) + 10;

    // 소리: 효과음 켜져 있으면 톡 (폰이 진동 모드면 진동, 무음이면 조용) / 꺼져 있으면 평소 터치 진동
    final soundOn = context.read<ThemeProvider>().feedbackSoundEnabled;
    if (soundOn) {
      const MethodChannel('kr.ssing.catsong/media')
          .invokeMethod('feedbackSound', {'low': false})
          .catchError((Object _) => null);
    } else {
      const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
    }

    _removeBubbleNow();
    _bubbleFor = iconKey;
    _bubble = OverlayEntry(
      builder: (_) => Stack(
        children: [
          // 다른 곳을 누르면 닫기 (누른 건 그대로 아래로 전달)
          Positioned.fill(
            child: Listener(
              behavior: HitTestBehavior.translucent,
              onPointerDown: (e) {
                // 포인트 색 카드 안(동그라미)은 눌러도 열어 둠 → 바꿔 보며 비교
                if (keepOpenOnCard && cardRect != null && cardRect.contains(ovBox.globalToLocal(e.position))) return;
                _hideBubble();
              },
            ),
          ),
          Positioned(
            left: 16,
            top: above ? null : top,
            bottom: above ? bottomGap : null,
            width: w,
            child: _InfoBubble(
              tailDown: above,
              key: _bubbleKey,
              title: title,
              text: text,
              items: items,
              foot: foot,
              tailX: iconCx - 16,
              maxHeight: maxH,
              isDark: d,
              onClose: _hideBubble,
              onClosed: _removeBubbleNow,
            ),
          ),
        ],
      ),
    );
    overlay.insert(_bubble!);
  }

  /// ⓘ를 감싼 카드(위쪽으로 처음 만나는 꾸민 상자)
  RenderBox? _cardBoxOf(RenderBox icon) {
    RenderObject? r = icon.parent;
    var depth = 0;
    while (r != null && depth < 30) {
      if (r is RenderDecoratedBox) {
        final dec = r.decoration;
        if (dec is BoxDecoration && dec.borderRadius != null && r.size.width > 60) return r;
      }
      r = r.parent;
      depth++;
    }
    return null;
  }

  final GlobalKey _pointInfoKey = GlobalKey();
  final GlobalKey _homeInfoKey = GlobalKey();
  static List<(String, String)> get _homeInfoItems => [
    (tr.infoTodaySong, tr.infoTodaySongD),
    (tr.infoLongTime, tr.infoLongTimeD),
    (tr.infoWeek, tr.infoWeekD),
    (tr.infoTime, tr.infoTimeD),
    (tr.infoTips, tr.infoTipsD),
    (tr.infoAlarm, tr.infoAlarmD),
  ];
  static List<(String, String)> get _pointInfoItems => [
    (tr.pcMusic, tr.pcMusicD),
    (tr.pcPlayer, tr.pcPlayerD),
    (tr.pcLyrics, tr.pcLyricsD),
    (tr.pcRadio, tr.pcRadioD),
    (tr.pcNature, tr.pcNatureD),
    (tr.pcVideo, tr.pcVideoD),
    (tr.pcEtc, tr.pcEtcD),
  ];

  /// 포인트 색: 이름 + 아래 동그라미 10개 (누르면 바로 바뀜, 폰 크기에 맞춰 한 줄)
  Widget _pointColorTile(ThemeProvider t) {
    final d = t.isDarkMode;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.fromLTRB(16, 13, 16, 14),
      decoration: BoxDecoration(
        color: _sCard(d),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _iconBox(Icons.palette_outlined, d),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        // 제목 (색 이름) — 글자가 커도 한 줄, 넘치면 …
                        Flexible(
                          child: Text.rich(
                            TextSpan(children: [
                              TextSpan(text: tr.accentColor),
                              if (t.pointColorName != null)
                                TextSpan(
                                    text: ' (${pointColorName(t.pointColorName!)})',
                                    style: TextStyle(color: _sTextHint(d), fontSize: 13)),
                            ]),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: _sText(d), fontSize: 14.5),
                          ),
                        ),
                        // ⓘ 누르면 바뀌는 곳 말풍선
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () => _showBubble(_pointInfoKey, d,
                              title: tr.accentWhere,
                              items: _pointInfoItems,
                              foot: tr.accentFoot,
                              keepOpenOnCard: true),
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(6, 4, 8, 4),
                            child: Icon(Icons.info_outline_rounded, key: _pointInfoKey, size: 16, color: _sTextHint(d)),
                          ),
                        ),
                      ],
                    ),
                    Text(tr.accentDesc,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: _sTextHint(d), fontSize: 11.5)),
                  ],
                ),
              ),

            ],
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.only(left: 42),
            child: Row(
              children: [
                for (var i = 0; i < ThemeProvider.pointColors.length; i++) ...[
                  if (i > 0) const SizedBox(width: 6),
                  Expanded(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 28),
                        child: AspectRatio(
                          aspectRatio: 1,
                          child: GestureDetector(
                            onTap: () {
                              const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                              t.setPrimaryColor(ThemeProvider.pointColors[i].$2);
                            },
                            child: Builder(builder: (_) {
                              final c = ThemeProvider.pointColors[i].$2;
                              final on = t.primaryColor.value == c.value;
                              return Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: on ? _sCard(d) : c,
                                  border: on ? Border.all(color: _sText(d), width: 2) : null,
                                ),
                                padding: on ? const EdgeInsets.all(3) : EdgeInsets.zero,
                                child: on
                                    ? DecoratedBox(decoration: BoxDecoration(shape: BoxShape.circle, color: c))
                                    : null,
                              );
                            }),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title) {
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    // 작은 회색 소제목 (다른 화면과 같은 모양)
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 8),
      child: Text(title,
          style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }

  Widget _buildTile(BuildContext context, {
    required IconData icon, required String title, String? subtitle, String? desc,
    required VoidCallback onTap, required Color primaryColor,
    Widget? trailing, bool isFirst = false, bool isLast = false,
    Widget? titleExtra, // 이름 바로 옆 (예: ⓘ)
    Widget? descWidget, // 설명 대신 보여 줄 것 (예: '다시 보기 ›')
  }) {
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    // 같은 묶음은 흰 카드 하나로 (위·아래 끝만 둥글게)
    const r = Radius.circular(16);
    final radius = BorderRadius.vertical(top: isFirst ? r : Radius.zero, bottom: isLast ? r : Radius.zero);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: _sCard(isDarkMode), borderRadius: radius),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: radius,
          onTap: onTap,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isFirst)
                Container(height: 0.5, margin: const EdgeInsets.only(left: 58), color: _sBorder(isDarkMode)),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: desc != null ? 11 : 14),
                // 한 줄로: 아이콘 · 이름 ········ 작은 회색 글자 · 스위치/›
                child: Row(children: [
                  _iconBox(icon, isDarkMode),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: _sText(isDarkMode), fontSize: 14.5)),
                            ),
                            if (titleExtra != null) titleExtra,
                          ],
                        ),
                        if (desc != null) ...[
                          const SizedBox(height: 2),
                          descWidget ??
                          Text(desc,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 11.5)),
                        ],
                      ],
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(width: 8),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 150),
                      child: Text(subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 12.5)),
                    ),
                  ],
                  const SizedBox(width: 6),
                  trailing ?? Icon(Icons.chevron_right_rounded, color: _sTextHint(isDarkMode), size: 20),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _toggleFlashlight(BuildContext context) async {
    try {
      if (_isFlashlightOn) {
        await TorchLight.disableTorch();
        setState(() => _isFlashlightOn = false);
      } else {
        if (_isSosOn) { setState(() => _isSosOn = false); await TorchLight.disableTorch(); await Future.delayed(const Duration(milliseconds: 200)); }
        await TorchLight.enableTorch();
        setState(() => _isFlashlightOn = true);
      }
    } catch (e) {
      showParanToast(context, AppLocalizations.of(context)!.flashlightError, error: true);
    }
  }

  Future<void> _toggleSOS(BuildContext context) async {
    if (_isSosOn) {
      setState(() => _isSosOn = false);
      await TorchLight.disableTorch();
    } else {
      if (_isFlashlightOn) { await TorchLight.disableTorch(); setState(() => _isFlashlightOn = false); await Future.delayed(const Duration(milliseconds: 200)); }
      setState(() => _isSosOn = true);
      _startSOS();
    }
  }

  Future<void> _startSOS() async {
    final p = [200, 200, 200, 200, 200, 400, 600, 200, 600, 200, 600, 400, 200, 200, 200, 200, 200, 800];
    while (_isSosOn && mounted) {
      for (int i = 0; i < p.length; i++) {
        if (!_isSosOn || !mounted) break;
        if (i % 2 == 0) { await TorchLight.enableTorch(); } else { await TorchLight.disableTorch(); }
        await Future.delayed(Duration(milliseconds: p[i]));
      }
    }
    if (mounted) await TorchLight.disableTorch();
  }

  /// 프로모션 코드 — 아래에서 올라오는 베이지 카드 (입력 → 틀리면 빨간 안내 → 성공하면 혜택 카드)
  Future<void> _showPromoCodeDialog(BuildContext context) async {
    final isDarkMode = context.read<ThemeProvider>().isDarkMode;
    final l = AppLocalizations.of(context)!;
    final controller = TextEditingController();
    final prefs = await SharedPreferences.getInstance();
    var unlocked = prefs.getBool('promo_unlocked') ?? false;
    var error = false;
    if (!context.mounted) return;

    final ink = _sText(isDarkMode);
    final btnText = isDarkMode ? const Color(0xFF24221F) : const Color(0xFFF4EFE5);
    const red = Color(0xFFD84A3A);


    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _sBg(isDarkMode),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        Future<void> apply() async {
          if (controller.text.trim() == '37258') {
            await prefs.setBool('promo_unlocked', true);
            // 창 닫고 가운데 알림 (다른 알림처럼 팝 → 옆으로 슝)
            if (ctx.mounted) Navigator.pop(ctx);
            if (context.mounted) {
              showActionFeedback(context, type: ActionFeedbackType.saved, message: tr.adsRemoved);
            }
          } else {
            setSheet(() => error = true);
          }
        }

        final empty = controller.text.trim().isEmpty;

        // 먹색 큰 버튼 (비어 있으면 흐리게)
        Widget bigButton(String label, VoidCallback? onTap) => SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: onTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ink,
                  foregroundColor: btnText,
                  disabledBackgroundColor: _sBorder(isDarkMode),
                  disabledForegroundColor: _sTextHint(isDarkMode),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(label, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700)),
              ),
            );

        return Padding(
          padding: EdgeInsets.fromLTRB(
              20, 10, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom + MediaQuery.of(ctx).padding.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 손잡이
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(color: _sBorder(isDarkMode), borderRadius: BorderRadius.circular(2)),
                ),
              ),
              // 제목 + ✕
              Row(
                children: [
                  Expanded(
                    child: unlocked
                        ? const SizedBox.shrink()
                        : Text(l.promoCode,
                            style: TextStyle(
                                color: ink, fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(ctx),
                    icon: Icon(Icons.close_rounded, color: _sTextHint(isDarkMode), size: 22),
                  ),
                ],
              ),
              if (unlocked) ...[
                // ── 성공 (잡지 느낌: 작은 PARANSORI + 큰 글씨 두 줄) ──
                Text('PARANSORI',
                    style: TextStyle(
                        color: _sTextHint(isDarkMode),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.8)),
                const SizedBox(height: 8),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Text(tr.adFreeTitle,
                          style: TextStyle(
                              color: ink,
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              height: 1.3,
                              letterSpacing: -0.5)),
                    ),
                    // 오른쪽 작은 그림 (리본 레코드판 = 선물)
                    Image.asset('assets/promo_thumb.webp', width: 116, height: 116, cacheWidth: 348),
                  ],
                ),
                const SizedBox(height: 10),
                Text(tr.promoKeeps,
                    style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 12.5)),
                const SizedBox(height: 20),
                Divider(height: 1, thickness: 1, color: _sBorder(isDarkMode)),
                const SizedBox(height: 16),
                bigButton(l.confirm, () => Navigator.pop(ctx)),
              ] else ...[
                // ── 입력 ──
                Text(l.promoEnter, style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 12.5)),
                const SizedBox(height: 14),
                Container(
                  decoration: BoxDecoration(
                    color: _sCard(isDarkMode),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: error ? red : Colors.transparent, width: 1.5),
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 4, 8, 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: controller,
                          autofocus: true,
                          keyboardType: TextInputType.number,
                          onChanged: (_) => setSheet(() => error = false),
                          onSubmitted: (_) => apply(),
                          style: TextStyle(
                              color: ink, fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: 2),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: tr.enterCode,
                            hintStyle: TextStyle(
                                color: _sTextHint(isDarkMode).withOpacity(0.6),
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0),
                          ),
                        ),
                      ),
                      // 붙여넣기 (복사해서 오는 경우가 많아서)
                      TextButton(
                        onPressed: () async {
                          final data = await Clipboard.getData(Clipboard.kTextPlain);
                          final t = (data?.text ?? '').trim();
                          if (t.isEmpty) return;
                          controller.text = t;
                          controller.selection = TextSelection.collapsed(offset: t.length);
                          setSheet(() => error = false);
                        },
                        style: TextButton.styleFrom(
                          backgroundColor: _sBg(isDarkMode),
                          foregroundColor: _sTextSub(isDarkMode),
                          minimumSize: const Size(0, 32),
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                        ),
                        child: Text(tr.paste, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ),
                if (error) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.error_outline_rounded, color: red, size: 15),
                      const SizedBox(width: 5),
                      Text(l.promoInvalid, style: const TextStyle(color: red, fontSize: 12)),
                    ],
                  ),
                ],
                const SizedBox(height: 16),
                bigButton(l.confirm, empty ? null : apply),
              ],
            ],
          ),
        );
      }),
    );
  }


  /// 이어폰 연결하면 이어서 듣기: 끄기 · 알림으로 묻기 · 바로 재생
  void _showHeadsetResumeSheet(BuildContext context) {
    final isDarkMode = context.read<ThemeProvider>().isDarkMode;
    const icons = [
      Icons.do_not_disturb_on_outlined,
      Icons.notifications_none_rounded,
      Icons.play_circle_outline_rounded,
    ];
    showParanSheet(
      context,
      title: tr.headsetTitle,
      builder: (ctx, setSheet) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ParanCard(
            children: [
              for (var i = 0; i < HeadsetResume.names.length; i++)
                ParanRow(
                  icon: icons[i],
                  title: HeadsetResume.names[i],
                  selected: HeadsetResume.mode.value == i,
                  onTap: () {
                    const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                    HeadsetResume.setMode(i);
                    Navigator.pop(ctx);
                    // 켤 때만 배터리 부탁 (한 번만)
                    if (i > 0) {
                      HeadsetResume.askBattery(context, 'headset',
                          tr.batteryAskHeadset);
                    }
                  },
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 2, 4, 4),
            child: Text(
                tr.headsetNote,
                style: TextStyle(color: _sTextHint(isDarkMode), fontSize: 12.5, height: 1.5)),
          ),
        ],
      ),
    );
  }

  void _showPlayerStyleDialog(BuildContext context) {
    showPlayerStyleMenu(context); // 재생화면 ⋮ 메뉴와 같은 스타일 창 (시디롬·파란포토·앨범)
  }

  void _showFontDialog(BuildContext context) {
    final themeProvider = context.read<ThemeProvider>();
    String? busyKey; // 지금 받는 중인 글꼴 (그 줄에 동그라미)
    showParanSheet(
      context,
      title: AppLocalizations.of(context)!.fontChange,
      builder: (ctx, setSheet) => ParanCard(
        children: [
          for (final font in ThemeProvider.availableFonts)
            ParanRow(
              icon: Icons.font_download_outlined,
              title: _getFontName(context, font['key']!),
              // 이름을 그 글꼴 모양으로 (받기 전에도 보이게 이름 글자만 담은 작은 글꼴)
              titleFont: ThemeProvider.previewFamily(font['key']!),
              selected: themeProvider.fontFamily == font['key'],
              // 아직 안 받은 글꼴은 ⬇, 받는 중이면 동그라미
              trailing: busyKey == font['key']
                  ? SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: pointColorOf(context)),
                    )
                  : FontDownloader.needsDownload(font['key']!)
                      ? Icon(Icons.download_rounded, size: 18, color: _sTextHint(themeProvider.isDarkMode))
                      : null,
              onTap: () async {
                final key = font['key']!;
                if (busyKey != null) return; // 받는 중엔 다른 줄 안 눌리게
                if (!FontDownloader.isLoaded(key)) {
                  final wasNew = FontDownloader.needsDownload(key); // 처음 받는 글꼴인지
                  setSheet(() => busyKey = key);
                  final ok = await FontDownloader.ensure(key);
                  if (!ctx.mounted) return;
                  setSheet(() => busyKey = null);
                  if (!ok) {
                    showParanToast(context, tr.checkInternet, error: true);
                    return;
                  }
                  // 다 받으면 물방울 "똑" (설정 → 효과음 따라: 소리 모드=소리, 진동 모드=진동, 무음=없음)
                  if (wasNew && themeProvider.feedbackSoundEnabled) {
                    const MethodChannel('kr.ssing.catsong/media')
                        .invokeMethod('feedbackSound', {'low': false})
                        .catchError((Object _) => null);
                  }
                }
                await themeProvider.setFontFamily(key);
                // 창은 그대로 두고 ✓만 옮기기 (여러 글꼴을 눌러 보며 비교할 수 있게)
                if (ctx.mounted) setSheet(() {});
              },
            ),
        ],
      ),
    );
  }

  /// 언어 줄 글자 (번역 파일)
  String _langText(String key) {
    final l = AppLocalizations.of(context)!;
    return switch (key) {
      'desc' => l.languageMenuDesc,
      'hant' => l.languageTagHant,
      'hans' => l.languageTagHans,
      _ => l.languagePhone,
    };
  }

  /// 언어 이름: 폰 설정 따라가기는 지금 언어로, 나머지는 그 나라 말로 (모르는 언어로 바꿔도 다시 찾게)
  String _langName(String code) {
    if (code == 'system') return _langText('system');
    for (final l in ThemeProvider.appLanguages) {
      if (l.$1 == code) {
        // 괄호 안에 지금 앱 언어로 쓴 이름 (예: Deutsch (독일어)) — 지금 언어 자신이면 이름이 같아서 안 붙임
        final tag = _langLocalName(code);
        return tag.isEmpty || tag == l.$2 ? l.$2 : '${l.$2} ($tag)';
      }
    }
    return _langText('system');
  }

  /// 언어 이름을 지금 앱 언어로 (번역 파일 langName…)
  String _langLocalName(String code) {
    final l = AppLocalizations.of(context)!;
    return switch (code) {
      'ko' => l.langNameKo,
      'en' => l.langNameEn,
      'ja' => l.langNameJa,
      'zh_Hant' => l.langNameZhHant,
      'zh_Hans' => l.langNameZhHans,
      'id' => l.langNameId,
      'de' => l.langNameDe,
      'es' => l.langNameEs,
      'fr' => l.langNameFr,
      'pt' => l.langNamePt,
      'vi' => l.langNameVi,
      'th' => l.langNameTh,
      'ru' => l.langNameRu,
      'it' => l.langNameIt,
      'tr' => l.langNameTr,
      'pl' => l.langNamePl,
      'uk' => l.langNameUk,
      'hi' => l.langNameHi,
      'ro' => l.langNameRo,
      'cs' => l.langNameCs,
      'hu' => l.langNameHu,
      _ => '',
    };
  }

  /// 설정 → 언어: 폰 설정 따라가기 + 앱이 아는 언어들 (고르면 바로 바뀌고 기억)
  void _showLanguageSheet(BuildContext context) {
    final themeProvider = context.read<ThemeProvider>();
    showParanSheet(
      context,
      title: AppLocalizations.of(context)!.languageTab,
      builder: (ctx, setSheet) => ParanCard(
        children: [
          for (final code in ['system', for (final l in ThemeProvider.appLanguages) l.$1])
            ParanRow(
              icon: code == 'system' ? Icons.phone_android_rounded : Icons.language_rounded,
              title: _langName(code),
              selected: themeProvider.appLanguage == code,
              onTap: () {
                const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                Navigator.pop(ctx);
                themeProvider.setAppLanguage(code);
              },
            ),
        ],
      ),
    );
  }

  /// 약관 주소: 폰 언어 + 앱 다크/라이트를 붙여서 (페이지가 그대로 맞춰 열림)
  String _policyUrl(String page) {
    // 설정 → 언어에서 고른 언어 — 약관 페이지에 없는 언어(독일어·프랑스어 등)는 영어로
    // (그냥 보내면 페이지가 폰 언어=한국어로 열려서)
    final code = Localizations.localeOf(context).languageCode;
    final lang = const ['ko', 'en', 'ja', 'zh', 'vi', 'hi', 'id', 'th', 'es', 'pt', 'de', 'fr', 'ru', 'it', 'tr', 'pl', 'uk', 'ro', 'cs', 'hu']
            .contains(code)
        ? code
        : 'en';
    final theme = context.read<ThemeProvider>().isDarkMode ? 'dark' : 'light';
    return 'https://www.ssing.kr/$page.html?lang=$lang&theme=$theme';
  }

  /// 약관은 앱 안에서 열기 (폰 브라우저의 다크 모드와 상관없이 앱 설정대로)
  void _openPolicy(String page, String title) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PolicyWebScreen(url: _policyUrl(page), title: title)));
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (e) { await launchUrl(uri, mode: LaunchMode.inAppWebView); }
  }

  /// 글자 크기: 작게 · 보통 · 크게 (누르면 앱 전체가 바로 바뀜)
  void _showTextSizeDialog(BuildContext context) {
    final isDarkMode = context.read<ThemeProvider>().isDarkMode;
    final themeProvider = context.read<ThemeProvider>();
    showParanSheet(
      context,
      title: AppLocalizations.of(context)!.textSize,
      builder: (ctx, setSheet) {
        final cur = themeProvider.textStepIndex;
        return Column(
          children: [
            // 미리보기 (고른 크기 그대로 보임)
            ParanCard(
              padding: const EdgeInsets.all(16),
              children: [
                Text(AppLocalizations.of(context)!.preview,
                    style: TextStyle(color: _sText(isDarkMode), fontSize: 16)),
              ],
            ),
            // 작게 · 보통 · 크게 (고른 칸은 먹색)
            ParanCard(
              padding: const EdgeInsets.all(8),
              children: [
                Row(
                  children: [
                    for (var i = 0; i < ThemeProvider.textSteps.length; i++) ...[
                      if (i > 0) const SizedBox(width: 8),
                      Expanded(
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                            themeProvider.setTextScale(ThemeProvider.textSteps[i].$2);
                            setSheet(() {});
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 160),
                            height: 66,
                            decoration: BoxDecoration(
                              color: i == cur ? _sText(isDarkMode) : _sInputBg(isDarkMode),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(tr.textSample,
                                    textScaler: TextScaler.noScaling,
                                    style: TextStyle(
                                        color: i == cur ? _sBg(isDarkMode) : _sText(isDarkMode),
                                        fontSize: 13 + i * 2.5,
                                        height: 1.2,
                                        fontWeight: FontWeight.w700)),
                                const SizedBox(height: 3),
                                Text([tr.sizeTiny, tr.small, tr.sizeMedium, tr.large, tr.sizeHuge][i],
                                    textScaler: TextScaler.noScaling,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: i == cur ? _sBg(isDarkMode) : _sTextSub(isDarkMode),
                                        fontSize: 10.5,
                                        fontWeight: i == cur ? FontWeight.w700 : FontWeight.w500)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}


/// 넓은 먹색 설명 (다크 모드는 크림색) · 위쪽 꼬리 · ✕로 닫기
class _InfoBubble extends StatefulWidget {
  final String? title;
  final String? text;
  final List<(String, String)>? items;
  final String? foot;
  final double tailX;
  final bool isDark;
  final VoidCallback onClose;
  final VoidCallback onClosed;
  final double maxHeight; // 이보다 길면 안에서 스크롤
  final bool tailDown; // true면 말풍선이 위에 있고 꼬리가 아래(ⓘ 쪽)를 가리킴
  const _InfoBubble({
    super.key,
    this.tailDown = false,
    this.maxHeight = 600,
    this.title,
    this.text,
    this.items,
    this.foot,
    required this.tailX,
    required this.isDark,
    required this.onClose,
    required this.onClosed,
  });

  @override
  State<_InfoBubble> createState() => _InfoBubbleState();
}

class _InfoBubbleState extends State<_InfoBubble> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 220));
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _c.forward();
  }

  void close() {
    if (_closing || !mounted) return;
    _closing = true;
    _c.reverse().whenComplete(widget.onClosed);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bg = widget.isDark ? const Color(0xFFF3EFE7) : const Color(0xFF17140F);
    final fg = widget.isDark ? const Color(0xFF24221F) : const Color(0xFFF4EFE5);
    final point = context.watch<ThemeProvider>().primaryColor; // 점 = 지금 포인트 색
    final curve = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    final head = widget.title ?? widget.text ?? '';
    final items = widget.items ?? const <(String, String)>[];
    return FadeTransition(
      opacity: curve,
      child: SlideTransition(
        position: Tween<Offset>(begin: Offset(0, widget.tailDown ? 0.03 : -0.03), end: Offset.zero).animate(curve),
        child: Material(
          type: MaterialType.transparency,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // 꼬리 (ⓘ 쪽을 가리킴)
              Positioned(
                top: widget.tailDown ? null : -6,
                bottom: widget.tailDown ? -6 : null,
                left: (widget.tailX - 6.5).clamp(14.0, double.infinity).toDouble(),
                child: Transform.rotate(
                  angle: 0.785398,
                  child: Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(2)),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(18, 12, 12, 14),
                constraints: BoxConstraints(maxHeight: widget.maxHeight),
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 28, offset: const Offset(0, 12)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                              head,
                              style: widget.title != null
                                  ? TextStyle(color: fg, fontSize: 15.5, fontWeight: FontWeight.w800, letterSpacing: -0.3)
                                  : TextStyle(color: fg, fontSize: 14, height: 1.55),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        // ✕ 닫기
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: widget.onClose,
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(color: fg.withOpacity(0.12), shape: BoxShape.circle),
                            child: Icon(Icons.close_rounded, size: 19, color: fg),
                          ),
                        ),
                      ],
                    ),
                    // 설명 목록: 길면 말풍선 안에서 위아래로 밀어서 보기
                    Flexible(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                          if (items.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            for (var i = 0; i < items.length; i++) ...[
                              if (i > 0) Container(height: 1, margin: const EdgeInsets.only(right: 6), color: fg.withOpacity(0.12)),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(0, 7, 6, 7),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 9,
                                      height: 9,
                                      margin: const EdgeInsets.only(top: 6),
                                      decoration: BoxDecoration(color: point, shape: BoxShape.circle),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text.rich(
                                        TextSpan(children: [
                                          TextSpan(text: items[i].$1, style: const TextStyle(fontWeight: FontWeight.w700)),
                                          const TextSpan(text: '  '),
                                          TextSpan(text: items[i].$2, style: TextStyle(color: fg.withOpacity(0.75))),
                                        ]),
                                        style: TextStyle(color: fg, fontSize: 14, height: 1.5),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                          if (widget.foot != null) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.info_outline_rounded, size: 15, color: fg.withOpacity(0.65)),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(widget.foot!,
                                      style: TextStyle(color: fg.withOpacity(0.65), fontSize: 12.5)),
                                ),
                              ],
                            ),
                          ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
