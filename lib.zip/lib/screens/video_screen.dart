import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:permission_handler/permission_handler.dart';
import '../providers/video_provider.dart';
import '../models/video.dart';
import '../theme/app_theme.dart';
import '../l10n/app_localizations.dart';
import '../providers/theme_provider.dart';
import '../widgets/paran_dialog.dart';
import '../widgets/action_feedback.dart';
import '../widgets/paran_toast.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<VideoProvider>();
      if (!provider.hasPermission && provider.videos.isEmpty) {
        provider.requestPermissionAndLoad();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final videoProvider = context.watch<VideoProvider>();
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final baseColor = isDarkMode ? Colors.white : Colors.black;
    final bgColor = isDarkMode ? const Color(0xFF17140F) : const Color(0xFFEDE7DA);

    if (videoProvider.permissionDenied) {
      return Scaffold(
        backgroundColor: bgColor,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.video_library_outlined,
                    size: 72, color: baseColor.withOpacity(0.5)),
                const SizedBox(height: 24),
                Text(AppLocalizations.of(context)!.videoPermissionRequired,
                    style: TextStyle(
                        color: baseColor,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text(AppLocalizations.of(context)!.videoPermissionMessage,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: baseColor.withOpacity(0.7), fontSize: 14, height: 1.6)),
                const SizedBox(height: 32),
                ElevatedButton(
                  onPressed: () => openAppSettings(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: baseColor.withOpacity(0.15),
                    foregroundColor: baseColor,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  child: Text(AppLocalizations.of(context)!.openSettings,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (videoProvider.isLoading) {
      return Scaffold(
        backgroundColor: bgColor,
        body: Center(
          child: CircularProgressIndicator(color: baseColor.withOpacity(0.6)),
        ),
      );
    }

    if (videoProvider.videos.isEmpty) {
      return Scaffold(
        backgroundColor: bgColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.video_library_outlined,
                  size: 72, color: baseColor.withOpacity(0.4)),
              const SizedBox(height: 16),
              Text(AppLocalizations.of(context)!.noVideosFound,
                  style: TextStyle(
                      color: baseColor.withOpacity(0.7), fontSize: 16)),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgColor,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            snap: true,
            backgroundColor: bgColor,
            expandedHeight: 80 * MediaQuery.of(context).textScaler.scale(1.0),
            flexibleSpace: FlexibleSpaceBar(
              background: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppLocalizations.of(context)!.videos,
                          style: TextStyle(
                              color: baseColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      Text(AppLocalizations.of(context)!.videoCount(videoProvider.videos.length),
                          style: TextStyle(
                              color: baseColor.withOpacity(0.7), fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(8),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.5,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  return _VideoTile(video: videoProvider.videos[index]);
                },
                childCount: videoProvider.videos.length,
              ),
            ),
          ),
          const SliverPadding(padding: EdgeInsets.only(bottom: 16)),
        ],
      ),
    );
  }
}

class _VideoTile extends StatefulWidget {
  final Video video;

  const _VideoTile({required this.video});

  @override
  State<_VideoTile> createState() => _VideoTileState();
}

class _VideoTileState extends State<_VideoTile> {
  static const _channel = MethodChannel('kr.ssing.catsong/media');
  Uint8List? _thumbnail;

  @override
  void initState() {
    super.initState();
    _loadThumbnail();
  }

  Future<void> _loadThumbnail() async {
    try {
      final result = await _channel.invokeMethod('getVideoThumbnail', {
        'path': widget.video.uri,
      });
      if (result != null && mounted) {
        setState(() {
          _thumbnail = Uint8List.fromList(List<int>.from(result));
        });
      }
    } catch (e) {
      // 썸네일 로드 실패
    }
  }

  Future<void> _showOptions(BuildContext context) async {
    final isDarkMode = context.read<ThemeProvider>().isDarkMode;
    final baseColor = isDarkMode ? Colors.white : Colors.black;
    showModalBottomSheet(
      context: context,
      backgroundColor: isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF7F5F0),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.edit, color: baseColor.withOpacity(0.7)),
              title: Text(AppLocalizations.of(context)!.rename,
                  style: TextStyle(color: baseColor)),
              onTap: () {
                Navigator.pop(ctx);
                _renameVideo(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.redAccent),
              title: Text(AppLocalizations.of(context)!.delete,
                  style: TextStyle(color: baseColor)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteVideo(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _renameVideo(BuildContext context) async {
    final newName = await showParanInput(
      context,
      title: AppLocalizations.of(context)!.rename,
      initial: widget.video.titleDisplay,
    );
    if (newName == null || !context.mounted) return;
    try {
      await _channel.invokeMethod('renameVideo', {
        'uri': widget.video.uri,
        'newName': newName,
      });
      if (!context.mounted) return;
      context.read<VideoProvider>().loadVideos();
      showActionFeedback(context, type: ActionFeedbackType.edited, message: '이름을 바꿨어요');
    } catch (e) {
      showParanToast(context, '이름을 바꾸지 못했어요', error: true);
    }
  }

  Future<void> _deleteVideo(BuildContext context) async {
    final ok = await showParanConfirm(
      context,
      title: '이 동영상을 삭제할까요?',
      message: "'${widget.video.titleDisplay}'이(가) 폰에서 지워져요",
      confirmLabel: '삭제',
      danger: true,
    );
    if (!ok || !context.mounted) return;
    try {
      await _channel.invokeMethod('deleteVideo', {'uri': widget.video.uri});
      if (!context.mounted) return;
      context.read<VideoProvider>().loadVideos();
      showActionFeedback(context, type: ActionFeedbackType.deleted);
    } catch (e) {
      showParanToast(context, '삭제하지 못했어요', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () => _showOptions(context),
      onTap: () {
        _channel.invokeMethod('vibrate');
        Navigator.push(
          context,
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) => VideoPlayerScreen(video: widget.video),
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              return FadeTransition(opacity: animation, child: child);
            },
            transitionDuration: const Duration(milliseconds: 250),
          ),
        );
      },
      child: Builder(builder: (ctx) {
        final isDarkMode = ctx.watch<ThemeProvider>().isDarkMode;
        final baseColor = isDarkMode ? Colors.white : Colors.black;
        return Container(
          decoration: BoxDecoration(
            color: baseColor.withOpacity(0.06),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(12)),
                  child: _thumbnail != null
                      ? Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.memory(
                        _thumbnail!,
                        fit: BoxFit.cover,
                      ),
                      Center(
                        child: Icon(
                          Icons.play_circle_outline,
                          color: Colors.white.withOpacity(0.8),
                          size: 36,
                        ),
                      ),
                    ],
                  )
                      : Container(
                    color: baseColor.withOpacity(0.1),
                    child: Center(
                      child: Icon(Icons.play_circle_outline,
                          color: baseColor.withOpacity(0.6),
                          size: 40),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.video.titleDisplay,
                        style: TextStyle(
                            color: baseColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w500),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      widget.video.durationFormatted,
                      style: TextStyle(
                          color: baseColor.withOpacity(0.35), fontSize: 10),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

class VideoPlayerScreen extends StatefulWidget {
  final Video video;
  const VideoPlayerScreen({super.key, required this.video});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late VideoPlayerController _videoPlayerController;
  ChewieController? _chewieController;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    // 라디오/음악 정지
    try {
      context.read<VideoProvider>().stopOtherPlayers();
    } catch (e) {
      debugPrint('stopOtherPlayers 오류: $e');
    }

    _videoPlayerController = VideoPlayerController.file(
      File(widget.video.uri),
    );

    await _videoPlayerController.initialize();

    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController,
      autoPlay: true,
      looping: false,
      allowFullScreen: true,
      allowMuting: true,
      showControls: true,
      showOptions: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.white,
        handleColor: Colors.white,
        backgroundColor: Colors.white24,
        bufferedColor: Colors.white38,
      ),
    );

    setState(() {});
  }

  @override
  void dispose() {
    _videoPlayerController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.video.titleDisplay,
            style: const TextStyle(color: Colors.white)),
        leading: IconButton(
          onPressed: () {
            const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            color: const Color(0xFF2A2A2A),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'rename',
                child: Row(
                  children: [
                    const Icon(Icons.edit, color: Colors.white, size: 18),
                    const SizedBox(width: 10),
                    Text(AppLocalizations.of(context)!.rename,
                        style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    const Icon(Icons.delete, color: Colors.redAccent, size: 18),
                    const SizedBox(width: 10),
                    Text(AppLocalizations.of(context)!.delete,
                        style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ),
            ],
            onSelected: (value) async {
              if (value == 'rename') {
                final newName = await showParanInput(
                  context,
                  title: AppLocalizations.of(context)!.rename,
                  initial: widget.video.titleDisplay,
                );
                if (newName != null && newName.isNotEmpty) {
                  await const MethodChannel('kr.ssing.catsong/media')
                      .invokeMethod('renameVideo', {
                    'uri': widget.video.uri,
                    'newName': newName,
                  });
                  Navigator.pop(context);
                }
              } else if (value == 'delete') {
                final confirm = await showParanConfirm(
                  context,
                  title: '이 동영상을 삭제할까요?',
                  message: "'${widget.video.titleDisplay}'이(가) 폰에서 지워져요",
                  confirmLabel: '삭제',
                  danger: true,
                );
                if (confirm == true) {
                  await const MethodChannel('kr.ssing.catsong/media')
                      .invokeMethod('deleteVideo', {'uri': widget.video.uri});
                  Navigator.pop(context);
                }
              }
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: _chewieController != null
              ? Chewie(controller: _chewieController!)
              : const CircularProgressIndicator(color: Colors.white),
        ),
      ),
    );
  }
}