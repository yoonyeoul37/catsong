import 'dart:math' as math;

import 'package:audio_session/audio_session.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

import '../models/radio_station.dart';
import '../providers/radio_provider.dart';
import '../providers/theme_provider.dart';
import '../l10n/locale_holder.dart';

/// 주사위 판에 올릴 방송 하나
class DiceStation {
  final RadioStation station;
  final String badge; // 로고 칸 글자 (KBS·MBC 등)
  final String frequency; // 93.1 MHz (없으면 '')
  /// 지금 하는 프로그램 이름 (편성표가 없으면 '')
  final String Function(RadioProvider radio) program;
  final double weight; // 나올 확률 (1 = 보통, 0.3 = 덜 나옴)
  final double badgeSize; // 로고 칸 글자 크기 (국기는 크게)
  final String? programLabel; // 카드 아래 작은 제목 (없으면 '지금 하는 프로그램')
  final String? emptyProgram; // 정보가 없을 때 (없으면 '편성 정보가 없어요')
  /// 로고 칸에 넣을 사진 주소 (없으면 '' → 글자)
  final String Function(RadioProvider radio)? image;

  const DiceStation({
    required this.station,
    required this.badge,
    this.frequency = '',
    required this.program,
    this.weight = 1.0,
    this.badgeSize = 10.5,
    this.programLabel,
    this.emptyProgram,
    this.image,
  });
}

/// 라디오 주사위: 가운데 포인트 색 판에 주사위를 던지고, 멈추면 판 위에 방송이 나오며 바로 재생
Future<void> showRadioDice(BuildContext context, List<DiceStation> pool,
    {void Function(RadioStation station)? onOpen}) {
  if (pool.isEmpty) return Future.value();
  return showGeneralDialog(
    context: context,
    barrierDismissible: false,
    barrierColor: const Color(0x8C0A0907),
    transitionDuration: const Duration(milliseconds: 250),
    pageBuilder: (ctx, _, __) => _DiceBoard(pool: pool, onOpen: onOpen),
    transitionBuilder: (ctx, a, _, child) => FadeTransition(
      opacity: a,
      child: ScaleTransition(
        scale: Tween(begin: 0.92, end: 1.0).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
        child: child,
      ),
    ),
  );
}

// ───────── 주사위 소리 (효과음 설정을 따름: 무음·진동 모드에선 폰이 알아서 소리를 끔) ─────────
class _DiceSound {
  static AudioPlayer? _p;

  static Future<void> play(BuildContext context) async {
    bool on = true;
    try {
      on = context.read<ThemeProvider>().feedbackSoundEnabled;
    } catch (_) {}
    if (!on) return;
    // 바닥에 닿을 때마다 짧은 진동
    for (final ms in const [290, 690, 940]) {
      Future.delayed(Duration(milliseconds: ms), () {
        const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate').catchError((Object _) => null);
      });
    }
    try {
      _p ??= AudioPlayer(handleInterruptions: false, handleAudioSessionActivation: false);
      await _p!.setAndroidAudioAttributes(const AndroidAudioAttributes(
        contentType: AndroidAudioContentType.sonification,
        usage: AndroidAudioUsage.assistanceSonification,
      ));
      await _p!.setAsset('assets/dice_roll.mp3');
      await _p!.seek(Duration.zero);
      _p!.play();
    } catch (_) {}
  }
}

// ───────── 판 ─────────
class _DiceBoard extends StatefulWidget {
  final List<DiceStation> pool;
  final void Function(RadioStation station)? onOpen;
  const _DiceBoard({required this.pool, this.onOpen});

  @override
  State<_DiceBoard> createState() => _DiceBoardState();
}

class _DiceBoardState extends State<_DiceBoard> with TickerProviderStateMixin {
  static const double _w = 296, _h = 320, _d = 84;
  static const double _floor = (_h - _d) / 2; // 주사위가 멈추는 높이
  static String? _lastName; // 방금 나온 방송은 빼기
  static List<int> _faceBag = []; // 1~6 한 바퀴씩
  static int _lastFace = 0;

  late final AnimationController _throw =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1050));
  late final AnimationController _out =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
  late final AnimationController _info =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 350));

  final _rng = math.Random();
  bool _busy = false;
  DiceStation? _cur;
  // 멈출 때 각도
  double _rx = 0, _ry = 0, _rz = 0;
  int _spin = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _roll());
  }

  @override
  void dispose() {
    _throw.dispose();
    _out.dispose();
    _info.dispose();
    super.dispose();
  }

  DiceStation _pick() {
    var list = widget.pool.where((s) => s.station.name != _lastName).toList();
    if (list.isEmpty) list = widget.pool;
    // 무게가 큰 방송이 더 자주 나옴
    final total = list.fold<double>(0, (a, s) => a + s.weight);
    var r = _rng.nextDouble() * total;
    var p = list.last;
    for (final s in list) {
      r -= s.weight;
      if (r <= 0) {
        p = s;
        break;
      }
    }
    _lastName = p.station.name;
    return p;
  }

  int _nextFace() {
    if (_faceBag.isEmpty) {
      _faceBag = [1, 2, 3, 4, 5, 6]..shuffle(_rng);
      if (_faceBag.first == _lastFace) _faceBag.add(_faceBag.removeAt(0));
    }
    _lastFace = _faceBag.removeAt(0);
    return _lastFace;
  }

  Future<void> _roll() async {
    if (_busy) return;
    _busy = true;
    final pick = _pick();
    final face = _nextFace();
    final t = _faceTarget[face]!;
    _spin += 2;
    final tilt = math.pi / 180;
    _rx = t.$1 + (_rng.nextBool() ? 7 : -7) * tilt + 2 * math.pi * _spin;
    _ry = t.$2 + (_rng.nextBool() ? 8 : -8) * tilt + 2 * math.pi * (_spin + 1);
    _rz = (_rng.nextDouble() * 30 - 15) * tilt;
    setState(() => _cur = null);
    _info.value = 0;
    _out.value = 0;
    _throw.forward(from: 0);
    _DiceSound.play(context);
    // 던지기 1초 + 멈춘 채로 1초 보여주기
    await Future.delayed(const Duration(milliseconds: 1050 + 1000));
    if (!mounted) return;
    await _out.forward(from: 0); // 쏙 사라짐
    if (!mounted) return;
    setState(() => _cur = pick);
    context.read<RadioProvider>().playStation(pick.station);
    _info.forward(from: 0);
    _busy = false;
  }

  void _close() {
    if (_busy) return;
    Navigator.of(context).pop();
  }

  // 위아래 통통 (0~1 → 판 안 위쪽 좌표)
  double _bounceTop(double t) {
    const k = [(0.0, -60.0), (0.28, _floor), (0.48, _floor - 58), (0.66, _floor), (0.80, _floor - 20), (0.90, _floor), (1.0, _floor)];
    for (var i = 1; i < k.length; i++) {
      if (t <= k[i].$1) {
        final a = k[i - 1], b = k[i];
        final f = (t - a.$1) / (b.$1 - a.$1);
        return a.$2 + (b.$2 - a.$2) * f;
      }
    }
    return _floor;
  }

  @override
  Widget build(BuildContext context) {
    final point = context.watch<ThemeProvider>().primaryColor;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _close, // 판 바깥 누르면 닫기 (라디오는 계속)
      child: Center(
        child: GestureDetector(
          onTap: () {}, // 판 안은 닫히지 않게
          child: SizedBox(
            width: _w,
            height: _h,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: Material(
                type: MaterialType.transparency,
                child: Stack(
                  children: [
                    Positioned.fill(child: RepaintBoundary(child: CustomPaint(painter: _FeltPainter(point)))),
                    // 제목 (던지는 동안만)
                    Positioned(
                      top: 22,
                      left: 0,
                      right: 0,
                      child: AnimatedOpacity(
                        duration: const Duration(milliseconds: 250),
                        opacity: _cur == null ? 0.8 : 0,
                        child: Text(tr.diceWhich,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w700)),
                      ),
                    ),
                    // 주사위 + 그림자
                    AnimatedBuilder(
                      animation: Listenable.merge([_throw, _out]),
                      builder: (context, _) {
                        final t = _throw.value;
                        final xf = const Cubic(0.2, 0.6, 0.3, 1).transform(t);
                        final rf = const Cubic(0.15, 0.6, 0.25, 1).transform(t);
                        final left = -90 + (((_w - _d) / 2) + 90) * xf;
                        final top = _bounceTop(t);
                        final out = Curves.easeInCubic.transform(_out.value);
                        final shadowOpacity = ((0.15 + 0.75 * ((top + 60) / 190).clamp(0.0, 1.0)) * (1 - out)).toDouble();
                        return Stack(
                          children: [
                            Positioned(
                              left: left + 7,
                              top: _floor + _d - 8,
                              child: Opacity(
                                opacity: shadowOpacity.clamp(0.0, 1.0).toDouble(),
                                child: Container(
                                  width: 70,
                                  height: 14,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: const [BoxShadow(color: Color(0x73000000), blurRadius: 8)],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              left: left,
                              top: top,
                              child: Opacity(
                                opacity: 1 - out,
                                child: Transform.scale(
                                  scale: 1 - 0.8 * out,
                                  child: DiceCube(size: _d, rx: _rx * rf, ry: _ry * rf, rz: _rz * rf),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                    // 판 위 방송
                    if (_cur != null)
                      Positioned.fill(
                        child: FadeTransition(
                          opacity: _info,
                          child: SlideTransition(
                            position: Tween(begin: const Offset(0, 0.03), end: Offset.zero)
                                .animate(CurvedAnimation(parent: _info, curve: Curves.easeOutCubic)),
                            child: _StationInfo(
                              item: _cur!,
                              face: _lastFace,
                              onAgain: _roll,
                              onOpen: widget.onOpen == null
                                  ? null
                                  : () {
                                      if (_busy) return;
                                      const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                                      final st = _cur!.station;
                                      Navigator.of(context).pop();
                                      widget.onOpen!(st);
                                    },
                            ),
                          ),
                        ),
                      ),
                    // ✕
                    Positioned(
                      top: 12,
                      right: 12,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: _close,
                        child: const SizedBox(
                          width: 36,
                          height: 36,
                          child: Icon(Icons.close_rounded, color: Color(0xCCFFFFFF), size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// 면이 앞으로 오게 하는 각도 (rx, ry)
const Map<int, (double, double)> _faceTarget = {
  1: (0.0, 0.0),
  6: (0.0, -math.pi),
  2: (0.0, -math.pi / 2),
  5: (0.0, math.pi / 2),
  3: (-math.pi / 2, 0.0),
  4: (math.pi / 2, 0.0),
};

/// 판 위에 나온 방송: 나온 숫자 + 판 위에 놓인 흰 방송 카드
class _StationInfo extends StatelessWidget {
  final DiceStation item;
  final int face; // 주사위에 나온 숫자
  final VoidCallback onAgain;
  final VoidCallback? onOpen; // 카드 누르면 상세 화면
  const _StationInfo({required this.item, required this.face, required this.onAgain, this.onOpen});

  // 1이, 2가, 3이, 4가, 5가, 6이
  static String _got(int n) => tr.localeName.startsWith('ko')
      ? '$n${const {1: '이', 3: '이', 6: '이'}[n] ?? '가'} 나왔어요!'
      : tr.diceGot(n);

  @override
  Widget build(BuildContext context) {
    final radio = context.watch<RadioProvider>();
    final point = context.watch<ThemeProvider>().primaryColor;
    final program = item.program(radio);
    final img = (item.image?.call(radio) ?? '').trim();
    final fav = radio.isFavorite(item.station.stationUuid);
    const ink = Color(0xFF17140F);
    const hint = Color(0xFF8A8378);
    return MediaQuery.withClampedTextScaling(
      maxScaleFactor: 1.15,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
        child: Column(
          children: [
            // 나온 숫자
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _MiniFace(n: face),
                const SizedBox(width: 9),
                Text(_got(face),
                    style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
              ],
            ),
            const SizedBox(height: 14),
            // 판 위에 살짝 비스듬히 놓인 흰 카드 (누르면 상세 화면)
            GestureDetector(
              onTap: onOpen,
              child: Transform.rotate(
              angle: -1.5 * math.pi / 180,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFDF8),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: const [BoxShadow(color: Color(0x38000000), blurRadius: 24, offset: Offset(0, 10))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          alignment: Alignment.center,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            color: Color.lerp(Colors.white, point, 0.14),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          // 방송 사진이 있으면 사진, 없거나 못 불러오면 글자
                          child: Builder(builder: (_) {
                            final badgeText = Text(item.badge,
                                maxLines: 1,
                                overflow: TextOverflow.clip,
                                style: TextStyle(color: point, fontSize: item.badgeSize, fontWeight: FontWeight.w800));
                            if (img.isEmpty) return badgeText;
                            return Image.network(
                              img,
                              width: 36,
                              height: 36,
                              fit: BoxFit.cover,
                              gaplessPlayback: true,
                              frameBuilder: (_, child, frame, sync) => sync
                                  ? child
                                  : AnimatedOpacity(
                                      opacity: frame == null ? 0 : 1,
                                      duration: const Duration(milliseconds: 250),
                                      child: child,
                                    ),
                              errorBuilder: (_, __, ___) => badgeText,
                            );
                          }),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.station.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: ink, fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                              if (item.frequency.isNotEmpty)
                                Text(item.frequency, style: const TextStyle(color: hint, fontSize: 11.5)),
                            ],
                          ),
                        ),
                        _MiniBars(color: point),
                        const SizedBox(width: 5),
                        Text(tr.nowPlayingBadge, style: TextStyle(color: point, fontSize: 11, fontWeight: FontWeight.w800)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const SizedBox(width: double.infinity, height: 1.5, child: CustomPaint(painter: _DashPainter())),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.programLabel ?? tr.diceProgramLabel, style: const TextStyle(color: hint, fontSize: 11.5)),
                              const SizedBox(height: 1),
                              Text(program.isEmpty ? (item.emptyProgram ?? tr.diceNoProgram) : program,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: program.isEmpty ? hint : ink, fontSize: 13.5, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                        if (onOpen != null) const Icon(Icons.chevron_right_rounded, color: hint, size: 22),
                      ],
                    ),
                  ],
                ),
              ),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: _BoardButton(
                    filled: true,
                    onTap: () {
                      const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                      onAgain();
                    },
                    label: tr.rollAgain,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _BoardButton(
                    filled: false,
                    onTap: () {
                      const MethodChannel('kr.ssing.catsong/media').invokeMethod('vibrate');
                      radio.toggleFavorite(item.station);
                    },
                    icon: fav ? CupertinoIcons.heart_fill : CupertinoIcons.heart,
                    label: tr.favorites,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// 나온 숫자를 보여주는 작은 말랑 주사위 (한 면)
class _MiniFace extends StatelessWidget {
  final int n;
  const _MiniFace({required this.n});

  @override
  Widget build(BuildContext context) {
    final pips = DiceCube._pips[n] ?? const [4];
    return Transform.rotate(
      angle: -10 * math.pi / 180,
      child: Container(
        width: 34,
        height: 34,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: const LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFFDF8), Color(0xFFF1E9DA)]),
          boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 10, offset: Offset(0, 4))],
        ),
        child: Stack(
          children: [
            for (final k in pips)
              Align(
                alignment: Alignment(-1.0 + (k % 3), -1.0 + (k ~/ 3)),
                child: Container(
                  width: n == 1 ? 8 : 5,
                  height: n == 1 ? 8 : 5,
                  decoration: BoxDecoration(
                    color: n == 1 ? const Color(0xFFFF8A7A) : const Color(0xFF4A4038),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// 카드 안 점선
class _DashPainter extends CustomPainter {
  const _DashPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = const Color(0xFFE4DBCB)
      ..strokeWidth = 1.5;
    var x = 0.0;
    while (x < size.width) {
      canvas.drawLine(Offset(x, size.height / 2), Offset(math.min(x + 5, size.width), size.height / 2), p);
      x += 9;
    }
  }

  @override
  bool shouldRepaint(_DashPainter old) => false;
}

class _BoardButton extends StatelessWidget {
  final bool filled;
  final VoidCallback onTap;
  final IconData? icon; // 없으면 굴러가는 주사위
  final String label;
  const _BoardButton({required this.filled, required this.onTap, this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    final fg = filled ? const Color(0xFF17140F) : Colors.white;
    return Material(
      color: filled ? Colors.white : Colors.white.withOpacity(0.18),
      borderRadius: BorderRadius.circular(13),
      child: InkWell(
        borderRadius: BorderRadius.circular(13),
        onTap: onTap,
        child: SizedBox(
          height: 44,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              icon == null ? RollDiceIcon(size: 18, color: fg) : Icon(icon, size: 17, color: fg),
              const SizedBox(width: 6),
              // 긴 언어(독일어 등)는 버튼 폭 안에서 살짝 작게
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(label,
                      maxLines: 1, style: TextStyle(color: fg, fontSize: 13, fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 재생 중 작은 막대 3개
class _MiniBars extends StatefulWidget {
  final Color color;
  const _MiniBars({this.color = Colors.white});
  @override
  State<_MiniBars> createState() => _MiniBarsState();
}

class _MiniBarsState extends State<_MiniBars> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 11,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var i = 0; i < 3; i++) ...[
              if (i > 0) const SizedBox(width: 2),
              Container(
                width: 2.5,
                height: 3 + 8 * (0.5 + 0.5 * math.sin(_c.value * 2 * math.pi + i * 1.3)),
                decoration: BoxDecoration(color: widget.color, borderRadius: BorderRadius.circular(1)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// 입체 주사위 (그림 파일 없이 코드로)
class DiceCube extends StatelessWidget {
  final double size, rx, ry, rz;
  const DiceCube({super.key, required this.size, this.rx = 0, this.ry = 0, this.rz = 0});

  static final Map<int, Matrix4> _faceRot = {
    1: Matrix4.identity(),
    6: Matrix4.rotationY(math.pi),
    2: Matrix4.rotationY(math.pi / 2),
    5: Matrix4.rotationY(-math.pi / 2),
    3: Matrix4.rotationX(math.pi / 2),
    4: Matrix4.rotationX(-math.pi / 2),
  };
  static const Map<int, List<int>> _pips = {
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  };

  @override
  Widget build(BuildContext context) {
    final rot = Matrix4.identity()
      ..rotateZ(rz)
      ..rotateX(rx)
      ..rotateY(ry);
    final faces = <Widget>[];
    for (final e in _faceRot.entries) {
      final m = rot.clone()..multiply(e.value);
      final facing = m.entry(2, 2); // 1 = 정면, 0 이하 = 뒤쪽
      if (facing <= 0.02) continue; // 안 보이는 면은 안 그림
      final full = Matrix4.identity()
        ..setEntry(3, 2, 0.0013)
        ..multiply(m)
        ..translate(0.0, 0.0, -size / 2);
      faces.add(Transform(
        alignment: Alignment.center,
        transform: full,
        child: _face(e.key, facing),
      ));
    }
    return SizedBox(width: size, height: size, child: Stack(children: faces));
  }

  // 말랑 젤리: 아주 둥근 모서리 · 크림색 광택 · 작은 동글 점 · 1은 산호색
  Widget _face(int n, double light) {
    final l = light.clamp(0.0, 1.0);
    final top = Color.lerp(const Color(0xFFD9D1C2), const Color(0xFFFFFDF8), l)!;
    final bottom = Color.lerp(const Color(0xFFC4B9A6), const Color(0xFFF1E9DA), l)!;
    final pip = size * 0.16;
    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * 0.18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.34),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [top, bottom]),
        border: Border.all(color: const Color(0x0D000000), width: 1),
      ),
      child: Stack(
        children: [
          for (final k in _pips[n]!)
            Align(
              alignment: Alignment(-1.0 + (k % 3), -1.0 + (k ~/ 3)),
              child: Container(
                width: n == 1 ? pip * 1.45 : pip,
                height: n == 1 ? pip * 1.45 : pip,
                decoration: BoxDecoration(
                  color: n == 1 ? const Color(0xFFFF8A7A) : const Color(0xFF4A4038),
                  shape: BoxShape.circle,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// 굴러가는 주사위 아이콘 (기울어진 주사위 + 움직임 선) — 라디오 위쪽 · 버튼에 같이 씀
class RollDiceIcon extends StatelessWidget {
  final double size;
  final Color color;
  const RollDiceIcon({super.key, this.size = 24, required this.color});

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: _RollDicePainter(color));
}

class _RollDicePainter extends CustomPainter {
  final Color color;
  _RollDicePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / 24; // 24칸 기준으로 그림
    final line = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.9 * k
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final fill = Paint()..color = color;
    // 움직임 선 세 줄
    canvas.drawLine(Offset(2.5 * k, 9 * k), Offset(5.7 * k, 9 * k), line);
    canvas.drawLine(Offset(1.8 * k, 13 * k), Offset(5.4 * k, 13 * k), line);
    canvas.drawLine(Offset(3 * k, 17 * k), Offset(5.6 * k, 17 * k), line);
    // 기울어진 주사위
    canvas.save();
    canvas.translate(14.5 * k, 11.5 * k);
    canvas.rotate(16 * math.pi / 180);
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: 12.4 * k, height: 12.4 * k), Radius.circular(3.4 * k)),
        line);
    for (final o in [const Offset(-2.6, -2.6), Offset.zero, const Offset(2.6, 2.6)]) {
      canvas.drawCircle(o * k, 1.15 * k, fill);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_RollDicePainter old) => old.color != color;
}

/// 포인트 색 천 (가운데 밝게 + 잔잔한 결 + 바느질 점선)
class _FeltPainter extends CustomPainter {
  final Color color;
  final double inset, innerRadius;
  _FeltPainter(this.color, {this.inset = 10, this.innerRadius = 18});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final hsl = HSLColor.fromColor(color);
    final light = hsl.withLightness((hsl.lightness + 0.08).clamp(0.0, 1.0)).toColor();
    final dark = hsl.withLightness((hsl.lightness - 0.16).clamp(0.0, 1.0)).toColor();
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0, -0.15),
          radius: 0.9,
          colors: [light, color, dark],
          stops: const [0, 0.5, 1],
        ).createShader(rect),
    );
    // 천 결: 작은 점 (항상 같은 모양)
    final r = math.Random(11);
    final dot = Paint();
    for (var i = 0; i < 1600; i++) {
      dot.color = (r.nextBool() ? Colors.white : Colors.black).withOpacity(0.035 + r.nextDouble() * 0.04);
      canvas.drawCircle(Offset(r.nextDouble() * size.width, r.nextDouble() * size.height), 0.6 + r.nextDouble() * 0.7, dot);
    }
    // 바느질 점선
    final inner = RRect.fromRectAndRadius(rect.deflate(inset), Radius.circular(innerRadius));
    final path = Path()..addRRect(inner);
    final stroke = Paint()
      ..color = Colors.white.withOpacity(0.28)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    for (final metric in path.computeMetrics()) {
      var d = 0.0;
      while (d < metric.length) {
        canvas.drawPath(metric.extractPath(d, d + 5), stroke);
        d += 9;
      }
    }
  }

  @override
  bool shouldRepaint(_FeltPainter old) => old.color != color;
}

/// 라디오 처음 들어왔을 때 한 번만: 가운데 포인트 색 천 정사각형 팝업
class RadioDiceIntro extends StatefulWidget {
  final VoidCallback onThrow;
  final VoidCallback onClose;
  const RadioDiceIntro({super.key, required this.onThrow, required this.onClose});

  @override
  State<RadioDiceIntro> createState() => _RadioDiceIntroState();
}

class _RadioDiceIntroState extends State<RadioDiceIntro> with TickerProviderStateMixin {
  // 천천히 흔들기 + 가끔 통통
  late final AnimationController _rock =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 5000))..repeat();
  late final AnimationController _hop =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat();

  @override
  void dispose() {
    _rock.dispose();
    _hop.dispose();
    super.dispose();
  }

  double _hopY(double t) {
    // 0~60% 가만히 → 통 → 작게 통
    const k = [(0.0, 0.0), (0.60, 0.0), (0.70, -10.0), (0.80, 0.0), (0.86, -4.0), (0.92, 0.0), (1.0, 0.0)];
    for (var i = 1; i < k.length; i++) {
      if (t <= k[i].$1) {
        final a = k[i - 1], b = k[i];
        return a.$2 + (b.$2 - a.$2) * Curves.easeInOut.transform((t - a.$1) / (b.$1 - a.$1));
      }
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final point = context.watch<ThemeProvider>().primaryColor;
    return Stack(
      children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(color: const Color(0x6B17140F)),
          ),
        ),
        Center(
          child: GestureDetector(
            onTap: widget.onThrow,
            child: Container(
              width: 296,
              height: 296,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [BoxShadow(color: Color(0x59000000), blurRadius: 50, offset: Offset(0, 22))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: RepaintBoundary(
                          child: CustomPaint(painter: _FeltPainter(point, inset: 9, innerRadius: 22))),
                    ),
                    Center(
                      // 글자 크기를 크게 해 둔 폰에서도 정사각형 안에 들어가게
                      child: MediaQuery.withClampedTextScaling(
                        maxScaleFactor: 1.15,
                        child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 22),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedBuilder(
                              animation: Listenable.merge([_rock, _hop]),
                              builder: (_, __) {
                                final s = math.sin(_rock.value * 2 * math.pi);
                                return Transform.translate(
                                  offset: Offset(0, _hopY(_hop.value)),
                                  child: DiceCube(
                                    size: 72,
                                    rx: (-20 - 2 * s) * math.pi / 180,
                                    ry: (24 * s) * math.pi / 180,
                                  ),
                                );
                              },
                            ),
                            const SizedBox(height: 14),
                            Text(tr.diceTitle,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 17.5,
                                    fontWeight: FontWeight.w800,
                                    height: 1.4,
                                    letterSpacing: -0.4)),
                            const SizedBox(height: 4),
                            Text(tr.diceSub,
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.white.withOpacity(0.88), fontSize: 13.5, height: 1.5)),
                            const SizedBox(height: 14),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
                              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(999)),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const RollDiceIcon(size: 19, color: Color(0xFF17140F)),
                                  const SizedBox(width: 7),
                                  Text(tr.rollDice,
                                      style: const TextStyle(
                                          color: Color(0xFF17140F), fontSize: 14, fontWeight: FontWeight.w800)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      ),
                    ),
                    // ✕
                    Positioned(
                      top: 10,
                      right: 10,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: widget.onClose,
                        child: const SizedBox(
                          width: 34,
                          height: 34,
                          child: Icon(Icons.close_rounded, size: 18, color: Color(0xCCFFFFFF)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
