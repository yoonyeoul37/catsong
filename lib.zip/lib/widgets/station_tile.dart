import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../models/radio_station.dart';
import '../providers/radio_provider.dart';
import '../providers/theme_provider.dart';
import '../theme/app_theme.dart';
import 'station_logo.dart';
import '../screens/radio_player_screen.dart';

class StationTile extends StatelessWidget {
  final RadioStation station;
  final bool openedFromList; // false면 재생화면에서 뒤로가기 → 라디오 목록
  const StationTile({super.key, required this.station, this.openedFromList = true});

  @override
  Widget build(BuildContext context) {
    const accent = AppTheme.fixedAccent;
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final baseColor = isDarkMode ? Colors.white : Colors.black;
    final radioProvider = context.watch<RadioProvider>();
    final isPlaying =
        radioProvider.currentStation?.stationUuid == station.stationUuid;
    final isFav = radioProvider.isFavorite(station.stationUuid);

    return InkWell(
      onTap: () {
        context.read<RadioProvider>().playStation(station);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => RadioPlayerScreen(
              station: station,
              openedFromList: openedFromList,
            ),
          ),
        );
      },
      splashColor: baseColor.withOpacity(0.04),
      highlightColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 13),
        child: Row(
          children: [
            StationLogo(
                logoUrl: station.logoUrl,
                name: station.name,
                size: 46),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    station.name,
                    style: TextStyle(
                      color: isPlaying ? accent : baseColor,
                      fontSize: 15.5,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.2,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    [
                      if (station.country != null) station.country!,
                      if (station.bitrate != null && station.bitrate! > 0)
                        '${station.bitrate} kbps',
                    ].join(' · '),
                    style: TextStyle(
                        color: baseColor.withOpacity(0.45), fontSize: 11.5),
                  ),
                ],
              ),
            ),
            if (isPlaying)
              const Icon(Icons.graphic_eq, color: accent, size: 22)
            else
              IconButton(
                icon: Icon(
                  isFav ? CupertinoIcons.heart_fill : CupertinoIcons.heart,
                  color: isFav ? accent : baseColor.withOpacity(0.3),
                  size: 21,
                ),
                onPressed: () =>
                    Future.microtask(() => radioProvider.toggleFavorite(station)),
              ),
          ],
        ),
      ),
    );
  }
}